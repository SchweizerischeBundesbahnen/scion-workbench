import * as i0 from '@angular/core';
import { inputBinding, signal, input, Component, inject, InjectionToken, Injector, runInInjectionContext, Injectable, viewChild, effect, untracked, computed, Directive, makeEnvironmentProviders } from '@angular/core';
import { SciComponentOutletDirective, coerceSignal } from '@scion/components/common';
import { fromMutation$ } from '@scion/toolkit/observable';
import { of, concatWith, map } from 'rxjs';

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides Material icons for non-scion icons.
 */
const materialIconProvider = (ligature) => {
    if (ligature.startsWith('scion.')) {
        return undefined; // delegate to next provider
    }
    return { component: MaterialIconComponent, bindings: [inputBinding('ligature', signal(ligature))] };
};
/**
 * Renders a Material icon based on its ligature.
 *
 * This component requires a Material icon font to be included in the HTML.
 *
 * Supported fonts:
 * - https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded
 * - https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined
 * - https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp
 * - https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Round|Material+Icons+Sharp
 */
class MaterialIconComponent {
    /**
     * Specifies the ligature of the Material icon.
     */
    ligature = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ligature" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: MaterialIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.1", type: MaterialIconComponent, isStandalone: true, selector: "sci-material-icon", inputs: { ligature: { classPropertyName: "ligature", publicName: "ligature", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: '{{ligature()}}', isInline: true, styles: [":host{font-family:Material Symbols Rounded,Material Symbols Outlined,Material Symbols Sharp,Material Icons,Material Icons Outlined,Material Icons Round,Material Icons Sharp;font-weight:400;font-style:normal;line-height:1;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;font-feature-settings:\"liga\";-webkit-font-smoothing:antialiased}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: MaterialIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sci-material-icon', template: '{{ligature()}}', styles: [":host{font-family:Material Symbols Rounded,Material Symbols Outlined,Material Symbols Sharp,Material Icons,Material Icons Outlined,Material Icons Round,Material Icons Sharp;font-weight:400;font-style:normal;line-height:1;letter-spacing:normal;text-transform:none;display:inline-block;white-space:nowrap;word-wrap:normal;direction:ltr;font-feature-settings:\"liga\";-webkit-font-smoothing:antialiased}\n"] }]
        }], propDecorators: { ligature: [{ type: i0.Input, args: [{ isSignal: true, alias: "ligature", required: true }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides icons used in SCION libraries.
 *
 * Register this provider as the last icon provider, enabling replacement of built-in SCION icons.
 */
const scionIconProvider = (icon) => {
    const ligature = scionIcons[icon];
    if (ligature) {
        return { component: ScionIconComponent, bindings: [inputBinding('ligature', signal(ligature))] };
    }
    return undefined;
};
/**
 * Maps icons to ligatures of the SCION icon font.
 */
const scionIcons = {
    'scion.add': 'add',
    'scion.checkmark': 'checkmark',
    'scion.chevron_down': 'chevron_down',
    'scion.chevron_left': 'chevron_left',
    'scion.chevron_right': 'chevron_right',
    'scion.chevron_up': 'chevron_up',
    'scion.clear': 'clear',
    'scion.close': 'close',
    'scion.collapse_all': 'collapse_all',
    'scion.delete': 'delete',
    'scion.dirty': 'dirty',
    'scion.edit': 'edit',
    'scion.expand_all': 'expand_all',
    'scion.filter': 'filter',
    'scion.minimize': 'minimize',
    'scion.more_horizontal': 'more_horizontal',
    'scion.more_vertical': 'more_vertical',
    'scion.pin': 'pin',
    'scion.remove': 'remove',
    'scion.search': 'search',
};
/**
 * Renders the icon for a ligature of the SCION icon font.
 *
 * This component requires the SCION icon font 'scion-icons' to be included in the HTML.
 */
class ScionIconComponent {
    /**
     * Specifies the ligature of the icon.
     */
    ligature = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ligature" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: ScionIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.1", type: ScionIconComponent, isStandalone: true, selector: "sci-scion-icon", inputs: { ligature: { classPropertyName: "ligature", publicName: "ligature", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: '{{ligature()}}', isInline: true, styles: [":host{font-family:scion-icons;font-style:normal;font-weight:400;font-variant:normal;text-transform:none;line-height:1;letter-spacing:0;font-feature-settings:\"liga\";font-variant-ligatures:discretionary-ligatures;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: ScionIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sci-scion-icon', template: '{{ligature()}}', styles: [":host{font-family:scion-icons;font-style:normal;font-weight:400;font-variant:normal;text-transform:none;line-height:1;letter-spacing:0;font-feature-settings:\"liga\";font-variant-ligatures:discretionary-ligatures;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}\n"] }]
        }], propDecorators: { ligature: [{ type: i0.Input, args: [{ isSignal: true, alias: "ligature", required: true }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides icons based on registered icon providers.
 */
class IconProviders {
    _iconProviders = [
        // Provide app-specific icons.
        ...inject(SCI_ICON_PROVIDER, { optional: true }) ?? [],
        // Provide built-in icons.
        scionIconProvider,
        // Provide material icons.
        materialIconProvider,
    ];
    _injector = inject(Injector);
    /**
     * Provides the icon descriptor for the given icon based on icon providers registered under the {@link SCI_ICON_PROVIDER} DI token.
     *
     * Icon providers are called in registration order. If a provider does not provide the icon, the next provider is called, and so on.
     */
    provide(icon) {
        if (!icon) {
            return undefined;
        }
        if (!this._iconProviders.length) {
            return undefined;
        }
        for (const iconProvider of this._iconProviders) {
            const componentOrDescriptor = runInInjectionContext(this._injector, () => iconProvider(icon));
            if (componentOrDescriptor) {
                return typeof componentOrDescriptor === 'function' ? { component: componentOrDescriptor } : componentOrDescriptor;
            }
        }
        return undefined;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: IconProviders, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: IconProviders, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: IconProviders, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * Multi-DI token for injecting icon providers.
 *
 * @see provideIconProvider
 * @see SciIconProviderFn
 */
const SCI_ICON_PROVIDER = new InjectionToken('SCI_ICON_PROVIDER');

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Renders an icon based on registered icon providers.
 *
 * Set the icon name as slotted content of the `<sci-icon>` component.
 *
 * Example:
 * ```html
 * <sci-icon>home</sci-icon>
 * ```
 *
 * Providers are called in registration order. If a provider does not provide the icon, the next provider is called, and so on.
 * If no provider provides the icon, defaults to a Material icon provider, interpreting the icon as a Material icon ligature.
 *
 * The icon size depends on the font size at its position in the DOM.
 * To change the size, set a font-size on the `<sci-icon>` element or set the `--sci-icon-size` CSS variable.
 *
 * @see provideIconProvider
 *
 * TODO [Angular 23] Consider changing encapsulation to `IsolatedShadowDom` when stable. See branch issue/icon-shadow-dom
 */
class SciIconComponent {
    _slottedContent = viewChild.required('slotted_content');
    icon = this.computeIcon();
    /**
     * Reads the icon from slotted content and passes it to registered icon providers for resolution.
     */
    computeIcon() {
        const icon = signal(undefined, /* @ts-ignore */
        ...(ngDevMode ? [{ debugName: "icon" }] : /* istanbul ignore next */ []));
        const iconProviders = inject(IconProviders);
        effect(onCleanup => {
            const slottedContent = this._slottedContent();
            untracked(() => {
                // Instantiate template to "read" slotted content.
                const view = slottedContent.createEmbeddedView(undefined);
                onCleanup(() => view.destroy());
                // Return if empty, i.e., no icon to render.
                if (!view.rootNodes.length) {
                    icon.set(undefined);
                    return;
                }
                // Ensure only text is provided as slotted content.
                if (view.rootNodes.length > 1 || view.rootNodes[0].nodeType !== Node.TEXT_NODE) {
                    throw Error('[InvalidInputError] Only text (ligature) is allowed in slotted content of <sci-icon>.');
                }
                // Watch slotted content.
                const textNode = view.rootNodes[0];
                const subscription = of(textNode.textContent)
                    .pipe(concatWith(fromMutation$(textNode, { characterData: true }).pipe(map(() => textNode.textContent))), map(slottedContent => iconProviders.provide(slottedContent.trim() || undefined)), augmentIconDescriptor())
                    .subscribe(iconDescriptor => icon.set(iconDescriptor));
                onCleanup(() => subscription.unsubscribe());
            });
        });
        return icon;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: SciIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.0.1", type: SciIconComponent, isStandalone: true, selector: "sci-icon", viewQueries: [{ propertyName: "_slottedContent", first: true, predicate: ["slotted_content"], descendants: true, isSignal: true }], ngImport: i0, template: "<ng-container *sciComponentOutlet=\"icon()\"/>\r\n\r\n<!--Template to capture slotted content. -->\r\n<ng-template #slotted_content>\r\n  <ng-content/>\r\n</ng-template>\r\n", styles: [":host{display:inline-grid;place-content:center;-webkit-user-select:none;user-select:none;height:var(--sci-icon-size, 1em);width:var(--sci-icon-size, 1em);overflow:hidden}\n"], dependencies: [{ kind: "directive", type: SciComponentOutletDirective, selector: "ng-template[sciComponentOutlet]", inputs: ["sciComponentOutlet"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: SciIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sci-icon', imports: [
                        SciComponentOutletDirective,
                    ], template: "<ng-container *sciComponentOutlet=\"icon()\"/>\r\n\r\n<!--Template to capture slotted content. -->\r\n<ng-template #slotted_content>\r\n  <ng-content/>\r\n</ng-template>\r\n", styles: [":host{display:inline-grid;place-content:center;-webkit-user-select:none;user-select:none;height:var(--sci-icon-size, 1em);width:var(--sci-icon-size, 1em);overflow:hidden}\n"] }]
        }], propDecorators: { _slottedContent: [{ type: i0.ViewChild, args: ['slotted_content', { isSignal: true }] }] } });
/**
 * Augments the icon descriptor:
 *
 * - Prevents the browser from translating the icon.
 * - Sets the icon's font size to 'var(--sci-icon-size, 1em)', required to inherit the location's font size for icons with a fixed font size.
 *   For example, Material sets a fixed font size of 24px.
 */
function augmentIconDescriptor() {
    return map((icon) => icon && {
        ...icon,
        attributes: computed(() => ({
            ...coerceSignal(icon.attributes)?.(),
            translate: 'no',
        })),
        directives: [
            ...icon.directives ?? [],
            IconFontSizeDirective,
        ],
    });
}
/**
 * Sets the font size to 'var(--sci-icon-size, 1em)', required to inherit the location's font size for icons with a fixed font size.
 * For example, Material sets a fixed font size of 24px.
 */
class IconFontSizeDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: IconFontSizeDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.0.1", type: IconFontSizeDirective, isStandalone: true, host: { properties: { "style.font-size": "'var(--sci-icon-size, 1em)'" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.1", ngImport: i0, type: IconFontSizeDirective, decorators: [{
            type: Directive,
            args: [{ host: { '[style.font-size]': `'var(--sci-icon-size, 1em)'` } }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Enables contribution or replacement of icons used in SCION.
 *
 * An icon provider is a function that returns a component for an icon. The component renders the icon.
 *
 * Multiple icon providers can be registered. Providers are called in registration order. If a provider does not provide the icon,
 * the next provider is called, and so on.
 *
 * Defaults to a Material icon provider, interpreting the icon as a Material icon ligature.
 *
 * The default icon provider requires the application to include the Material icon font, for example in `styles.scss`, as follows:
 * ```scss
 * @import url('https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL@20..24,400,0&display=block');
 * ```
 *
 * SCION uses the following icons:
 * - `scion.add`: Add or create new item
 * - `scion.checkmark`: Checked state indicator of an option
 * - `scion.chevron_down`: Expand a section or tree node, or open a menu
 * - `scion.chevron_left`: Collapse or expand a side panel
 * - `scion.chevron_right`: Collapse or expand a side panel, or open a submenu
 * - `scion.chevron_up`: Collapse a section or tree node
 * - `scion.clear`: Clear content in input fields
 * - `scion.close`: Close a view, dialog, or notification
 * - `scion.collapse_all`: Collapse all tree nodes
 * - `scion.delete`: Delete selected item or data
 * - `scion.dirty`: Indicate unsaved changes
 * - `scion.edit`: Enter edit mode
 * - `scion.expand_all`: Expand all tree nodes
 * - `scion.filter`: Open or apply a filter
 * - `scion.minimize`: Minimize a panel
 * - `scion.more_horizontal`: Show options menu horizontally
 * - `scion.more_vertical`: Show options menu vertically
 * - `scion.pin`: Pin or unpin an element
 * - `scion.remove`: Remove item from a list or selection
 * - `scion.search`: Trigger or indicate search function
 *
 * To not replace built-in icons, the icon provider can return `undefined` for icons starting with the `scion.` prefix.
 *
 * The function can call `inject` to get any required dependencies.
 *
 * @see SciIconProviderFn
 * @see SciIconComponent
 */
function provideIconProvider(iconProviderFn) {
    return makeEnvironmentProviders(iconProviderFn ? [
        {
            provide: SCI_ICON_PROVIDER,
            useValue: iconProviderFn,
            multi: true,
        },
    ] : []);
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/*
 * Secondary entrypoint: '@scion/components/icon'
 *
 * @see https://github.com/ng-packagr/ng-packagr/blob/master/docs/secondary-entrypoints.md
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SciIconComponent, provideIconProvider };
//# sourceMappingURL=scion-components-icon.mjs.map
