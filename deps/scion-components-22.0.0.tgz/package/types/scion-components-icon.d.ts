import * as i0 from '@angular/core';
import { Signal, EnvironmentProviders } from '@angular/core';
import { SciComponentDescriptor } from '@scion/components/common';
import { ComponentType } from '@angular/cdk/portal';

/**
 * Renders an icon based on registered icon providers.
 *
 * Set the icon name as slotted content of the `<sci-icon>` component.
 *
 * Example:
 * ```html
 * <sci-icon>home</sci-icon>
 * ```
 *
 * Providers are called in registration order. If a provider does not provide the icon, the next provider is called, and so on.
 * If no provider provides the icon, defaults to a Material icon provider, interpreting the icon as a Material icon ligature.
 *
 * The icon size depends on the font size at its position in the DOM.
 * To change the size, set a font-size on the `<sci-icon>` element or set the `--sci-icon-size` CSS variable.
 *
 * @see provideIconProvider
 *
 * TODO [Angular 23] Consider changing encapsulation to `IsolatedShadowDom` when stable. See branch issue/icon-shadow-dom
 */
declare class SciIconComponent {
    private readonly _slottedContent;
    protected readonly icon: Signal<SciComponentDescriptor | undefined>;
    /**
     * Reads the icon from slotted content and passes it to registered icon providers for resolution.
     */
    private computeIcon;
    static ɵfac: i0.ɵɵFactoryDeclaration<SciIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SciIconComponent, "sci-icon", never, {}, {}, never, ["*"], true, never>;
}

/**
 * Enables contribution or replacement of icons used in SCION.
 *
 * An icon provider is a function that returns a component for an icon. The component renders the icon.
 *
 * Multiple icon providers can be registered. Providers are called in registration order. If a provider does not provide the icon,
 * the next provider is called, and so on.
 *
 * Defaults to a Material icon provider, interpreting the icon as a Material icon ligature.
 *
 * The default icon provider requires the application to include the Material icon font, for example in `styles.scss`, as follows:
 * ```scss
 * @import url('https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL@20..24,400,0&display=block');
 * ```
 *
 * SCION uses the following icons:
 * - `scion.add`: Add or create new item
 * - `scion.checkmark`: Checked state indicator of an option
 * - `scion.chevron_down`: Expand a section or tree node, or open a menu
 * - `scion.chevron_left`: Collapse or expand a side panel
 * - `scion.chevron_right`: Collapse or expand a side panel, or open a submenu
 * - `scion.chevron_up`: Collapse a section or tree node
 * - `scion.clear`: Clear content in input fields
 * - `scion.close`: Close a view, dialog, or notification
 * - `scion.collapse_all`: Collapse all tree nodes
 * - `scion.delete`: Delete selected item or data
 * - `scion.dirty`: Indicate unsaved changes
 * - `scion.edit`: Enter edit mode
 * - `scion.expand_all`: Expand all tree nodes
 * - `scion.filter`: Open or apply a filter
 * - `scion.minimize`: Minimize a panel
 * - `scion.more_horizontal`: Show options menu horizontally
 * - `scion.more_vertical`: Show options menu vertically
 * - `scion.pin`: Pin or unpin an element
 * - `scion.remove`: Remove item from a list or selection
 * - `scion.search`: Trigger or indicate search function
 *
 * To not replace built-in icons, the icon provider can return `undefined` for icons starting with the `scion.` prefix.
 *
 * The function can call `inject` to get any required dependencies.
 *
 * @see SciIconProviderFn
 * @see SciIconComponent
 */
declare function provideIconProvider(iconProviderFn: SciIconProviderFn | undefined): EnvironmentProviders;
/**
 * Signature of a function to provide icons.
 *
 * An icon provider is a function that returns the component for an icon. The component renders the icon.
 *
 * Alternatively, the icon provider can return a descriptor, allowing for additional configuration such as inputs.
 * Inputs are available as input properties in the component. The component can use the inputs to render the icon.
 *
 * Icon keys used by SCION start with the `scion.` prefix. To not replace built-in icons, the icon provider can
 * return `undefined` for icons starting with the `scion.` prefix.
 *
 * An icon provider can be registered via {@link provideIconProvider} function.
 *
 * The function can call `inject` to get any required dependencies.
 *
 * @param icon - The key of the icon for which to provide the icon component.
 * @returns ComponentType or {@link SciComponentDescriptor} to render the icon, or `undefined` if not provided by the icon provider.
 */
type SciIconProviderFn = (icon: string) => ComponentType<unknown> | SciComponentDescriptor | undefined;

export { SciIconComponent, provideIconProvider };
export type { SciIconProviderFn };
