import * as _angular_core from '@angular/core';
import { Injector, Signal, ElementRef, Binding, Provider, ViewContainerRef } from '@angular/core';
import { OneOf, MaybeArray, Disposable, RequireOne } from '@scion/toolkit/types';
import { ComponentType } from '@angular/cdk/portal';
import { MaybeSignal, SciComponentDescriptor } from '@scion/components/common';
import { Translatable } from '@scion/components/text';
import * as _scion_components_menu from '@scion/components/menu';

interface SciMenubarFactory {
    addMenu(descriptor: SciMenubarMenuDescriptor, menuFactoryFn: (menu: SciMenuFactory) => void): this;
}
interface SciMenubarMenuDescriptor {
    name?: `menuitem:${string}`;
    label: MaybeSignal<Translatable>;
    visible?: MaybeSignal<boolean>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    menu?: SciMenuDescriptor['menu'];
}

interface SciMenuContribution {
    scope: 'menu' | 'toolbar' | 'menubar';
    factoryFn: SciMenuFactoryFnLike;
    requiredContext: Map<string, unknown>;
    position?: SciMenuContributionPositionLike;
    contributionInstant: number;
    /**
     * Arbitrary metadata to be associated with the contribution.
     */
    metadata: {
        [key: string]: unknown;
    };
}
type SciMenuContributionLocation = {
    location: `menu:${string}`;
} & SciMenuContributionPosition;
type SciToolbarContributionLocation = {
    location: `toolbar:${string}`;
} & SciToolbarContributionPosition;
type SciMenubarContributionLocation = {
    location: `menubar:${string}`;
} & SciMenubarContributionPosition;
type SciMenuContributionLocationLike = SciMenuContributionLocation | SciToolbarContributionLocation | SciMenubarContributionLocation;
interface SciMenuContributionOptions {
    /**
     * This function must be called within an injection context, or an explicit {@link Injector} passed. Destroying the injection context will unregister contributed menus.
     */
    injector?: Injector;
    /**
     * Context required by the contribution.
     */
    requiredContext?: Map<string, unknown>;
    /**
     * Arbitrary metadata to be associated with the contribution.
     */
    metadata?: {
        [key: string]: unknown;
    };
    contributionInstant?: number;
}
type SciMenuContributionPosition = OneOf<{
    before?: `menuitem:${string}` | `menu:${string}`;
    after?: `menuitem:${string}` | `menu:${string}`;
    position?: 'start' | 'end';
}>;
type SciToolbarContributionPosition = OneOf<{
    before?: `menuitem:${string}` | `toolbar:${string}`;
    after?: `menuitem:${string}` | `toolbar:${string}`;
    position?: 'start' | 'end';
}>;
type SciMenubarContributionPosition = OneOf<{
    before?: `menu:${string}`;
    after?: `menu:${string}`;
    position?: 'start' | 'end';
}>;
type SciMenuContributionPositionLike = SciMenuContributionPosition | SciToolbarContributionPosition | SciMenubarContributionPosition;
type SciMenuFactoryFn = (menu: SciMenuFactory, context: Map<string, unknown>) => void;
type SciToolbarFactoryFn = (toolbar: SciToolbarFactory, context: Map<string, unknown>) => void;
type SciMenubarFactoryFn = (menubar: SciMenubarFactory, context: Map<string, unknown>) => void;
type SciMenuFactoryFnLike = SciMenuFactoryFn | SciToolbarFactoryFn | SciMenubarFactoryFn;

/**
 * INPUTS FOR DESCRIPTION: https://www.electronjs.org/docs/latest/api/menu-item
 */
interface SciMenuItem {
    type: 'menu-item';
    name?: `menuitem:${string}`;
    labelText?: Signal<string>;
    labelComponent?: SciComponentDescriptor;
    iconLigature?: Signal<string>;
    iconComponent?: SciComponentDescriptor;
    control?: SciComponentDescriptor;
    tooltip?: Signal<string>;
    accelerator?: SciKeyboardAccelerator;
    disabled?: Signal<boolean>;
    visible?: Signal<boolean>;
    checked?: Signal<boolean>;
    active?: Signal<boolean>;
    actions?: SciMenuItemLike[];
    matchesFilter?: (filter: string) => boolean;
    position?: SciMenuContributionPositionLike;
    visualMenuIndicator?: boolean;
    cssClass?: string[];
    attributes?: {
        [name: string]: string;
    };
    onSelect?: () => Promise<boolean>;
    menu?: {
        name?: `menu:${string}`;
        width?: string;
        minWidth?: string;
        maxWidth?: string;
        maxHeight?: string;
        filter?: SciMenuFilterConfig<Signal<Translatable>>;
        children: SciMenuItemLike[];
    };
}
interface SciMenuGroup {
    type: 'group';
    name?: `menu:${string}` | `toolbar:${string}`;
    label?: Signal<string>;
    collapsible?: {
        collapsed: boolean;
    };
    glyphArea?: false;
    disabled?: Signal<boolean>;
    visible?: Signal<boolean>;
    position?: SciMenuContributionPositionLike;
    actions?: SciMenuItemLike[];
    children: SciMenuItemLike[];
    cssClass?: string[];
}
type SciMenuItemLike = SciMenuItem | SciMenuGroup;

/**
 * Installs accelerators for menu items contributed to the given location matching the specified context.
 *
 * An accelerator maps a physical key combination (key combined with modifiers such as `Ctrl`, `Shift`, or `Alt`) to an application action,
 * enabling users to trigger commands or navigate the user interface without using a pointer device.
 *
 * Menu items are contributed to a location and may declare a required context. Only accelerators of menu items matching the specified context are installed.
 *
 * This function must be called within an injection context, or an explicit {@link Injector} passed. Destroying the injection context uninstalls the accelerators.
 *
 * @param location - Specifies the menu, toolbar, or menubar for which to install accelerators.
 * @param options - Controls installation of accelerators.
 * @returns Handle to uninstall the accelerators.
 */
declare function installMenuAccelerators(location: `menu:${string}` | `toolbar:${string}` | `menubar:${string}`, options?: SciMenuAcceleratorOptions): Disposable;
/**
 * Controls installation of accelerators.
 */
interface SciMenuAcceleratorOptions {
    /**
     * Specifies DOM elements on which to install menu accelerators. Defaults to {@link SciMenuEnvironmentProvider.provideAcceleratorTargets} or {@link Document}.
     */
    target?: MaybeArray<Element | ElementRef<Element>>;
    /**
     * Controls in which context to install menu accelerators.
     *
     * Menu items are contributed to a location and may declare a required context. Only accelerators of menu items matching this context are installed.
     */
    context?: Map<string, unknown>;
    /**
     * Specifies metadata available to the operation.
     */
    metadata?: {
        [key: string]: unknown;
    };
    /**
     * Specifies the injector used to install accelerators. Defaults to the current injection context. Destroying the injector uninstalls the accelerators.
     */
    injector?: Injector;
}
/**
 * Represents a keyboard accelerator to match specific keystrokes or key combinations.
 *
 * An accelerator maps a physical key combination (key combined with modifiers such as `Ctrl`, `Shift`, or `Alt`) to an application action,
 * enabling users to trigger commands or navigate the user interface without using a pointer device.
 */
interface SciKeyboardAccelerator {
    /**
     * Specifies the key of the accelerator.
     *
     * @see https://developer.mozilla.org/en-US/docs/Web/API/UI_Events/Keyboard_event_key_values
     */
    key: string;
    /**
     * Indicates whether the `Ctrl` key (or `Cmd` key on macOS) must be pressed.
     */
    ctrl?: boolean;
    /**
     * Indicates whether the `Shift` key must be pressed.
     */
    shift?: boolean;
    /**
     * Indicates whether the `Alt` key (or `Opt` key on macOS) must be pressed.
     */
    alt?: boolean;
    /**
     * Specifies the physical location of the key on the keyboard.
     *
     * - `numpad`: Keys on the numeric keypad.
     * - `left`: Left-side modifier keys.
     * - `right`: Right-side modifier keys.
     *
     * @see https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/location
     */
    location?: 'numpad' | 'left' | 'right';
}

interface SciToolbarFactory {
    addToolbarButton(descriptor: SciToolbarButtonDescriptor): this;
    addToolbarSplitButton(descriptor: SciToolbarButtonDescriptor & {
        menu?: SciMenuDescriptor['menu'];
    }, menuFactoryFn: (menu: SciMenuFactory) => void): this;
    addToolbarMenu(descriptor: SciToolbarMenuDescriptor, menuFactoryFn: (menu: SciMenuFactory) => void): this;
    addToolbarControl(descriptor: SciToolbarControlDescriptor): this;
    addToolbarSplitControl(descriptor: SciToolbarControlDescriptor & {
        menu?: SciMenuDescriptor['menu'];
    }, menuFactoryFn: (menu: SciMenuFactory) => void): this;
    addGroup(groupFactoryFn: (group: SciToolbarFactory) => void): this;
    addGroup(descriptor: SciToolbarGroupDescriptor, groupFactoryFn?: (group: SciToolbarFactory) => void): this;
}
interface SciToolbarButtonDescriptor {
    name?: `menuitem:${string}`;
    label?: MaybeSignal<Translatable> | ComponentType<unknown> | SciComponentDescriptor;
    icon?: MaybeSignal<string> | ComponentType<unknown> | SciComponentDescriptor;
    checked?: MaybeSignal<boolean>;
    tooltip?: MaybeSignal<Translatable>;
    accelerator?: SciKeyboardAccelerator;
    disabled?: MaybeSignal<boolean>;
    visible?: MaybeSignal<boolean>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    onSelect: () => void | boolean | Promise<void | boolean>;
}
interface SciToolbarMenuDescriptor {
    name?: `menuitem:${string}`;
    label?: MaybeSignal<Translatable> | ComponentType<unknown> | SciComponentDescriptor;
    icon?: MaybeSignal<string> | ComponentType<unknown> | SciComponentDescriptor;
    tooltip?: MaybeSignal<Translatable>;
    disabled?: MaybeSignal<boolean>;
    visible?: MaybeSignal<boolean>;
    /**
     * Controls the display of a visual marker for menu dropdown. Defaults to `true`.
     */
    visualMenuIndicator?: boolean;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    menu?: SciMenuDescriptor['menu'];
}
interface SciToolbarControlDescriptor {
    name?: `menuitem:${string}`;
    component: ComponentType<unknown>;
    bindings?: Binding[];
    injector?: Injector;
    providers?: Provider[];
    tooltip?: MaybeSignal<Translatable>;
    visible?: MaybeSignal<boolean>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
}
interface SciToolbarGroupDescriptor {
    name?: `toolbar:${string}`;
    disabled?: MaybeSignal<boolean>;
    visible?: MaybeSignal<boolean>;
    cssClass?: string | string[];
}

interface SciMenuFactory {
    addMenuItem(descriptor: SciMenuItemDescriptor): this;
    addMenu(descriptor: SciMenuDescriptor, menuFactoryFn: (menu: SciMenuFactory) => void): this;
    addGroup(groupFactoryFn: (group: SciMenuFactory) => void): this;
    addGroup(descriptor: SciMenuGroupDescriptor, groupFactoryFn?: (group: SciMenuFactory) => void): this;
}
interface SciMenuItemDescriptor {
    name?: `menuitem:${string}`;
    label: MaybeSignal<Translatable> | ComponentType<unknown> | SciComponentDescriptor;
    icon?: MaybeSignal<string> | ComponentType<unknown> | SciComponentDescriptor;
    checked?: MaybeSignal<boolean>;
    active?: MaybeSignal<boolean>;
    tooltip?: MaybeSignal<Translatable>;
    accelerator?: SciKeyboardAccelerator;
    disabled?: MaybeSignal<boolean>;
    visible?: MaybeSignal<boolean>;
    actions?: (actions: SciToolbarFactory) => void;
    onFilter?: (filter: string) => boolean;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    onSelect: () => void | boolean | Promise<void | boolean>;
}
interface SciMenuDescriptor {
    name?: `menuitem:${string}`;
    label: MaybeSignal<Translatable> | ComponentType<unknown> | SciComponentDescriptor;
    icon?: MaybeSignal<string> | ComponentType<unknown> | SciComponentDescriptor;
    disabled?: MaybeSignal<boolean>;
    visible?: MaybeSignal<boolean>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    menu?: {
        name?: `menu:${string}`;
        width?: string;
        minWidth?: string;
        maxWidth?: string;
        maxHeight?: string;
        filter?: boolean | RequireOne<SciMenuFilterConfig>;
    };
}
interface SciMenuGroupDescriptor {
    name?: `menu:${string}`;
    label?: MaybeSignal<Translatable>;
    collapsible?: boolean | {
        collapsed: boolean;
    };
    /**
     * TODO [menu]: Explain what glyph area is.
     *
     * Controls whether to hide the glyph area in this group.
     * Defaults to displaying the glyph area if any menu item contained in the menu or its groups has an icon or is checkable.
     */
    glyphArea?: false;
    disabled?: MaybeSignal<boolean>;
    visible?: MaybeSignal<boolean>;
    actions?: (actions: SciToolbarFactory) => void;
    cssClass?: string | string[];
}
/**
 * Features of the menu filter field.
 */
interface SciMenuFilterConfig<T = MaybeSignal<Translatable>> {
    placeholder?: T;
    notFoundMessage?: T;
    focus?: boolean;
}

declare abstract class SciMenuService {
    abstract open(name: `menu:${string}`, options: SciMenuOptions): SciMenuRef;
    abstract closeAll(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SciMenuService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SciMenuService>;
}
interface SciMenuOptions {
    /**
     * Controls where to open the menu.
     *
     * Can be an HTML element or a coordinate. The coordinate is relative to the page viewport.
     *
     * Supported coordinate pairs:
     * - x/y: Relative to the top/left corner of the page viewport.
     * - top/left: Same as x/y.
     * - top/right: Relative to the top/right corner of the page viewport.
     * - bottom/left: Relative to the bottom/left corner of the page viewport.
     * - bottom/right: Relative to the bottom/right corner of the page viewport.
     */
    anchor: HTMLElement | ElementRef<HTMLElement> | SciMenuOrigin | MouseEvent;
    context?: Map<string, unknown>;
    /**
     * Controls where to align the menu relative to the menu anchor, unless there is not enough space available in that area. Defaults to `vertical`.
     */
    align?: 'vertical' | 'horizontal';
    /**
     * Controls where the menu will be added to the DOM. If not specified, adds the menu after the anchor element.
     */
    viewContainerRef?: ViewContainerRef;
    width?: string;
    minWidth?: string;
    maxWidth?: string;
    maxHeight?: string;
    filter?: boolean | RequireOne<SciMenuFilterConfig>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    /**
     * Arbitrary metadata to be associated with the operation.
     */
    metadata?: {
        [key: string]: unknown;
    };
}
/**
 * Represents a point on the page, optionally with a dimension, where a menu should be attached.
 */
interface SciMenuOrigin {
    x: number;
    y: number;
    width?: number;
    height?: number;
}
interface SciMenuRef {
    close(): void;
    /**
     * Registers a close callback.  Returns a cleanup function that can be invoked to unregister the callback.
     *
     * The callback is immediately called if registering a callback and the menu is already closed.
     */
    onClose: (fn: () => void) => void;
}

/**
 * @docs-private Not public API. For internal use only.
 */
declare class ɵSciMenuService implements SciMenuService {
    private readonly _menuRegistry;
    private readonly _environmentContext;
    /** @inheritDoc */
    open(menu: `menu:${string}` | SciMenuItemLike[], options: SciMenuOptions): SciMenuRef;
    /** @inheritDoc */
    closeAll(): void;
    /**
     * The function:
     * - Must be called within an injection context, or an explicit {@link Injector} passed.
     * - Must be called in a non-reactive (non-tracking) context.
     *
     * @docs-private Not public API. For internal use only.
     */
    menuItems(location: MaybeSignal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: MaybeSignal<Map<string, unknown>>, options?: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }): Signal<SciMenuItemLike[]>;
    /** @docs-private Not public API. For internal use only. */
    menuContributions(location: MaybeSignal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: MaybeSignal<Map<string, unknown>>, options?: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }): Signal<SciMenuContribution[]>;
    /** @docs-private Not public API. For internal use only. */
    contributeMenu(location: SciMenuContributionLocationLike, factoryFn: SciMenuFactoryFnLike, options?: SciMenuContributionOptions): Disposable;
    /**
     * Gets keyboard accelerators for menu items installed in the application that match the given context.
     *
     * A positive match does not require an identical context, but any common context keys must map to identical context values.
     */
    accelerators(options?: {
        context?: MaybeSignal<Map<string, unknown>>;
    }): Signal<SciKeyboardAccelerator[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ɵSciMenuService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ɵSciMenuService>;
}
/**
 * Provides {@link SciMenuService} for dependency injection.
 */
declare function provideMenuService(): Provider[];

/**
 * Allows intercepting calls to the menu registry.
 *
 * Adapters can handle or augment calls. Multiple adapters form a chain and are called one by one in registration order.
 *
 * Calling 'next' passes the call to the next adapter, or to the registry if it is the last adapter in the chain.
 */
declare abstract class SciMenuAdapter {
    abstract contributeMenu?(location: SciMenuContributionLocationLike, factoryFn: SciMenuFactoryFnLike, options: SciMenuContributionOptions, next: SciMenuAdapterChain): Disposable;
    abstract menuContributions?(location: Signal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: Signal<Map<string, unknown>>, options: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }, next: SciMenuAdapterChain): Signal<SciMenuContribution[]>;
    abstract menuItems?(location: Signal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: Signal<Map<string, unknown>>, options: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }, next: SciMenuAdapterChain): Signal<SciMenuItemLike[]>;
    abstract openMenu?(menu: `menu:${string}` | SciMenuItemLike[], options: SciMenuOptions, next: SciMenuAdapterChain): SciMenuRef;
    abstract closeMenus?(next: SciMenuAdapterChain): void;
    abstract accelerators?(context: Signal<Map<string, unknown>>, next: SciMenuAdapterChain): Signal<SciKeyboardAccelerator[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SciMenuAdapter, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SciMenuAdapter>;
}
/**
 * Represents the next adapter in the adapter chain.
 */
interface SciMenuAdapterChain {
    contributeMenu(location: SciMenuContributionLocationLike, factoryFn: SciMenuFactoryFnLike, options: SciMenuContributionOptions): Disposable;
    menuContributions(location: Signal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: Signal<Map<string, unknown>>, options: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }): Signal<SciMenuContribution[]>;
    menuItems(location: Signal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: Signal<Map<string, unknown>>, options: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }): Signal<SciMenuItemLike[]>;
    openMenu(menu: `menu:${string}` | SciMenuItemLike[], options: SciMenuOptions): SciMenuRef;
    closeMenus(): void;
    accelerators(context: Signal<Map<string, unknown>>): Signal<SciKeyboardAccelerator[]>;
}

/**
 * By default, the contribution will be unregistered when the current injection context is destroyed.
 */
declare function contributeMenu(location: `menu:${string}` | SciMenuContributionLocation, menuFactoryFn: SciMenuFactoryFn, options?: SciMenuContributionOptions): Disposable;
declare function contributeMenu(location: `toolbar:${string}` | SciToolbarContributionLocation, toolbarFactoryFn: SciToolbarFactoryFn, options?: SciMenuContributionOptions): Disposable;
declare function contributeMenu(location: `menubar:${string}` | SciMenubarContributionLocation, menubarFactoryFn: SciMenubarFactoryFn, options?: SciMenuContributionOptions): Disposable;

/**
 * TODO [menu]: Explain how to size the toolbar. (height can be set; icon size by setting a CSS variable)
 *
 * TODO [menu]: Mention that component is :empty if no menu items, e.g., to hide empty toolbar:
 * ```scss
 * sci-toolbar:empty {
 *   display: none;
 * }
 * ```
 *
 * Control the toolbar item size by setting the `--sci-toolbar-item-size` CSS variable, globally in the document root or on a specific toolbar component. Defaults to 16px.
 */
declare class SciToolbarComponent {
    readonly name: _angular_core.InputSignal<`toolbar:${string}`>;
    readonly orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    readonly context: _angular_core.InputSignal<Map<string, unknown> | undefined>;
    readonly acceleratorTarget: _angular_core.InputSignal<MaybeArray<Element | ElementRef<Element>> | undefined>;
    readonly popoverViewContainerRef: _angular_core.InputSignal<ViewContainerRef>;
    private readonly _environmentContext;
    private readonly _context;
    protected readonly menuItems: _angular_core.Signal<_scion_components_menu.SciMenuItemLike[]>;
    constructor();
    /**
     * Installs accelerators of menu items in this toolbar, recursively for menu items in submenus and groups.
     */
    private installAccelerators;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SciToolbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SciToolbarComponent, "sci-toolbar", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "context": { "alias": "context"; "required": false; "isSignal": true; }; "acceleratorTarget": { "alias": "acceleratorTarget"; "required": false; "isSignal": true; }; "popoverViewContainerRef": { "alias": "popoverViewContainerRef"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * TODO [menu]: Explain how to size the menubar. (height can be set)
 */
declare class SciMenubarComponent {
    readonly name: _angular_core.InputSignal<`menubar:${string}`>;
    readonly context: _angular_core.InputSignal<Map<string, unknown> | undefined>;
    readonly acceleratorTarget: _angular_core.InputSignal<MaybeArray<Element | ElementRef<Element>> | undefined>;
    readonly viewContainerRef: _angular_core.InputSignal<ViewContainerRef | undefined>;
    private readonly _environmentContext;
    private readonly _context;
    protected readonly menuItems: Signal<SciMenuItem[]>;
    protected readonly activeMenuItem: _angular_core.WritableSignal<{
        menuItem: SciMenuItem;
        element: HTMLElement;
        closing?: true | "prevented";
    } | null>;
    constructor();
    /**
     * Method invoked when clicking on a menu item.
     */
    protected onMenuItemClick(menuItem: SciMenuItem, element: HTMLElement): void;
    /**
     * Method invoked before clicking on a menu item.
     *
     * When clicking on the active menu item, mark it as closing to prevent immediate re-opening race condition on subsequent click event.
     */
    protected onMenuItemMouseDown(menuItem: SciMenuItem): void;
    /**
     * Method invoked when moving the pointer over a menu item.
     */
    protected onMenuItemMouseEnter(menuItem: SciMenuItem, element: HTMLElement): void;
    /**
     * Method invoked when moving the pointer out of a menu item.
     */
    protected onMenuItemMouseLeave(menuItem: SciMenuItem): void;
    /**
     * Opens a menu based on {@link activeMenuItem}.
     */
    private installMenuOpener;
    /**
     * Installs accelerators of menu items in this menubar, recursively for menu items in submenus and groups.
     */
    private installAccelerators;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SciMenubarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SciMenubarComponent, "sci-menubar", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "context": { "alias": "context"; "required": false; "isSignal": true; }; "acceleratorTarget": { "alias": "acceleratorTarget"; "required": false; "isSignal": true; }; "viewContainerRef": { "alias": "viewContainerRef"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Registers a {@link SciMenuContextProviderFn} to provide context to menu locations and contributions.
 *
 * Provided context is applied to menu locations and contributions in the scope of the injector providing this function.
 * Individual locations and contributions can extend or override the provided context.
 *
 * Multiple providers can be registered. Providers at different injector tree levels form a hierarchy.
 *
 * @see SciMenuContextProviderFn
 */
declare function provideMenuContextProvider(providerFn: SciMenuContextProviderFn): Provider[];
/**
 * Registers a {@link SciMenuInjectionContextProviderFn} to provide dependency injection tokens for a given menu context.
 *
 * Provided tokens are available for dependency injection for contributions registered in the scope of the injector providing this function.
 * Tokens can be injected in the factory passed to {@link contributeMenu}.
 *
 * Multiple providers can be registered. Providers at different injector tree levels form a hierarchy.
 *
 * @see SciMenuInjectionContextProviderFn
 */
declare function provideMenuInjectionContextProvider(providerFn: SciMenuInjectionContextProviderFn): Provider[];
/**
 * Registers a {@link SciMenuAcceleratorTargetProviderFn} to provide accelerator targets to menu locations.
 *
 * Provided accelerator targets are available to menu locations in the scope of the injector providing this function.
 * Individual locations can override the provided targets.
 *
 * Multiple providers can be registered. Providers at different injector tree levels form a hierarchy.
 *
 * @see SciMenuAcceleratorTargetProviderFn
 */
declare function provideMenuAcceleratorTargetProvider(providerFn: SciMenuAcceleratorTargetProviderFn): Provider[];
/**
 * Signature of a function to provide context to menu locations and contributions.
 *
 * A menu location is a toolbar, menubar, or menu. A location or contribution can have a context (`Map`)
 * describing its environment. A contribution is eligible for a location only if the location's context fully
 * contains the contribution's context.
 *
 * Register this provider using the {@link provideMenuContextProvider} function.
 *
 * The function can call `inject` to get dependencies from the injector providing this function.
 *
 * @param callingInjector - Use to inject dependencies from the injector calling this function, e.g., the injector of the menu location.
 */
type SciMenuContextProviderFn = (callingInjector: Injector) => MaybeSignal<Map<string, unknown> | undefined>;
/**
 * Signature of a function to provide dependency injection tokens for a given menu context.
 *
 * The passed menu context is the context of a menu location (toolbar, menubar, or menu) describing its environment.
 * Returned tokens are available for dependency injection in the menu factory passed to {@link contributeMenu}.
 *
 * Register this provider using the {@link provideMenuInjectionContextProvider} function.
 *
 * The function can call `inject` to get any required dependencies.
 */
type SciMenuInjectionContextProviderFn = (context: Map<string, unknown>) => Provider[];
/**
 * Signature of a function to provide accelerator targets to menu locations.
 *
 * An accelerator target is a DOM element on which a menu location (toolbar, menubar, or menu) listens
 * for keyboard events for accelerators configured on menu items.
 *
 * Register this provider using the {@link provideMenuAcceleratorTargetProvider} function.
 *
 * The function can call `inject` to get dependencies from the injector providing this function.
 *
 * @param callingInjector - Use to inject dependencies from the injector calling this function, e.g., the injector of the menu location.
 */
type SciMenuAcceleratorTargetProviderFn = (callingInjector: Injector) => MaybeSignal<MaybeArray<Element | ElementRef<Element>> | undefined>;

/**
 * Injects dependency injection providers of the given menu context based on the current injection context.
 *
 * Must be called within an injection context, or an explicit {@link Injector} passed.
 *
 * @see provideMenuInjectionContextProvider
 * @docs-private Not public API. For internal use only.
 */
declare function injectMenuInjectionContextProviders(menuContext: Map<string, unknown>, options?: {
    injector?: Injector;
}): Provider[];

export { SciMenuAdapter, SciMenuService, SciMenubarComponent, SciToolbarComponent, contributeMenu, injectMenuInjectionContextProviders, installMenuAccelerators, provideMenuAcceleratorTargetProvider, provideMenuContextProvider, provideMenuInjectionContextProvider, provideMenuService, ɵSciMenuService };
export type { SciKeyboardAccelerator, SciMenuAcceleratorOptions, SciMenuAcceleratorTargetProviderFn, SciMenuAdapterChain, SciMenuContextProviderFn, SciMenuContribution, SciMenuContributionLocation, SciMenuContributionLocationLike, SciMenuContributionOptions, SciMenuContributionPosition, SciMenuContributionPositionLike, SciMenuDescriptor, SciMenuFactory, SciMenuFactoryFn, SciMenuFactoryFnLike, SciMenuFilterConfig, SciMenuGroup, SciMenuGroupDescriptor, SciMenuInjectionContextProviderFn, SciMenuItem, SciMenuItemDescriptor, SciMenuItemLike, SciMenuOptions, SciMenuOrigin, SciMenuRef, SciMenubarContributionLocation, SciMenubarContributionPosition, SciMenubarFactory, SciMenubarFactoryFn, SciMenubarMenuDescriptor, SciToolbarButtonDescriptor, SciToolbarContributionLocation, SciToolbarContributionPosition, SciToolbarControlDescriptor, SciToolbarFactory, SciToolbarFactoryFn, SciToolbarGroupDescriptor, SciToolbarMenuDescriptor };
