import * as i0 from '@angular/core';
import { Signal, Injector, Provider, DestroyableInjector, Binding, Type } from '@angular/core';
import { Observable } from 'rxjs';
import { ComponentType } from '@angular/cdk/portal';

declare function coerceSignal<T>(value: MaybeSignal<NonNullable<T>>): Signal<NonNullable<T>>;
declare function coerceSignal<T>(value: MaybeSignal<T> | undefined): Signal<NonNullable<T>> | undefined;
declare function coerceSignal<T>(value: MaybeSignal<T> | undefined, options: {
    defaultValue: T;
}): Signal<T>;
/**
 * Represents a value or a {@link Signal} of that value.
 */
type MaybeSignal<T> = T | Signal<T>;
/**
 * Like {@link toSignal}, but lazily creates the effect upon subscription, binding it to the subscription lifecycle instead of the injection context, plus, emits the signal's initial value synchronously.
 */
declare function toLazyObservable<T>(signal: MaybeSignal<NonNullable<T>>, options?: {
    injector?: Injector;
}): Observable<NonNullable<T>>;
declare function toLazyObservable<T>(signal: MaybeSignal<NonNullable<T>> | undefined, options?: {
    injector?: Injector;
}): Observable<NonNullable<T>> | undefined;

/**
 * Creates an injector that can be destroyed.
 *
 * Unlike when creating an injector using `Injector.create`, this injector also gets destroyed when the parent injector is destroyed,
 * plus, does not error when invoking destroyed if already destroyed.
 *
 * `parent`: (optional) A parent injector.
 * `name`: (optional) A developer-defined identifying name for the new injector.
 */
declare function createDestroyableInjector(options?: {
    parent?: Injector;
    providers?: Provider[];
    name?: string;
}): DestroyableInjector;
/**
 * Asserts that the current stack frame is within an injection context and has access to inject.
 *
 * Delegates to `assertInInjectionContext` from @angular/core, adding the given message to the error if the assertion fails.
 */
declare function assertInInjectionContext(debugFn: Function, message: string): void;

/**
 * Renders a component, similar to `ngComponentOutlet`, but with input bindings.
 *
 * Usage:
 *
 * ```html
 * <ng-container *sciComponentOutlet="descriptor"/>
 * ````
 *
 * @see WbComponentPortal
 */
declare class SciComponentOutletDirective {
    readonly descriptor: i0.InputSignal<SciComponentDescriptor | null | undefined>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SciComponentOutletDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SciComponentOutletDirective, "ng-template[sciComponentOutlet]", never, { "descriptor": { "alias": "sciComponentOutlet"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
interface SciComponentDescriptor {
    /** Directive type that should be created. */
    component: ComponentType<unknown>;
    /** Bindings that should be applied to the specific directive. */
    bindings?: Binding[];
    /**
     * Sets the injector for the instantiation of the component, giving control over the objects available for injection.
     *
     * **Example:**
     * ```ts
     * Injector.create({
     *   parent: ...,
     *   providers: [
     *    {provide: <TOKEN>, useValue: <VALUE>}
     *   ],
     * })
     * ```
     */
    directives?: Array<Type<unknown> | {
        type: Type<unknown>;
        bindings: Binding[];
    }>;
    injector?: Injector;
    /**
     * Specifies providers available for injection in the component.
     */
    providers?: Provider[];
    /**
     * Specifies CSS class(es) to add to the component, e.g., to locate the component in tests.
     */
    cssClass?: MaybeSignal<string | string[]>;
    /**
     * Specifies attributes to add to the component.
     */
    attributes?: MaybeSignal<{
        [name: string]: string | undefined;
    }>;
}

/**
 * Adds specified attributes to the host element.
 */
declare class SciAttributesDirective {
    readonly attributes: i0.InputSignal<{
        [name: string]: string | null | undefined;
    } | null | undefined>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SciAttributesDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SciAttributesDirective, "[sciAttributes]", never, { "attributes": { "alias": "sciAttributes"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { SciAttributesDirective, SciComponentOutletDirective, assertInInjectionContext, coerceSignal, createDestroyableInjector, toLazyObservable };
export type { MaybeSignal, SciComponentDescriptor };
