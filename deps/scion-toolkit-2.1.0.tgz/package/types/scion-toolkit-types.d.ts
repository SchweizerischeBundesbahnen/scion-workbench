import { Observable } from 'rxjs';

/**
 * Requires at least one key from T.
 */
type RequireOne<T> = {
    [K in keyof T]: Required<Pick<T, K>> & Partial<Omit<T, K>>;
}[keyof T];
/**
 * Allows maximum one property of T.
 */
type OneOf<T> = {
    [K in keyof T]: {
        [P in K]: T[P];
    } & {
        [P in Exclude<keyof T, K>]?: never;
    };
}[keyof T];
/**
 * Represents a value or an array of that value.
 */
type MaybeArray<T> = T | T[];
type MaybeObservable<T> = T | Observable<T>;
/**
 * Represents an object that can be disposed of to free up resources.
 */
interface Disposable {
    /**
     * Disposes of the object, releasing any allocated resources.
     */
    dispose(): void;
}
/**
 * Signature of a function to clean up allocated resources.
 */
type DisposeFn = () => void;

export type { Disposable, DisposeFn, MaybeArray, MaybeObservable, OneOf, RequireOne };
