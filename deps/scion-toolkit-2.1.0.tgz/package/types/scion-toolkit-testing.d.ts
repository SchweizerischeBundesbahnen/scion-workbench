import { Observer } from 'rxjs';

/**
 * Allows capturing emissions of an Observable.
 */
declare class ObserveCaptor<T = any, R = T> implements Observer<T> {
    private readonly _projectFn;
    private _values;
    private _state;
    private _error;
    private _completeOrError$;
    private _emitCount$;
    /**
     * Constructs this captor. Optionally, you can provide a project function to map emitted values.
     */
    constructor(projectFn?: (value: T) => R);
    /**
     * @docs-private
     *
     * Note: Write as arrow function to retain the `this` reference when being invoked from another scope, e.g., from the global scope.
     */
    next: (value: T) => void;
    /**
     * @docs-private
     *
     * Note: Write as arrow function to retain the `this` reference when being invoked from another scope, e.g., from the global scope.
     */
    error: (error: unknown) => void;
    /**
     * @docs-private
     *
     * Note: Write as arrow function to retain the `this` reference when being invoked from another scope, e.g., from the global scope.
     */
    complete: () => void;
    /**
     * Returns captured values in the order as emitted by the Observable.
     */
    getValues(): R[];
    /**
     * Returns the last captured value, if any.
     */
    getLastValue(): R | undefined;
    /**
     * Returns the error if the Observable errored.
     */
    getError(): any;
    /**
     * Indicates if the Observable completed. An Observable can either complete or error.
     */
    hasCompleted(): boolean;
    /**
     * Indicates if the Observable errored. An Observable can either complete or error.
     */
    hasErrored(): boolean;
    /**
     * Resets this captor.
     *
     * Pass options to control which aspects of this captor not to reset. By default, all aspects are reset.
     */
    reset(options?: {
        resetValues?: boolean;
        resetEmitCount?: boolean;
    }): this;
    /**
     * Waits until the Observable emits the given number of items, or throws if the given timeout elapses.
     */
    waitUntilEmitCount(count: number, timeoutMs?: number): Promise<void>;
    /**
     * Waits until the Observable completes or errors.
     */
    waitUntilCompletedOrErrored(): Promise<void>;
}

/**
 * Executes the given function, retrying execution if it throws an error. If the maximum timeout is exceeded, the error is re-thrown.
 *
 * @returns Promise that resolves to the result of the function.
 */
declare function retryOnError<T>(fn: () => Promise<T> | T, options?: {
    timeout?: number;
    interval?: number;
}): Promise<T>;

export { ObserveCaptor, retryOnError };
