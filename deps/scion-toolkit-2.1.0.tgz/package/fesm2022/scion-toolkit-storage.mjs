import { Subject, fromEvent, EMPTY, of, Observable, merge } from 'rxjs';
import { filter, mergeMap, startWith, distinctUntilChanged, takeUntil, map } from 'rxjs/operators';

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Allows observing items contained in web storage (local storage or session storage).
 *
 * Items are added in the JSON format to the storage.
 *
 * Because web storage does not notify about same document storage changes, always use {@link WebStorage#put}
 * to add items to the storage, or {@link WebStorage#remove} to remove items from the storage.
 *
 * #### Storage implementors:
 * - Local storage:
 *   Maintains a persistent storage area per origin.
 * - Session storage:
 *   Maintains a separate storage area per origin that is available for the duration of the page session
 *   (as long as the browser is open, including page reloads and restores).
 */
class WebStorage {
    _storage;
    _currentDocumentChange$ = new Subject();
    /**
     * Provide the storage implementor: {@link window.localStorage} or {@link window.sessionStorage}.
     */
    constructor(_storage) {
        this._storage = _storage;
    }
    /**
     * Puts the given item into storage. The item is serialized to JSON.
     */
    put(key, value) {
        if (value === undefined || value === null) {
            this._storage.setItem(key, `${value}`); // preserve `null` and `undefined`
        }
        else {
            this._storage.setItem(key, JSON.stringify(value));
        }
        this._currentDocumentChange$.next(key);
    }
    /**
     * Puts the given item into storage, but only if not present. The item is serialized to JSON.
     *
     * Instead of an item you can pass a provider function to produce the item.
     */
    putIfAbsent(key, value) {
        if (!this.isPresent(key)) {
            this.put(key, typeof value === 'function' ? value() : value);
        }
    }
    /**
     * Returns the item associated with the given key, or `undefined` if not found.
     *
     * Expects the value to be stored in JSON format. Throws an error if the value cannot be parsed.
     */
    get(key) {
        const item = this._storage.getItem(key);
        // Web storage returns `null` if there is no item associated with the key.
        if (item === null) {
            return undefined;
        }
        // If the value `undefined` is associated with the key, web storage returns 'undefined' as string.
        if (item === 'undefined') {
            return undefined;
        }
        // If the value `null` is associated with the key, web storage returns 'null' as string.
        if (item === 'null') {
            return null;
        }
        return JSON.parse(item);
    }
    /**
     * Removes the item associated with the given key.
     */
    remove(key) {
        this._storage.removeItem(key);
        this._currentDocumentChange$.next(key);
    }
    /**
     * Checks if an item is present in the storage. Present also includes `null` and `undefined` items.
     */
    isPresent(key) {
        return this._storage.getItem(key) !== null; // storage returns `null` if not present
    }
    /**
     * Observes the item associated with the given key.
     *
     * Upon subscription, it emits the current item from the storage, but, by default, only if present,
     * and then continuously emits when the item associated with the given key changes. It never completes.
     *
     * When removing the item from the storage, by default, the Observable does not emit.
     *
     * Set `emitIfAbsent` to `true` if to emit `undefined` when removing the item, or if there is no item associated
     * with the given key upon subscription. By default, `emitIfAbsent` is set to `false`.
     */
    observe$(key, options) {
        const emitIfAbsent = options?.emitIfAbsent ?? false;
        const otherDocumentChange$ = fromEvent(window, 'storage')
            .pipe(filter(event => event.storageArea === this._storage), mergeMap(event => event.key !== null ? of(event.key) : EMPTY));
        return new Observable((observer) => {
            const unsubscribe$ = new Subject();
            merge(this._currentDocumentChange$, otherDocumentChange$)
                .pipe(filter(itemKey => itemKey === key), startWith(key), mergeMap(itemKey => {
                if (!this.isPresent(itemKey)) {
                    return emitIfAbsent ? of(undefined) : EMPTY;
                }
                try {
                    return of(this.get(itemKey));
                }
                catch (error) {
                    console.warn(`Failed to parse item from storage. Invalid JSON. [key=${itemKey}]`, error);
                    return EMPTY;
                }
            }), distinctUntilChanged(), takeUntil(unsubscribe$))
                .subscribe(observer);
            return () => {
                unsubscribe$.next();
            };
        });
    }
    /**
     * Notifies when no item is present for the given key. The Observable never completes.
     */
    absent$(key) {
        return this.observe$(key, { emitIfAbsent: true })
            .pipe(filter(() => !this.isPresent(key)), map(() => undefined));
    }
}

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/*
 * Secondary entrypoint: '@scion/toolkit/storage'
 *
 * @see https://github.com/ng-packagr/ng-packagr/blob/master/docs/secondary-entrypoints.md
 */

/**
 * Generated bundle index. Do not edit.
 */

export { WebStorage };
//# sourceMappingURL=scion-toolkit-storage.mjs.map
