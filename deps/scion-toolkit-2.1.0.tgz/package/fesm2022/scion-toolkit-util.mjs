import { identity, Observable, from, of } from 'rxjs';

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides utility methods to work with `undefined` values. The value `null` is considered as a defined value.
 *
 * Note: TypeScript 3.7 introduces the `nullish coalescing operator` [1] `(??)`, which is similar to the `Defined` function,
 * but also applies for `null` values.
 *
 * ## Links:
 * [1] https://www.typescriptlang.org/docs/handbook/release-notes/typescript-3-7.html#nullish-coalescing
 */
var Defined;
(function (Defined) {
    /**
     * Returns the value if not `undefined`, otherwise "orElseValue". The "orElseValue" value can be created with a factory function.
     *
     * Unlike JavaScript's "nullish coalescing operator (??)", the "orElse" function only tests for `undefined`, not `null`.
     */
    function orElse(value, orElseValue) {
        return (value !== undefined ? value : (typeof orElseValue === 'function' ? orElseValue() : orElseValue)); // eslint-disable-line @typescript-eslint/prefer-nullish-coalescing
    }
    Defined.orElse = orElse;
    /**
     * Returns the value if not `undefined`, otherwise throws the error created by the passed factory function.
     */
    function orElseThrow(value, orElseThrowFn) {
        if (value !== undefined) {
            return value;
        }
        throw orElseThrowFn();
    }
    Defined.orElseThrow = orElseThrow;
})(Defined || (Defined = {}));

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides array utility methods.
 */
var Arrays;
(function (Arrays) {
    function coerce(value, options) {
        if (value === null || value === undefined) {
            if (options?.coerceNullOrUndefined ?? true) {
                return [];
            }
            return value;
        }
        return Array.isArray(value) ? value : [value];
    }
    Arrays.coerce = coerce;
    /**
     * Compares items of given arrays for reference equality.
     *
     * Use the parameter `exactOrder` to control if the item order must be equal (which is by default) or not.
     *
     * @deprecated since version 2.1.0; use {@link Objects.isEqual} instead; API will be removed in version 3.0.0.
     */
    function isEqual(array1, array2, options) {
        if (array1 === array2) {
            return true;
        }
        if (!array1 || !array2) {
            return false;
        }
        if (array1.length !== array2.length) {
            return false;
        }
        if (options?.exactOrder ?? true) {
            return array1.every((item, index) => item === array2[index]);
        }
        return array1.every(item => array2.includes(item)) && array2.every(item => array1.includes(item));
    }
    Arrays.isEqual = isEqual;
    /**
     * Removes the specified element from an array, or the elements which satisfy the provided predicate function.
     * The original array will be changed.
     *
     * @param  array - The array from which elements should be removed.
     * @param  element - The element to be removed, or a predicate function to resolve elements which to be removed.
     * @param  options - Control if to remove all occurrences of the element. If not specified, all occurrences are removed.
     * @return the elements removed from the array.
     */
    function remove(array, element, options) {
        const firstOnly = options?.firstOnly ?? false;
        // define a function to resolve the element's index in the original array
        const indexOfElementFn = (() => {
            if (typeof element === 'function') {
                const predicate = element;
                return () => array.findIndex(predicate);
            }
            else {
                return () => array.indexOf(element);
            }
        })();
        const removedElements = [];
        for (let i = indexOfElementFn(); i !== -1; i = indexOfElementFn()) {
            removedElements.push(...array.splice(i, 1)); // changes the original array
            if (firstOnly) {
                break;
            }
        }
        return removedElements;
    }
    Arrays.remove = remove;
    /**
     * Removes duplicate items from the array. The original array will not be modified.
     *
     * Use the parameter `keySelector` to provide a function for comparing objects.
     */
    function distinct(items, keySelector = identity) {
        const itemSet = new Set(items.map(keySelector));
        return items.filter(item => itemSet.delete(keySelector(item)));
    }
    Arrays.distinct = distinct;
    /**
     * Intersects the given arrays, returning a new array containing all the elements contained in every array.
     * Arrays which are `undefined` or `null` are ignored.
     */
    function intersect(...arrays) {
        const _arrays = arrays.filter(array => array !== undefined && array !== null);
        if (!_arrays.length) {
            return [];
        }
        const first = _arrays.pop();
        return _arrays.reduce((intersection, array) => intersection.filter(value => array.includes(value)), [...first]);
    }
    Arrays.intersect = intersect;
    /**
     * Returns the last element in the given array, optionally matching the predicate if given.
     *
     * Returns `undefined` if no element is found.
     */
    function last(array, predicate) {
        if (!array?.length) {
            return undefined;
        }
        if (!predicate) {
            return array.at(-1);
        }
        for (let i = array.length - 1; i >= 0; i--) {
            if (predicate(array[i])) {
                return array[i];
            }
        }
        return undefined;
    }
    Arrays.last = last;
})(Arrays || (Arrays = {}));

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides helper functions for working with objects.
 */
const Objects = {
    /**
     * Compares two objects for deep equality.
     *
     * Supported types: Record, Array, Map, Set, and primitives.
     *
     * The property order is ignored when comparing records. The element order in arrays is relevant unless specified otherwise in options.
     *
     * @param a - The first object to compare.
     * @param b - The second object to compare.
     * @param options - Controls how to compare two objects.
     * @param options.ignoreArrayOrder - Controls whether to ignore the element order when comparing arrays. By default, the order is not ignored.
     * @return `true` if objects are equal, false otherwise.
     */
    isEqual: (a, b, options) => {
        if (a === b) {
            return true;
        }
        if (!a || !b) {
            return false;
        }
        if (typeof a !== 'object' || typeof b !== 'object') {
            return false;
        }
        // Map equality
        if (a instanceof Map || b instanceof Map) {
            if (!(a instanceof Map) || !(b instanceof Map)) {
                return false;
            }
            if (a.size !== b.size) {
                return false;
            }
            return [...a.entries()].every(([key, value]) => b.has(key) && Objects.isEqual(value, b.get(key), options));
        }
        // Set equality
        if (a instanceof Set || b instanceof Set) {
            if (!(a instanceof Set) || !(b instanceof Set)) {
                return false;
            }
            if (a.size !== b.size) {
                return false;
            }
            return [...a].every(value => [...b].some(other => Objects.isEqual(value, other, options)));
        }
        // Array equality
        const ignoreArrayOrder = options?.ignoreArrayOrder ?? false;
        if (Array.isArray(a) || Array.isArray(b)) {
            if (!(Array.isArray(a)) || !(Array.isArray(b))) {
                return false;
            }
            if (a.length !== b.length) {
                return false;
            }
            if (ignoreArrayOrder) {
                return a.every(value => b.some(other => Objects.isEqual(value, other, options))) && b.every(value => a.some(other => Objects.isEqual(value, other, options)));
            }
            else {
                return a.every((value, index) => Objects.isEqual(value, b[index], options));
            }
        }
        // Object literal equality
        const aKeys = Object.keys(a);
        const bKeys = Object.keys(b);
        if (aKeys.length !== bKeys.length) {
            return false;
        }
        return aKeys.every(key => Objects.isEqual(a[key], b[key], options));
    },
    /**
     * Stringifies given object to matrix notation: a=b;c=d;e=f
     */
    toMatrixNotation: (object) => {
        return Object.entries(object ?? {}).map(([key, value]) => `${key}=${value}`).join(';');
    },
    /**
     * Like {@link Object.keys}, but preserving the data type of keys.
     */
    keys: (object) => {
        return Object.keys(object);
    },
    /**
     * Like {@link Object.values}, but preserving the data type of values and supporting optional properties.
     */
    values: (object) => {
        return Object.values(object);
    },
    /**
     * Like {@link Object.entries}, but preserving the data type of keys and supporting optional properties.
     */
    entries: (object) => {
        return Object.entries(object);
    },
};

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides utilities for a dictionary.
 */
var Dictionaries;
(function (Dictionaries) {
    function coerce(dictionaryLike, options) {
        if (!dictionaryLike) {
            const orElseEmpty = options?.coerceNullOrUndefined ?? true;
            return orElseEmpty ? {} : dictionaryLike;
        }
        if (Symbol.iterator in dictionaryLike) {
            return Object.fromEntries(dictionaryLike);
        }
        return dictionaryLike;
    }
    Dictionaries.coerce = coerce;
    /**
     * Returns a new {@link Dictionary} with `undefined` values removed.
     */
    function withoutUndefinedEntries(object) {
        return Object.entries(object).reduce((dictionary, [key, value]) => {
            if (value !== undefined) {
                dictionary[key] = value;
            }
            return dictionary;
        }, {});
    }
    Dictionaries.withoutUndefinedEntries = withoutUndefinedEntries;
})(Dictionaries || (Dictionaries = {}));

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides utilities for {@link Map}.
 */
var Maps;
(function (Maps) {
    function coerce(mapLike, options) {
        if (!mapLike) {
            const orElseEmpty = options?.coerceNullOrUndefined ?? true;
            return orElseEmpty ? new Map() : mapLike;
        }
        if (mapLike instanceof Map) {
            return mapLike;
        }
        if (Symbol.iterator in mapLike) {
            return new Map(mapLike);
        }
        return new Map(Object.entries(mapLike));
    }
    Maps.coerce = coerce;
    /**
     * Adds the given value into a {@link Set} in the multi value {@link Map}.
     */
    function addSetValue(multiValueMap, key, value) {
        const values = multiValueMap.get(key) ?? new Set();
        return multiValueMap.set(key, values.add(value));
    }
    Maps.addSetValue = addSetValue;
    /**
     * Removes the given value or values matching the given predicate from the multi {@link Map}.
     *
     * @return `true` if the element was removed, or `false` otherwise.
     */
    function removeSetValue(multiValueMap, key, value) {
        const values = multiValueMap.get(key) ?? new Set();
        let hasRemoved;
        if (typeof value === 'function') {
            const predicateFn = value;
            hasRemoved = Array.from(values)
                .filter(predicateFn)
                .reduce((removed, it) => values.delete(it) || removed, false);
        }
        else {
            hasRemoved = values.delete(value);
        }
        if (hasRemoved && !values.size) {
            multiValueMap.delete(key);
        }
        return hasRemoved;
    }
    Maps.removeSetValue = removeSetValue;
    /**
     * Adds the given value into an {@link Array} in the multi value {@link Map}.
     */
    function addListValue(map, key, value) {
        const values = map.get(key) ?? [];
        return map.set(key, values.concat(value));
    }
    Maps.addListValue = addListValue;
    /**
     * Removes the given value or values matching the given predicate from the multi {@link Map}.
     *
     * @return `true` if the element was removed, or `false` otherwise.
     */
    function removeListValue(multiValueMap, key, value) {
        const values = multiValueMap.get(key) ?? [];
        const hasRemoved = Arrays.remove(values, value, { firstOnly: false }).length > 0;
        if (hasRemoved && !values.length) {
            multiValueMap.delete(key);
        }
        return hasRemoved;
    }
    Maps.removeListValue = removeListValue;
})(Maps || (Maps = {}));

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
var Observables;
(function (Observables) {
    /**
     * Creates an `Observable` from the passed value, which will emit the value and then complete,
     * or, if passing an `Observable`, returns it unchanged. If passing a `Promise`, it is converted
     * to an `Observable`.
     */
    function coerce(value) {
        if (value instanceof Observable) {
            return value;
        }
        if (value instanceof Promise) {
            return from(value);
        }
        return of(value);
    }
    Observables.coerce = coerce;
})(Observables || (Observables = {}));

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
function prune(object, options) {
    const pruneIfEmpty = options?.pruneIfEmpty ?? false;
    if (object === null || object instanceof Map || object instanceof Set || Array.isArray(object)) {
        return object;
    }
    if (typeof object === 'object') {
        Object.entries(object).forEach(([key, value]) => {
            if (prune(value, { pruneIfEmpty }) === undefined) {
                delete object[key]; // eslint-disable-line @typescript-eslint/no-dynamic-delete
            }
        });
        if (!Object.keys(object).length && pruneIfEmpty) {
            return undefined;
        }
    }
    return object;
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
function runSafe(fn, onErrorFn) {
    try {
        return fn();
    }
    catch (error) {
        if (onErrorFn) {
            return onErrorFn(error);
        }
        else {
            console.error('[UnexpectedError] An unexpected error occurred.', error);
        }
    }
}

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/*
 * Secondary entrypoint: '@scion/toolkit/util'
 * This module does not depend on Angular.
 *
 * @see https://github.com/ng-packagr/ng-packagr/blob/master/docs/secondary-entrypoints.md
 */

/**
 * Generated bundle index. Do not edit.
 */

export { Arrays, Defined, Dictionaries, Maps, Objects, Observables, prune, runSafe };
//# sourceMappingURL=scion-toolkit-util.mjs.map
