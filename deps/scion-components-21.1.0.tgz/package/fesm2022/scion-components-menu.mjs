import * as i0 from '@angular/core';
import { untracked, Injectable, inject, Injector, computed, runInInjectionContext, signal, makeEnvironmentProviders, NgZone, effect, DOCUMENT, isSignal, Pipe, input, EnvironmentInjector, ElementRef, ApplicationRef, createComponent, inputBinding, ChangeDetectionStrategy, Component, model, viewChild, DestroyRef, viewChildren, linkedSignal, ViewContainerRef, InjectionToken, Directive, assertNotInReactiveContext, assertInInjectionContext as assertInInjectionContext$1 } from '@angular/core';
import * as i1$1 from '@scion/components/common';
import { coerceSignal, createDestroyableInjector, SciComponentOutletDirective, SciAttributesDirective, assertInInjectionContext } from '@scion/components/common';
import { Objects, Arrays, prune, Maps } from '@scion/toolkit/util';
import { text, SciTextPipe } from '@scion/components/text';
import { merge, fromEvent, firstValueFrom, subscribeOn, animationFrameScheduler, filter, map } from 'rxjs';
import { subscribeIn } from '@scion/toolkit/operators';
import { coerceElement } from '@angular/cdk/coercion';
import * as i1 from '@angular/forms';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SciIconComponent } from '@scion/components/icon';
import { NgTemplateOutlet } from '@angular/common';
import { SciViewportComponent } from '@scion/components/viewport';
import { fromResize$ } from '@scion/toolkit/observable';
import { dimension } from '@scion/components/dimension';
import { UUID } from '@scion/toolkit/uuid';

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
function translate(translatable) {
    return translatable !== undefined ? untracked(() => text(translatable)) : undefined;
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides a context for contributions and locations such as toolbars and context menus.
 *
 * The provided environment context is used as the "required" context for contributions and the "available" context for locations.
 *
 * Contributions and locations can override or extend the context.
 *
 * Can be registered via {@link provideMenuEnvironmentProvider}.
 *
 * @see provideMenuEnvironmentProvider
 */
class SciMenuEnvironmentProvider {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuEnvironmentProvider, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuEnvironmentProvider });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuEnvironmentProvider, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides the environment for menus based on registered menu environment providers.
 *
 * @docs-private Not public API. For internal use only.
 */
class SciMenuEnvironmentProviders {
    // TODO [Angular 22] Remove cast when Angular supports type safety for multi-injection with abstract class DI tokens. See https://github.com/angular/angular/issues/55555
    _environmentProviders = inject(SciMenuEnvironmentProvider, { optional: true }) ?? [];
    provideContext(context, options) {
        const injector = options?.injector ?? inject(Injector);
        const providers = [
            ...this._environmentProviders,
            { provideContext: () => computed(() => coerceSignal(context)?.() ?? new Map()) }, // higher precedence
        ];
        return providers.reduce((accumulatedContext, provider) => {
            const context = coerceSignal(runInInjectionContext(injector, () => provider.provideContext?.()) ?? new Map());
            return computed(() => new Map([...accumulatedContext(), ...context()]), { equal: Objects.isEqual });
        }, signal(new Map()));
    }
    provideInjectionContext(menuContext) {
        return this._environmentProviders.flatMap(provider => provider.provideInjectionContext?.(menuContext) ?? []);
    }
    provideAcceleratorTargets(options) {
        const injector = options?.injector ?? inject(Injector);
        return this._environmentProviders.reduce((accumulatedTargets, environmentProvider) => {
            const acceleratorTargets = coerceSignal(runInInjectionContext(injector, () => environmentProvider.provideAcceleratorTargets?.()));
            return computed(() => [
                ...accumulatedTargets(),
                ...Arrays.coerce(acceleratorTargets?.()).map(coerceElement),
            ]);
        }, signal(new Array()));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuEnvironmentProviders, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuEnvironmentProviders, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuEnvironmentProviders, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * @see SciMenuEnvironmentProvider
 */
function provideMenuEnvironmentProvider(menuEnvironmentProvider) {
    return makeEnvironmentProviders([
        {
            provide: SciMenuEnvironmentProvider,
            useClass: menuEnvironmentProvider,
            multi: true,
        },
    ]);
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * INPUTS FOR DOCUMENTING THIS FUNCTION:
 *
 * Installs accelerator keys of specified menu items on specified element.
 *
 * Accelerators are strings that can be used to represent keyboard shortcuts throughout your Electron. These strings can contain multiple modifier keys and a single key code joined by the + character.
 *
 * Represents a keyboard shortcut (or accelerator) that lets a user perform an action using the keyboard instead of navigating the app UI (directly or through access keys).
 *
 * An accelerator key can be a single key, such as F1 - F12 and Esc, or a combination of keys (Ctrl + Shift + B, or Ctrl C) that invoke a command. They differ from access keys (mnemonics), which are typically modified with the Alt key and simply activate a command or control.
 *
 * Unsubscribes from keyboard events when the injection context is destroyed.
 *
 * TODO [menu] consider renaming to registerAccelerator (like in electron)
 */
function installMenuAccelerators(location, options) {
    const injector = createDestroyableInjector({ parent: options?.injector ?? inject(Injector) });
    return runInInjectionContext(injector, () => {
        const zone = inject(NgZone);
        const context = inject(SciMenuEnvironmentProviders).provideContext(options?.context);
        const menuItems = inject(ɵSciMenuService).menuItems(location, context, { metadata: options?.metadata });
        const acceleratorTargets = computeAcceleratorTargets(options);
        effect(onCleanup => {
            const accelerators = collectAccelerators(menuItems());
            if (!accelerators.length) {
                return;
            }
            const targets = acceleratorTargets();
            untracked(() => {
                const subscription = merge(...targets.map(target => fromEvent(target, 'keydown')))
                    .pipe(subscribeIn(fn => zone.runOutsideAngular(fn)))
                    .subscribe(event => {
                    // Skip if only pressing a modifier key.
                    switch (event.key) {
                        case 'Control':
                        case 'Shift':
                        case 'Alt':
                        case 'AltGraph':
                            return;
                        // UNDOCUMENTED: `event.key` can be `undefined`, for example, when selecting an option from an input element's datalist.
                        // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
                        case undefined:
                            return;
                    }
                    // Skip if not pressing a modifier key. Accelerators must have a modifier key.
                    if (!event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey && !allowedSingleKeys.has(event.key.toLowerCase())) {
                        return;
                    }
                    const matchingMenuItems = accelerators.filter(menuItem => {
                        return !menuItem.disabled?.() && matchesAccelerator(event, menuItem.accelerator);
                    });
                    if (!matchingMenuItems.length) {
                        return;
                    }
                    event.preventDefault();
                    event.stopPropagation();
                    // Execute action.
                    zone.run(() => matchingMenuItems.forEach(menuItem => void menuItem.onSelect()));
                });
                onCleanup(() => subscription.unsubscribe());
            });
        });
        return {
            dispose: () => injector.destroy(),
        };
    });
}
function computeAcceleratorTargets(options) {
    const acceleratorTargets = Arrays.coerce(options?.target).map(coerceElement);
    if (acceleratorTargets.length) {
        return signal(acceleratorTargets);
    }
    const environmentAcceleratorTargets = inject(SciMenuEnvironmentProviders).provideAcceleratorTargets();
    const document = inject(DOCUMENT);
    return computed(() => environmentAcceleratorTargets().length ? environmentAcceleratorTargets() : [document]);
}
/**
 * Returns a flat list of all menu items that have an accelerator.
 */
function collectAccelerators(menuItemLikes) {
    return menuItemLikes.reduce((menuItems, menuItemLike) => {
        switch (menuItemLike.type) {
            case 'menu-item': {
                return menuItems
                    .concat(menuItemLike.accelerator ? menuItemLike : [])
                    .concat(collectAccelerators(menuItemLike.actions ?? []))
                    .concat(collectAccelerators(menuItemLike.menu?.children ?? []));
            }
            case 'group': {
                return menuItems
                    .concat(collectAccelerators(menuItemLike.children))
                    .concat(collectAccelerators(menuItemLike.actions ?? []));
            }
        }
    }, new Array());
}
/**
 * Validates the passed menu accelerator to have a modifier, unless a function key, 'Delete', or 'Escape'.
 */
function validateMenuAccelerator(accelerator) {
    if (!accelerator) {
        return undefined;
    }
    if (!accelerator.ctrl && !accelerator.alt && !accelerator.shift && !allowedSingleKeys.has(accelerator.key.toLowerCase())) {
        console.warn(`[MenuDefinitionError] Illegal menu accelerator. The key '${accelerator.key}' requires a modifier such as 'Ctrl', 'Shift', or 'Alt'. Only function keys F1-F12 and 'Delete' are allowed without a modifier. Examples: ['ctrl', 's'], ['F5'].`);
        return undefined;
    }
    return accelerator;
}
/**
 * Tests if the given keyboard event matches the specified accelerator.
 */
function matchesAccelerator(event, accelerator) {
    if (accelerator.key.toLowerCase() !== event.key.toLowerCase()) {
        return false;
    }
    // Handles Meta key as the Control key modifier as on Apple devices the Command (⌘) key is used instead of the Control (Ctrl) key.
    if ((accelerator.ctrl ?? false) !== (event.ctrlKey || event.metaKey)) {
        return false;
    }
    if ((accelerator.shift ?? false) !== event.shiftKey) {
        return false;
    }
    if ((accelerator.alt ?? false) !== event.altKey) {
        return false;
    }
    if (accelerator.location === 'left' && event.location !== 1) {
        return false;
    }
    if (accelerator.location === 'right' && event.location !== 2) {
        return false;
    }
    if (accelerator.location === 'numpad' && event.location !== 3) {
        return false;
    }
    return true;
}
/**
 * Keys that can be used without a modifier (ctrl, alt, shift).
 */
const allowedSingleKeys = new Set([
    ...Array.from(Array(20).keys()).map(i => `f${i + 1}`), // F1 - F20
    'delete',
]);

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Translation note: Texts are translated when added (not lazily when rendered) to simplify filtering.
 */
class ɵSciToolbarFactory {
    menuItems = [];
    /** @inheritDoc */
    addToolbarButton(descriptor) {
        this.menuItems.push({
            type: 'menu-item',
            name: descriptor.name,
            labelText: translate(coerceLabelText$1(descriptor.label)),
            labelComponent: coerceLabelComponent$1(descriptor.label),
            iconLigature: coerceSignal(coerceIconLigature$1(descriptor.icon)),
            iconComponent: coerceIconComponent$1(descriptor.icon),
            checked: coerceSignal(descriptor.checked),
            tooltip: translate(descriptor.tooltip),
            accelerator: validateMenuAccelerator(descriptor.accelerator),
            disabled: coerceSignal(descriptor.disabled),
            cssClass: Arrays.coerce(descriptor.cssClass),
            attributes: descriptor.attributes,
            onSelect: async () => await descriptor.onSelect() ?? descriptor.checked === undefined, // Returning `true` will close the popover. Non-checkable items close by default.
        });
        return this;
    }
    /** @inheritDoc */
    addToolbarSplitButton(descriptor, menuFactoryFn) {
        this.menuItems.push({
            type: 'menu-item',
            name: descriptor.name,
            labelText: translate(coerceLabelText$1(descriptor.label)),
            labelComponent: coerceLabelComponent$1(descriptor.label),
            iconLigature: coerceSignal(coerceIconLigature$1(descriptor.icon)),
            iconComponent: coerceIconComponent$1(descriptor.icon),
            checked: coerceSignal(descriptor.checked),
            tooltip: translate(descriptor.tooltip),
            accelerator: validateMenuAccelerator(descriptor.accelerator),
            disabled: coerceSignal(descriptor.disabled),
            cssClass: Arrays.coerce(descriptor.cssClass),
            attributes: descriptor.attributes,
            menu: constructMenu(menuFactoryFn, descriptor.menu),
            onSelect: async () => await descriptor.onSelect() ?? descriptor.checked === undefined, // Returning `true` will close the popover. Non-checkable items close by default.
        });
        return this;
    }
    /** @inheritDoc */
    addToolbarMenu(descriptor, menuFactoryFn) {
        this.menuItems.push({
            type: 'menu-item',
            name: descriptor.name,
            labelText: translate(coerceLabelText$1(descriptor.label)),
            labelComponent: coerceLabelComponent$1(descriptor.label),
            iconLigature: coerceSignal(coerceIconLigature$1(descriptor.icon)),
            iconComponent: coerceIconComponent$1(descriptor.icon),
            tooltip: translate(descriptor.tooltip),
            disabled: coerceSignal(descriptor.disabled),
            visualMenuHint: descriptor.visualMenuHint,
            cssClass: Arrays.coerce(descriptor.cssClass),
            attributes: descriptor.attributes,
            menu: constructMenu(menuFactoryFn, descriptor.menu),
        });
        return this;
    }
    /** @inheritDoc */
    addToolbarControl(descriptor) {
        this.menuItems.push({
            type: 'menu-item',
            name: descriptor.name,
            control: {
                component: descriptor.component,
                bindings: descriptor.bindings,
                injector: descriptor.injector,
                providers: descriptor.providers,
            },
            tooltip: translate(descriptor.tooltip),
            cssClass: Arrays.coerce(descriptor.cssClass),
            attributes: descriptor.attributes,
        });
        return this;
    }
    /** @inheritDoc */
    addToolbarSplitControl(descriptor, menuFactoryFn) {
        this.menuItems.push({
            type: 'menu-item',
            name: descriptor.name,
            control: {
                component: descriptor.component,
                bindings: descriptor.bindings,
                injector: descriptor.injector,
                providers: descriptor.providers,
            },
            tooltip: translate(descriptor.tooltip),
            cssClass: Arrays.coerce(descriptor.cssClass),
            attributes: descriptor.attributes,
            menu: constructMenu(menuFactoryFn, descriptor.menu),
        });
        return this;
    }
    addGroup(factoryOrDescriptor, factoryIfDescriptor) {
        const [descriptor, groupFactoryFn] = coerceGroupDescriptor$1(factoryOrDescriptor, factoryIfDescriptor);
        // Construct group.
        const groupFactory = new ɵSciToolbarFactory();
        groupFactoryFn?.(groupFactory);
        // Add group.
        this.menuItems.push({
            type: 'group',
            name: descriptor.name,
            disabled: coerceSignal(descriptor.disabled),
            children: groupFactory.menuItems,
            cssClass: Arrays.coerce(descriptor.cssClass),
        });
        return this;
    }
}
function coerceGroupDescriptor$1(factoryOrDescriptor, factoryIfDescriptor) {
    if (typeof factoryOrDescriptor === 'function') {
        return [{}, factoryOrDescriptor];
    }
    return [factoryOrDescriptor, factoryIfDescriptor];
}
function coerceLabelText$1(label) {
    if (typeof label === 'string' || isSignal(label)) {
        return label;
    }
    return undefined;
}
function coerceLabelComponent$1(label) {
    if (typeof label === 'function' && !isSignal(label)) {
        return { component: label };
    }
    else if (typeof label === 'object') {
        return label;
    }
    return undefined;
}
function coerceIconLigature$1(icon) {
    if (typeof icon === 'string' || isSignal(icon)) {
        return icon;
    }
    return undefined;
}
function coerceIconComponent$1(icon) {
    if (typeof icon === 'function' && !isSignal(icon)) {
        return { component: icon };
    }
    else if (typeof icon === 'object') {
        return icon;
    }
    return undefined;
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Translation note: Texts are translated when added (not lazily when rendered) to simplify filtering.
 */
class ɵSciMenuFactory {
    menuItems = [];
    /** @inheritDoc */
    addMenuItem(descriptor) {
        // Construct action toolbar.
        const actionsFactory = new ɵSciToolbarFactory();
        descriptor.actions?.(actionsFactory);
        // Add menu item.
        this.menuItems.push({
            type: 'menu-item',
            name: descriptor.name,
            labelText: translate(coerceLabelText(descriptor.label)),
            labelComponent: coerceLabelComponent(descriptor.label),
            iconLigature: coerceSignal(coerceIconLigature(descriptor.icon)),
            iconComponent: coerceIconComponent(descriptor.icon),
            checked: coerceSignal(descriptor.checked),
            active: coerceSignal(descriptor.active),
            tooltip: translate(descriptor.tooltip),
            accelerator: validateMenuAccelerator(descriptor.accelerator),
            disabled: coerceSignal(descriptor.disabled),
            actions: actionsFactory.menuItems,
            matchesFilter: descriptor.onFilter,
            cssClass: Arrays.coerce(descriptor.cssClass),
            attributes: descriptor.attributes,
            onSelect: async () => await descriptor.onSelect() ?? descriptor.checked === undefined, // Returning `true` will close the popover. Non-checkable items close by default.
        });
        if (descriptor.checked && descriptor.icon) {
            throw Error('[MenuDefinitionError] Cannot use `checked` and `icon` together.');
        }
        return this;
    }
    /** @inheritDoc */
    addMenu(descriptor, menuFactoryFn) {
        this.menuItems.push({
            type: 'menu-item',
            name: descriptor.name,
            labelText: translate(coerceLabelText(descriptor.label)),
            labelComponent: coerceLabelComponent(descriptor.label),
            iconLigature: coerceSignal(coerceIconLigature(descriptor.icon)),
            iconComponent: coerceIconComponent(descriptor.icon),
            disabled: coerceSignal(descriptor.disabled),
            cssClass: Arrays.coerce(descriptor.cssClass),
            attributes: descriptor.attributes,
            menu: constructMenu(menuFactoryFn, descriptor.menu),
        });
        return this;
    }
    addGroup(factoryOrDescriptor, factoryIfDescriptor) {
        const [descriptor, groupFactoryFn] = coerceGroupDescriptor(factoryOrDescriptor, factoryIfDescriptor);
        // Construct group.
        const groupFactory = new ɵSciMenuFactory();
        groupFactoryFn?.(groupFactory);
        // Construct action toolbar.
        const actionsFactory = new ɵSciToolbarFactory();
        descriptor.actions?.(actionsFactory);
        // Add group.
        this.menuItems.push({
            type: 'group',
            name: descriptor.name,
            label: translate(descriptor.label),
            collapsible: coerceCollapsibleDescriptor(descriptor),
            glyphArea: descriptor.glyphArea,
            disabled: coerceSignal(descriptor.disabled),
            actions: actionsFactory.menuItems,
            children: groupFactory.menuItems,
            cssClass: Arrays.coerce(descriptor.cssClass),
        });
        return this;
    }
}
function coerceGroupDescriptor(factoryOrDescriptor, factoryIfDescriptor) {
    if (typeof factoryOrDescriptor === 'function') {
        return [{}, factoryOrDescriptor];
    }
    return [factoryOrDescriptor, factoryIfDescriptor];
}
function coerceLabelText(label) {
    if (typeof label === 'string' || isSignal(label)) {
        return label;
    }
    return undefined;
}
function coerceLabelComponent(label) {
    if (typeof label === 'function' && !isSignal(label)) {
        return { component: label };
    }
    else if (typeof label === 'object') {
        return label;
    }
    return undefined;
}
function coerceIconLigature(icon) {
    if (typeof icon === 'string' || isSignal(icon)) {
        return icon;
    }
    return undefined;
}
function coerceIconComponent(icon) {
    if (typeof icon === 'function' && !isSignal(icon)) {
        return { component: icon };
    }
    else if (typeof icon === 'object') {
        return icon;
    }
    return undefined;
}
function coerceCollapsibleDescriptor(groupDescriptor) {
    const collapsible = groupDescriptor.collapsible;
    if (typeof collapsible === 'object') {
        return collapsible;
    }
    return collapsible === true ? { collapsed: false } : undefined;
}
function constructMenu(menuFactoryFn, menuDescriptor) {
    const menuFactory = new ɵSciMenuFactory();
    menuFactoryFn(menuFactory);
    return {
        name: menuDescriptor?.name,
        children: menuFactory.menuItems,
        width: menuDescriptor?.width,
        minWidth: menuDescriptor?.minWidth,
        maxWidth: menuDescriptor?.maxWidth,
        maxHeight: menuDescriptor?.maxHeight,
        filter: coerceFilterDescriptor(menuDescriptor),
    };
    function coerceFilterDescriptor(menuDescriptor) {
        const filter = menuDescriptor?.filter;
        if (typeof filter === 'object') {
            return {
                placeholder: coerceSignal(filter.placeholder),
                notFoundText: coerceSignal(filter.notFoundText),
                focus: filter.focus,
            };
        }
        return filter === true ? {} : undefined;
    }
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Standard JavaScript sorting algorithms cannot be used as it requires strict weak element ordering (transitivity),
 * not given for elements positioned relative to each other.
 */
function sortMenuItems(menuItems) {
    const sorted = [];
    const queue = new Set(menuItems);
    // Add contributions which do not declare an insertion point or a non-existent insertion point.
    menuItems.forEach(menuItem => {
        // Add contribution if not declaring an insertion point.
        if (!menuItem.position) {
            sorted.push(menuItem);
            queue.delete(menuItem);
        }
        // Add contribution if declaring a "non-existent"  insertion point.
        else if (menuItem.position.before && !menuItems.some(it => it.name === menuItem.position.before)) {
            sorted.push(menuItem);
            queue.delete(menuItem);
        }
        // Add contribution if declaring a "non-existent" insertion point.
        else if (menuItem.position.after && !menuItems.some(it => it.name === menuItem.position.after)) {
            sorted.push(menuItem);
            queue.delete(menuItem);
        }
    });
    // Add contributions at start and end
    menuItems.forEach(menuItem => {
        if (menuItem.position?.position === 'start') {
            sorted.unshift(menuItem);
            queue.delete(menuItem);
        }
        else if (menuItem.position?.position === 'end') {
            sorted.push(menuItem);
            queue.delete(menuItem);
        }
    });
    // Add contributions declaring an insertion point. Multiple iterations may be required.
    while (queue.size) {
        const queueSize = queue.size;
        for (const menuItem of queue) {
            // Add contributions declaring a before "insertion point".
            if (menuItem.position?.before) {
                const index = sorted.findIndex(candidate => candidate.name === menuItem.position.before);
                if (index !== -1) {
                    sorted.splice(index, 0, menuItem);
                    queue.delete(menuItem);
                }
            }
            // Add contributions declaring an after "insertion point".
            else if (menuItem.position?.after) {
                const index = sorted.findIndex(candidate => candidate.name === menuItem.position.after);
                if (index !== -1) {
                    sorted.splice(index + 1, 0, menuItem);
                    queue.delete(menuItem);
                }
            }
        }
        if (queue.size === queueSize) {
            console.warn('Dangling menu contributions detected. Adding contributions to the end.', queue);
            sorted.push(...queue);
            queue.clear();
        }
    }
    return sorted;
}
// function compare(a: SciMenuItemContribution | SciMenuContribution | SciMenuGroupContribution, b: SciMenuItemContribution | SciMenuContribution | SciMenuGroupContribution): number {
//   if ((a.position?.before && b.name.some(name => name === a.position!.before)) || (b.position?.after && a.name.some(name => name === b.position!.after))) {
//     return -1;
//   }
//   if ((a.position?.after && b.name.some(name => name === a.position!.after)) || (b.position?.before && a.name.some(name => name === b.position!.before))) {
//     return 1;
//   }
//   return 0;
//
//   // TODO WHY UI Fehler?
//   // if (a.position?.before === b.name || b.position?.after === a.name) {
//   //   return -1;
//   // }
//   // if (a.position?.after === b.name || b.position?.before === a.name) {
//   //   return 1;
//   // }
//   // return 0;
// }

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Indicates no contributions found.
 */
const NULL_MENU_CONTRIBUTIONS = [];

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
function parseMenuLocation(location) {
    const regex = /^(?<scope>(menu|toolbar|menubar)):(?<name>.+)$/;
    const { scope } = regex.exec(location).groups;
    return { scope, location };
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides instants for the contribution of menu items.
 *
 * Two consecutive calls always have different instants, in ascending order.
 */
class SciMenuContributionInstantProvider {
    _instant = 0;
    /**
     * Provides the next instant.
     */
    next() {
        return ++this._instant;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuContributionInstantProvider, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuContributionInstantProvider, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuContributionInstantProvider, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Formats given keyboard accelerator for display to the user.
 */
class SciFormatAcceleratorPipe {
    transform(accelerator, leadingText) {
        if (!accelerator) {
            return leadingText;
        }
        const modifiers = [];
        if (accelerator.ctrl) {
            modifiers.push(ctrlKeySymbol);
        }
        if (accelerator.shift) {
            modifiers.push('Shift');
        }
        if (accelerator.alt) {
            modifiers.push('Alt');
        }
        const formattedAccelerator = modifiers.concat(formatKey(accelerator)).join('+');
        return leadingText ? `${leadingText} (${formattedAccelerator})` : formattedAccelerator;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciFormatAcceleratorPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.0.0", ngImport: i0, type: SciFormatAcceleratorPipe, isStandalone: true, name: "sciFormatAccelerator" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciFormatAcceleratorPipe, decorators: [{
            type: Pipe,
            args: [{ name: 'sciFormatAccelerator' }]
        }] });
function formatKey(accelerator) {
    const key = accelerator.key[0].toUpperCase() + accelerator.key.substring(1);
    if (key === ' ') {
        return 'Space';
    }
    if (key === 'ArrowDown') {
        return 'Down';
    }
    if (key === 'ArrowUp') {
        return 'Up';
    }
    if (key === 'ArrowLeft') {
        return 'Left';
    }
    if (key === 'ArrowRight') {
        return 'Right';
    }
    return accelerator.location === 'numpad' ? `NumPad ${key}` : key;
}
/**
 * Platform-specific display symbol for the Control modifier key.
 *
 * Resolves to `⌘` on macOS and `Ctrl` on other operating systems.
 */
const ctrlKeySymbol = navigator.platform.startsWith('Mac') ? '⌘' : 'Ctrl'; // eslint-disable-line @typescript-eslint/no-deprecated

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Alias for {@link SciMenuComponent} with the name `sci-menu-group` instead of `sci-menu`.
 */
class SciMenuGroupComponent {
    group = input.required(...(ngDevMode ? [{ debugName: "group" }] : []));
    glyphArea = input.required(...(ngDevMode ? [{ debugName: "glyphArea" }] : []));
    disabled = input(...(ngDevMode ? [undefined, { debugName: "disabled" }] : []));
    constructor() {
        const elementInjector = inject(Injector);
        const environmentInjector = inject(EnvironmentInjector);
        const hostElement = inject(ElementRef).nativeElement;
        const applicationRef = inject(ApplicationRef);
        effect(onCleanup => untracked(() => {
            const componentRef = createComponent(SciMenuComponent, {
                elementInjector,
                environmentInjector,
                hostElement,
                directives: [
                    provideMenuComponentRole('group'),
                ],
                bindings: [
                    inputBinding('menuItems', computed(() => this.group().children)),
                    inputBinding('disabled', this.disabled),
                    inputBinding('group', computed(() => {
                        const group = this.group();
                        return {
                            label: group.label?.(),
                            collapsible: !!group.collapsible,
                            collapsed: group.collapsible?.collapsed ?? false,
                            hideGlyphArea: group.glyphArea === false,
                            actions: group.actions,
                        };
                    })),
                    inputBinding('glyphArea', this.glyphArea),
                ],
            });
            // Register the newly created refto include it into change detection cycles.
            applicationRef.attachView(componentRef.hostView);
            componentRef.changeDetectorRef.detectChanges();
            // Destroy component when host is destroyed.
            onCleanup(() => componentRef.destroy());
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.0.0", type: SciMenuGroupComponent, isStandalone: true, selector: "sci-menu-group", inputs: { group: { classPropertyName: "group", publicName: "group", isSignal: true, isRequired: true, transformFunction: null }, glyphArea: { classPropertyName: "glyphArea", publicName: "glyphArea", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuGroupComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-menu-group',
                    template: '',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { group: [{ type: i0.Input, args: [{ isSignal: true, alias: "group", required: true }] }], glyphArea: [{ type: i0.Input, args: [{ isSignal: true, alias: "glyphArea", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class SciMenuFilterComponent {
    placeholder = input.required(...(ngDevMode ? [{ debugName: "placeholder" }] : []));
    text = model('', ...(ngDevMode ? [{ debugName: "text" }] : []));
    _inputField = viewChild.required('input');
    onClear() {
        this.text.set('');
        this._inputField().nativeElement.focus();
    }
    onFocus() {
        this._inputField().nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuFilterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.0.0", type: SciMenuFilterComponent, isStandalone: true, selector: "sci-menu-filter", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: true, transformFunction: null }, text: { classPropertyName: "text", publicName: "text", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { text: "textChange" }, host: { listeners: { "focus": "onFocus()" }, properties: { "attr.tabindex": "-1" } }, viewQueries: [{ propertyName: "_inputField", first: true, predicate: ["input"], descendants: true, isSignal: true }], ngImport: i0, template: "<input type=\"text\" autocomplete=\"off\" class=\"e2e-menu-filter-input\" [attr.placeholder]=\"placeholder()\" [(ngModel)]=\"text\" #input>\r\n<button class=\"clear\" (click)=\"onClear()\" [title]=\"('%scion.components.menu.clear.tooltip' | sciText)()\" tabindex=\"-1\">\r\n  <sci-icon>scion.clear</sci-icon>\r\n</button>\r\n", styles: [":host{display:flex}:host>input{all:unset;flex:1 1 0;appearance:auto;width:0;min-width:0}:host>input::placeholder{color:var(--sci-color-gray-400)}:host>input:placeholder-shown+button.clear{visibility:hidden}:host>button.clear{all:unset;flex:none;display:inline-grid;place-content:center;place-items:center;padding:1px;border-radius:var(--sci-corner);-webkit-user-select:none;user-select:none;overflow:hidden;cursor:var(--sci-button-cursor);--sci-icon-size: var(--sci-menu-filter-icon-size)}:host>button.clear:hover{background-color:var(--sci-button-background-color-hover)}:host>button.clear:active{background-color:var(--sci-button-background-color-active)}:host>button.clear:focus:not(:focus-visible){outline:none}:host>button.clear:focus-visible{outline:var(--sci-button-outline-width-focus) solid var(--sci-color-accent)}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: SciIconComponent, selector: "sci-icon" }, { kind: "pipe", type: SciTextPipe, name: "sciText" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sci-menu-filter', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        ReactiveFormsModule,
                        FormsModule,
                        SciTextPipe,
                        SciIconComponent,
                    ], host: {
                        '[attr.tabindex]': '-1', // enable delegation of programmatic focus requests
                        '(focus)': 'onFocus()',
                    }, template: "<input type=\"text\" autocomplete=\"off\" class=\"e2e-menu-filter-input\" [attr.placeholder]=\"placeholder()\" [(ngModel)]=\"text\" #input>\r\n<button class=\"clear\" (click)=\"onClear()\" [title]=\"('%scion.components.menu.clear.tooltip' | sciText)()\" tabindex=\"-1\">\r\n  <sci-icon>scion.clear</sci-icon>\r\n</button>\r\n", styles: [":host{display:flex}:host>input{all:unset;flex:1 1 0;appearance:auto;width:0;min-width:0}:host>input::placeholder{color:var(--sci-color-gray-400)}:host>input:placeholder-shown+button.clear{visibility:hidden}:host>button.clear{all:unset;flex:none;display:inline-grid;place-content:center;place-items:center;padding:1px;border-radius:var(--sci-corner);-webkit-user-select:none;user-select:none;overflow:hidden;cursor:var(--sci-button-cursor);--sci-icon-size: var(--sci-menu-filter-icon-size)}:host>button.clear:hover{background-color:var(--sci-button-background-color-hover)}:host>button.clear:active{background-color:var(--sci-button-background-color-active)}:host>button.clear:focus:not(:focus-visible){outline:none}:host>button.clear:focus-visible{outline:var(--sci-button-outline-width-focus) solid var(--sci-color-accent)}\n"] }]
        }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: true }] }], text: [{ type: i0.Input, args: [{ isSignal: true, alias: "text", required: false }] }, { type: i0.Output, args: ["textChange"] }], _inputField: [{ type: i0.ViewChild, args: ['input', { isSignal: true }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Filters menu items based on the passed filter text.
 *
 * Filtering is hierarchical; submenus and groups inherit the filter of their parent menus.
 * A menu item matches only if it satisfies both its immediate filter and all parent filters.
 *
 * Can be injected into {@link SciMenuComponent}.
 */
class MenuFilter {
    _parentMenuFilter;
    _filterText = signal(null, ...(ngDevMode ? [{ debugName: "_filterText" }] : []));
    /**
     * Indicates whether this filter is active.
     */
    active = computed(() => {
        return !!this._filterText() || (this._parentMenuFilter?.active() ?? false);
    }, ...(ngDevMode ? [{ debugName: "active" }] : []));
    constructor(_parentMenuFilter) {
        this._parentMenuFilter = _parentMenuFilter;
    }
    /**
     * Sets the filter for filtering menu items.
     */
    setFilterText(filterText) {
        this._filterText.set(filterText || null); // eslint-disable-line @typescript-eslint/prefer-nullish-coalescing
    }
    /**
     * Tests whether the given menu item matches this filter.
     */
    matches(menuItem) {
        return computed(() => {
            const filterText = this._filterText();
            // Test if the menu item matches the filter using the menu item's custom filter function, if any.
            if (filterText && menuItem.matchesFilter && !menuItem.matchesFilter(filterText)) {
                return false;
            }
            // Test if the display text of the menu item matches the filter.
            if (filterText && menuItem.labelText && !menuItem.labelText().toLowerCase().includes(filterText.toLowerCase())) {
                return false;
            }
            // Test if the menu item matches the parent filter, if any.
            if (this._parentMenuFilter && !this._parentMenuFilter.matches(menuItem)()) {
                return false;
            }
            return true;
        });
    }
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class SciToolbarControlComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarControlComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.0", type: SciToolbarControlComponent, isStandalone: true, selector: "sci-toolbar-control", ngImport: i0, template: '<ng-content/>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarControlComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-toolbar-control',
                    template: '<ng-content/>',
                }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class SciToolbarSplitButtonComponent {
    host = inject(ElementRef).nativeElement;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarSplitButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.0", type: SciToolbarSplitButtonComponent, isStandalone: true, selector: "sci-toolbar-split-button", ngImport: i0, template: '<ng-content/>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarSplitButtonComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-toolbar-split-button',
                    template: '<ng-content/>',
                }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class SciToolbarIconComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.0", type: SciToolbarIconComponent, isStandalone: true, selector: "sci-toolbar-icon", ngImport: i0, template: '<ng-content/>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-toolbar-icon',
                    template: '<ng-content/>',
                }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class SciToolbarLabelComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.0", type: SciToolbarLabelComponent, isStandalone: true, selector: "sci-toolbar-label", ngImport: i0, template: '<ng-content/>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarLabelComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-toolbar-label',
                    template: '<ng-content/>',
                }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides a reference to the menu's popover element and its child popover, if any.
 *
 * A child popover can be an open submenu or a menu opened from a menu item's action toolbar.
 *
 * Can be injected into {@link SciMenuComponent}.
 */
class PopoverRef {
    _parentPopover = inject(PopoverRef, { skipSelf: true, optional: true });
    _popover = inject(ElementRef).nativeElement;
    /**
     * Reference to the child submenu popover, if any. Can be a submenu or a menu opened from a menu item's action toolbar.
     */
    childPopover = signal(undefined, ...(ngDevMode ? [{ debugName: "childPopover" }] : []));
    /**
     * Indicates if this is a submenu popover; not a top-level menu or a menu opened from a menu item's action toolbar.
     */
    isSubmenu;
    constructor(options) {
        this.isSubmenu = options.isSubmenu;
        this.registerInParentPopover();
    }
    registerInParentPopover() {
        const parentPopover = this._parentPopover;
        if (!parentPopover) {
            return;
        }
        parentPopover.childPopover.set(this);
        inject(DestroyRef).onDestroy(() => parentPopover.childPopover.update(childPopover => childPopover == this ? undefined : childPopover));
    }
    /**
     * Closes this popover, and parent popovers if specified.
     *
     * Defaults to not closing parent popovers.
     */
    close(options) {
        this._popover.hidePopover();
        if (options?.closeParents) {
            this._parentPopover?.close(options);
        }
    }
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Represents a visually separated group of related items within a toolbar.
 */
class SciToolGroupComponent {
    /**
     * Specifies the toolbar items to display in this group.
     */
    menuItems = input.required(...(ngDevMode ? [{ debugName: "menuItems" }] : []));
    /**
     * Specifies the orientation of the items in this group.
     */
    orientation = input.required(...(ngDevMode ? [{ debugName: "orientation" }] : []));
    /**
     * Controls whether to disable the items in this group.
     */
    disabled = input(...(ngDevMode ? [undefined, { debugName: "disabled" }] : []));
    /**
     * Controls where to attach popovers opened in this group.
     */
    popoverViewContainerRef = input.required(...(ngDevMode ? [{ debugName: "popoverViewContainerRef" }] : []));
    /**
     * Indicates whether a menu is opened in this or any child group.
     */
    toolbarMenuOpen = this.computeToolbarMenuOpen();
    _menuService = inject(ɵSciMenuService);
    _childToolbarGroups = viewChildren(SciToolGroupComponent, ...(ngDevMode ? [{ debugName: "_childToolbarGroups" }] : []));
    /**
     * Reference to the popover. Only set if displayed in a menu, such as the action toolbar in menu items.
     */
    _popoverRef = inject(PopoverRef, { optional: true });
    /**
     * Reference to the active (opened) menu item.
     */
    activeMenuItem = linkedSignal(...(ngDevMode ? [{ debugName: "activeMenuItem", source: this.menuItems, // Unset when menu items change.
            computation: () => null }] : [{
            source: this.menuItems, // Unset when menu items change.
            computation: () => null,
        }]));
    constructor() {
        this.installMenuOpener();
    }
    /**
     * Method invoked when clicking on a toolbar button.
     */
    async onSelect(menuItem) {
        if (await menuItem.onSelect()) {
            this._popoverRef?.close();
        }
    }
    /**
     * Method invoked when clicking on a menu button.
     */
    onMenuButtonClick(menuItem, element) {
        this.activeMenuItem.update(activeMenuItem => activeMenuItem?.menuItem === menuItem ? null : { menuItem, element });
    }
    /**
     * Method invoked before clicking on a menu button.
     *
     * When clicking on the active menu button, mark it as closing to prevent immediate re-opening race condition on subsequent click event.
     */
    onMenuButtonMouseDown(menuItem) {
        const activeMenuItem = this.activeMenuItem();
        if (activeMenuItem?.menuItem === menuItem) {
            activeMenuItem.closing = true;
        }
    }
    /**
     * Method invoked when leaving a menu button.
     *
     * Clean up closing state set by {@link onMenuButtonMouseDown}, if any.
     */
    onMenuButtonMouseLeave(menuItem) {
        const activeMenuItem = this.activeMenuItem();
        if (activeMenuItem?.menuItem !== menuItem) {
            return;
        }
        if (activeMenuItem.closing === 'prevented') {
            this.activeMenuItem.set(null); // unset active menu
        }
        else if (activeMenuItem.closing) {
            delete activeMenuItem.closing; // unset closing state
        }
    }
    /**
     * Opens a menu based on {@link activeMenuItem}.
     */
    installMenuOpener() {
        effect(onCleanup => {
            if (!this.activeMenuItem()) {
                return;
            }
            const { menuItem, element } = this.activeMenuItem();
            const menu = menuItem.menu;
            untracked(() => {
                const menuRef = this._menuService.open(menu.children, {
                    anchor: element,
                    viewContainerRef: this.popoverViewContainerRef(),
                    filter: menu.filter,
                    width: menu.width,
                    minWidth: menu.minWidth,
                    maxWidth: menu.maxWidth,
                    maxHeight: menu.maxHeight,
                    cssClass: menuItem.cssClass,
                    attributes: menuItem.attributes,
                    align: this.orientation() === 'horizontal' ? 'vertical' : 'horizontal',
                });
                // Close when opening another menu.
                onCleanup(() => menuRef.close());
                // Unset when closing menu, but only if no other menu has been opened in the meantime.
                menuRef.onClose(() => {
                    const activeMenuItem = this.activeMenuItem();
                    // Do not unset if another menu was opened in the meantime.
                    if (activeMenuItem?.menuItem !== menuItem) {
                        return;
                    }
                    // Prevent immediate re-opening race condition when toolbar button is clicked to close.
                    if (activeMenuItem.closing) {
                        activeMenuItem.closing = 'prevented';
                        return;
                    }
                    this.activeMenuItem.set(null);
                });
            });
        });
    }
    /**
     * Computes whether a menu is open in this group or child group.
     */
    computeToolbarMenuOpen() {
        // Do not return `computed` signal to prevent illegal access to required component inputs until Angular has completed the initialization of this component,
        // happening when reading the signal from the parent component's template, e.g., via reference variable.
        const toolbarMenuOpen = signal(false, ...(ngDevMode ? [{ debugName: "toolbarMenuOpen" }] : []));
        effect(() => {
            toolbarMenuOpen.set(!!this.activeMenuItem() || this._childToolbarGroups().some(childGroup => childGroup.toolbarMenuOpen()));
        });
        return toolbarMenuOpen;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.0", type: SciToolGroupComponent, isStandalone: true, selector: "sci-toolbar-group", inputs: { menuItems: { classPropertyName: "menuItems", publicName: "menuItems", isSignal: true, isRequired: true, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, popoverViewContainerRef: { classPropertyName: "popoverViewContainerRef", publicName: "popoverViewContainerRef", isSignal: true, isRequired: true, transformFunction: null } }, host: { properties: { "attr.data-orientation": "orientation()" } }, viewQueries: [{ propertyName: "_childToolbarGroups", predicate: SciToolGroupComponent, descendants: true, isSignal: true }], ngImport: i0, template: "@for (menuItem of menuItems(); track $index) {\r\n  @let disabled = this.disabled() || menuItem.disabled?.() || false;\r\n  @switch (menuItem.type) {\r\n    <!-- Toolbar Item (push button, toggle button, split button, menu item, control) -->\r\n    @case ('menu-item') {\r\n      @let isSplitButton = (menuItem.onSelect || menuItem.control) && menuItem.menu;\r\n\r\n      @if (isSplitButton) {\r\n        <sci-toolbar-split-button class=\"e2e-menu-item\" #split_button_element>\r\n          <ng-container *ngTemplateOutlet=\"menu_item_template; context: {anchor: split_button_element.host}\"/>\r\n        </sci-toolbar-split-button>\r\n      } @else {\r\n        <ng-container *ngTemplateOutlet=\"menu_item_template\"/>\r\n      }\r\n\r\n      <!-- Template for rendering the content of a toolbar item. -->\r\n      <ng-template #menu_item_template let-anchor=\"anchor\">\r\n        <!-- Render push or toggle button. -->\r\n        @if (menuItem.onSelect) {\r\n          <button [attr.disabled]=\"disabled || null\"\r\n                  [attr.title]=\"menuItem.accelerator | sciFormatAccelerator:menuItem.tooltip?.()\"\r\n                  [class.checked]=\"menuItem.checked?.()\"\r\n                  [class]=\"menuItem.cssClass\" class=\"menu-item e2e-menu-item\"\r\n                  [sciAttributes]=\"menuItem.attributes\"\r\n                  (click)=\"onSelect(menuItem)\">\r\n            <!-- Render icon, if any. -->\r\n            <ng-container *ngTemplateOutlet=\"icon_template; context: {$implicit: menuItem}\"/>\r\n            <!-- Render label, if any. -->\r\n            <ng-container *ngTemplateOutlet=\"label_template; context: {$implicit: menuItem}\"/>\r\n          </button>\r\n        } @else if (menuItem.control) {\r\n          <!-- Render custom control. -->\r\n          <sci-toolbar-control [class]=\"menuItem.cssClass\" class=\"e2e-menu-item\"\r\n                               [attr.title]=\"menuItem.accelerator | sciFormatAccelerator:menuItem.tooltip?.()\"\r\n                               [sciAttributes]=\"menuItem.attributes\">\r\n            <ng-container *sciComponentOutlet=\"menuItem.control\"/>\r\n          </sci-toolbar-control>\r\n        }\r\n\r\n        <!-- Render dropdown menu button. -->\r\n        @if (menuItem.menu?.children?.length) {\r\n          @let hasLabel = menuItem.labelText || menuItem.labelComponent;\r\n          @let hasIcon = menuItem.iconLigature || menuItem.iconComponent;\r\n          @let hasVisualMenuHint = menuItem.visualMenuHint ?? true;\r\n          @let hasVisualIconMenuHint = hasVisualMenuHint && !isSplitButton && hasIcon && !hasLabel;\r\n          @let hasChevron = hasVisualMenuHint && (isSplitButton || !hasVisualIconMenuHint);\r\n\r\n          <button [attr.disabled]=\"disabled || null\"\r\n                  [attr.title]=\"menuItem.tooltip?.()\"\r\n                  [class.menu-open]=\"activeMenuItem()?.menuItem === menuItem\"\r\n                  [class.visual-menu-hint]=\"hasVisualIconMenuHint\"\r\n                  [class]=\"menuItem.cssClass\" class=\"menu-item menu e2e-menu-item\"\r\n                  [sciAttributes]=\"menuItem.attributes\"\r\n                  (click)=\"onMenuButtonClick(menuItem, anchor ?? menu_button)\"\r\n                  (mousedown)=\"onMenuButtonMouseDown(menuItem)\"\r\n                  (mouseleave)=\"onMenuButtonMouseLeave(menuItem)\"\r\n                  #menu_button>\r\n            @if (!isSplitButton) {\r\n              <!-- Render icon, if any. -->\r\n              <ng-container *ngTemplateOutlet=\"icon_template; context: {$implicit: menuItem}\"/>\r\n              <!-- Render label, if any. -->\r\n              <ng-container *ngTemplateOutlet=\"label_template; context: {$implicit: menuItem}\"/>\r\n            }\r\n            <!-- Render chevron to indicate dropdown menu. -->\r\n            @if (hasChevron) {\r\n              <sci-icon class=\"visual-menu-hint\">scion.menu_down</sci-icon>\r\n            }\r\n          </button>\r\n        }\r\n      </ng-template>\r\n    }\r\n    <!-- Toolbar Group -->\r\n    @case ('group') {\r\n      <sci-toolbar-group [menuItems]=\"menuItem.children\"\r\n                         [orientation]=\"orientation()\"\r\n                         [disabled]=\"disabled\"\r\n                         [popoverViewContainerRef]=\"popoverViewContainerRef()\"\r\n                         [class]=\"menuItem.cssClass\" class=\"e2e-toolbar-group\"/>\r\n    }\r\n  }\r\n}\r\n\r\n<!-- Renders the icon of a menu item, if any. -->\r\n<ng-template #icon_template let-menuItem>\r\n  @if (menuItem.iconLigature) {\r\n    <sci-icon>\r\n      {{menuItem.iconLigature()}}\r\n    </sci-icon>\r\n  } @else if (menuItem.iconComponent) {\r\n    <sci-toolbar-icon>\r\n      <ng-container *sciComponentOutlet=\"menuItem.iconComponent\"/>\r\n    </sci-toolbar-icon>\r\n  }\r\n</ng-template>\r\n\r\n<!-- Renders the label of a menu item, if any. -->\r\n<ng-template #label_template let-menuItem>\r\n  @if (menuItem.labelText) {\r\n    <sci-toolbar-label>\r\n      {{menuItem.labelText()}}\r\n    </sci-toolbar-label>\r\n  } @else if (menuItem.labelComponent) {\r\n    <sci-toolbar-label>\r\n      <ng-container *sciComponentOutlet=\"menuItem.labelComponent\"/>\r\n    </sci-toolbar-label>\r\n  }\r\n</ng-template>\r\n", styles: ["@charset \"UTF-8\";:host{--sci-icon-size: var(--sci-toolbar-item-size);--sci-toolbar-item-padding-inline: calc(.5 * var(--sci-toolbar-item-size));--sci-toolbar-item-padding-block: calc(.125 * var(--sci-toolbar-item-size));display:flex;gap:2px}:host[data-orientation=vertical]{flex-direction:column}:host>sci-toolbar-group:not(:first-child):not(:has(>sci-toolbar-group:first-child)):before{content:\"\";background-color:var(--sci-color-border);margin:2px}:host>sci-toolbar-group:not(:first-child):not(:has(>sci-toolbar-group:first-child))[data-orientation=horizontal]:before{width:1px}:host>sci-toolbar-group:not(:first-child):not(:has(>sci-toolbar-group:first-child))[data-orientation=vertical]:before{height:1px}:host>sci-toolbar-group:not(:last-child):not(:has(+sci-toolbar-group)):after{content:\"\";background-color:var(--sci-color-border);margin:2px}:host>sci-toolbar-group:not(:last-child):not(:has(+sci-toolbar-group))[data-orientation=horizontal]:after{width:1px}:host>sci-toolbar-group:not(:last-child):not(:has(+sci-toolbar-group))[data-orientation=vertical]:after{height:1px}:host>sci-toolbar-split-button{display:flex;--\\275sci-toolbar-split-button: true}:host>sci-toolbar-split-button:has(>button:first-child.checked){--\\275sci-toolbar-split-button-checked: true}:host>sci-toolbar-split-button:has(>button:last-child.menu-open){--sci-toolbar-split-button-menu-open: true}:host>sci-toolbar-split-button:hover{--sci-toolbar-split-button-hover: true}:host>sci-toolbar-split-button:hover,:host>sci-toolbar-split-button:has(>button:last-child.menu-open),:host>sci-toolbar-split-button:has(>button:first-child.checked),:host>sci-toolbar-split-button:has(>sci-toolbar-control:focus-within){--sci-toolbar-split-button-outline-visible: true}:host>sci-toolbar-split-button:focus-within{--sci-toolbar-split-button-focus-within: true}:host>sci-toolbar-split-button>sci-toolbar-control{border:1px solid var(--sci-color-border);border-radius:var(--sci-toolbar-item-border-radius);overflow:hidden}@container style(--sci-toolbar-split-button-outline-visible: true){:host>sci-toolbar-split-button>sci-toolbar-control{border-top-right-radius:0;border-bottom-right-radius:0}}:host button:is(.menu-item,#sci-reset){all:unset;display:inline-flex;gap:.3em;place-content:center;align-items:center;text-wrap:nowrap;padding:var(--sci-toolbar-item-padding-block) var(--sci-toolbar-item-padding-inline);border-radius:var(--sci-toolbar-item-border-radius);border:1px solid transparent;background-color:var(--sci-toolbar-item-background-color);color:var(--sci-toolbar-item-text-color);-webkit-user-select:none;user-select:none;cursor:var(--sci-toolbar-item-cursor)}:host button:is(.menu-item,#sci-reset):where(:not(:has(>sci-toolbar-label))){--sci-toolbar-item-padding-inline: var(--sci-toolbar-item-padding-block);aspect-ratio:1/1}@container style(--\\275sci-toolbar-split-button: true){:host button:is(.menu-item,#sci-reset):where(:first-child){border-top-right-radius:0;border-bottom-right-radius:0}@container style(--sci-toolbar-split-button-menu-open: true) or (style(--\\275sci-toolbar-split-button-checked: true) and (not style(--sci-toolbar-split-button-hover: true))){:host button:is(.menu-item,#sci-reset):where(:first-child){border-right:0;padding-right:calc(var(--sci-toolbar-item-padding-inline) + 1px)}}:host button:is(.menu-item,#sci-reset):where(:last-child){border-top-left-radius:0;border-bottom-left-radius:0;border-left:0;padding:0 .125em;aspect-ratio:auto}@container style(--sci-toolbar-split-button-outline-visible: true){:host button:is(.menu-item,#sci-reset){border-color:var(--sci-toolbar-item-border-color-checked)}}@container style(--\\275sci-toolbar-split-button-checked: true){:host button:is(.menu-item,#sci-reset){border-color:var(--sci-toolbar-item-border-color-checked)}:host button:is(.menu-item,#sci-reset):where(:not(:disabled)){background-color:var(--sci-toolbar-item-background-color-checked)}}@container style(--sci-toolbar-split-button-menu-open: true){:host button:is(.menu-item,#sci-reset){background-color:var(--sci-toolbar-item-background-color-hover)}}:host button:is(.menu-item,#sci-reset):focus-visible{border-radius:var(--sci-toolbar-item-border-radius)}}:host button:is(.menu-item,#sci-reset)>sci-toolbar-icon{display:inline-grid;height:var(--sci-toolbar-item-size);width:var(--sci-toolbar-item-size)}:host button:is(.menu-item,#sci-reset)>sci-icon.visual-menu-hint{--sci-icon-size: var(--sci-toolbar-item-chevron-size)}:host button:is(.menu-item,#sci-reset):has(>sci-toolbar-label)>sci-icon.visual-menu-hint{margin-left:calc(var(--sci-toolbar-item-padding-inline) / 2)}:host button:is(.menu-item,#sci-reset).menu.visual-menu-hint{position:relative}:host button:is(.menu-item,#sci-reset).menu.visual-menu-hint:after{content:\"\";position:absolute;box-sizing:border-box;width:var(--sci-toolbar-item-visual-menu-hint-size);height:var(--sci-toolbar-item-visual-menu-hint-size);border:var(--sci-toolbar-item-visual-menu-hint-size) solid transparent;border-right-color:var(--sci-toolbar-item-visual-menu-hint-color);border-bottom-color:var(--sci-toolbar-item-visual-menu-hint-color);bottom:calc(var(--sci-corner) / 4);right:calc(var(--sci-corner) / 4)}:host button:is(.menu-item,#sci-reset).menu.visual-menu-hint:disabled:after{border-right-color:var(--sci-toolbar-item-visual-menu-hint-color-disabled);border-bottom-color:var(--sci-toolbar-item-visual-menu-hint-color-disabled)}@container not style(--\\275sci-toolbar-split-button: true){:host button:is(.menu-item,#sci-reset).checked{border-color:var(--sci-toolbar-item-border-color-checked)}:host button:is(.menu-item,#sci-reset).checked:where(:not(:disabled)){background-color:var(--sci-toolbar-item-background-color-checked)}}:host button:is(.menu-item,#sci-reset):disabled{color:var(--sci-toolbar-item-text-color-disabled)}:host button:is(.menu-item,#sci-reset):hover:where(:not(:disabled)){background-color:var(--sci-toolbar-item-background-color-hover)}:host button:is(.menu-item,#sci-reset):active:where(:not(:disabled)){background-color:var(--sci-toolbar-item-background-color-active)}:host button:is(.menu-item,#sci-reset):focus:not(:focus-visible){outline:none}:host button:is(.menu-item,#sci-reset):focus-visible{outline:var(--sci-toolbar-item-outline-width-focus) solid var(--sci-color-accent)}@container not style(--\\275sci-toolbar-split-button: true){:host button:is(.menu-item,#sci-reset).menu.menu-open{background-color:var(--sci-toolbar-item-background-color-hover)}}\n"], dependencies: [{ kind: "component", type: SciToolGroupComponent, selector: "sci-toolbar-group", inputs: ["menuItems", "orientation", "disabled", "popoverViewContainerRef"] }, { kind: "directive", type: SciComponentOutletDirective, selector: "ng-template[sciComponentOutlet]", inputs: ["sciComponentOutlet"] }, { kind: "directive", type: SciAttributesDirective, selector: "[sciAttributes]", inputs: ["sciAttributes"] }, { kind: "component", type: SciIconComponent, selector: "sci-icon" }, { kind: "component", type: SciToolbarSplitButtonComponent, selector: "sci-toolbar-split-button" }, { kind: "component", type: SciToolbarControlComponent, selector: "sci-toolbar-control" }, { kind: "component", type: SciToolbarIconComponent, selector: "sci-toolbar-icon" }, { kind: "component", type: SciToolbarLabelComponent, selector: "sci-toolbar-label" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: SciFormatAcceleratorPipe, name: "sciFormatAccelerator" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sci-toolbar-group', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        SciComponentOutletDirective,
                        SciAttributesDirective,
                        SciIconComponent,
                        SciFormatAcceleratorPipe,
                        SciToolbarSplitButtonComponent,
                        SciToolbarControlComponent,
                        SciToolbarIconComponent,
                        SciToolbarLabelComponent,
                        NgTemplateOutlet,
                    ], host: {
                        '[attr.data-orientation]': 'orientation()',
                    }, template: "@for (menuItem of menuItems(); track $index) {\r\n  @let disabled = this.disabled() || menuItem.disabled?.() || false;\r\n  @switch (menuItem.type) {\r\n    <!-- Toolbar Item (push button, toggle button, split button, menu item, control) -->\r\n    @case ('menu-item') {\r\n      @let isSplitButton = (menuItem.onSelect || menuItem.control) && menuItem.menu;\r\n\r\n      @if (isSplitButton) {\r\n        <sci-toolbar-split-button class=\"e2e-menu-item\" #split_button_element>\r\n          <ng-container *ngTemplateOutlet=\"menu_item_template; context: {anchor: split_button_element.host}\"/>\r\n        </sci-toolbar-split-button>\r\n      } @else {\r\n        <ng-container *ngTemplateOutlet=\"menu_item_template\"/>\r\n      }\r\n\r\n      <!-- Template for rendering the content of a toolbar item. -->\r\n      <ng-template #menu_item_template let-anchor=\"anchor\">\r\n        <!-- Render push or toggle button. -->\r\n        @if (menuItem.onSelect) {\r\n          <button [attr.disabled]=\"disabled || null\"\r\n                  [attr.title]=\"menuItem.accelerator | sciFormatAccelerator:menuItem.tooltip?.()\"\r\n                  [class.checked]=\"menuItem.checked?.()\"\r\n                  [class]=\"menuItem.cssClass\" class=\"menu-item e2e-menu-item\"\r\n                  [sciAttributes]=\"menuItem.attributes\"\r\n                  (click)=\"onSelect(menuItem)\">\r\n            <!-- Render icon, if any. -->\r\n            <ng-container *ngTemplateOutlet=\"icon_template; context: {$implicit: menuItem}\"/>\r\n            <!-- Render label, if any. -->\r\n            <ng-container *ngTemplateOutlet=\"label_template; context: {$implicit: menuItem}\"/>\r\n          </button>\r\n        } @else if (menuItem.control) {\r\n          <!-- Render custom control. -->\r\n          <sci-toolbar-control [class]=\"menuItem.cssClass\" class=\"e2e-menu-item\"\r\n                               [attr.title]=\"menuItem.accelerator | sciFormatAccelerator:menuItem.tooltip?.()\"\r\n                               [sciAttributes]=\"menuItem.attributes\">\r\n            <ng-container *sciComponentOutlet=\"menuItem.control\"/>\r\n          </sci-toolbar-control>\r\n        }\r\n\r\n        <!-- Render dropdown menu button. -->\r\n        @if (menuItem.menu?.children?.length) {\r\n          @let hasLabel = menuItem.labelText || menuItem.labelComponent;\r\n          @let hasIcon = menuItem.iconLigature || menuItem.iconComponent;\r\n          @let hasVisualMenuHint = menuItem.visualMenuHint ?? true;\r\n          @let hasVisualIconMenuHint = hasVisualMenuHint && !isSplitButton && hasIcon && !hasLabel;\r\n          @let hasChevron = hasVisualMenuHint && (isSplitButton || !hasVisualIconMenuHint);\r\n\r\n          <button [attr.disabled]=\"disabled || null\"\r\n                  [attr.title]=\"menuItem.tooltip?.()\"\r\n                  [class.menu-open]=\"activeMenuItem()?.menuItem === menuItem\"\r\n                  [class.visual-menu-hint]=\"hasVisualIconMenuHint\"\r\n                  [class]=\"menuItem.cssClass\" class=\"menu-item menu e2e-menu-item\"\r\n                  [sciAttributes]=\"menuItem.attributes\"\r\n                  (click)=\"onMenuButtonClick(menuItem, anchor ?? menu_button)\"\r\n                  (mousedown)=\"onMenuButtonMouseDown(menuItem)\"\r\n                  (mouseleave)=\"onMenuButtonMouseLeave(menuItem)\"\r\n                  #menu_button>\r\n            @if (!isSplitButton) {\r\n              <!-- Render icon, if any. -->\r\n              <ng-container *ngTemplateOutlet=\"icon_template; context: {$implicit: menuItem}\"/>\r\n              <!-- Render label, if any. -->\r\n              <ng-container *ngTemplateOutlet=\"label_template; context: {$implicit: menuItem}\"/>\r\n            }\r\n            <!-- Render chevron to indicate dropdown menu. -->\r\n            @if (hasChevron) {\r\n              <sci-icon class=\"visual-menu-hint\">scion.menu_down</sci-icon>\r\n            }\r\n          </button>\r\n        }\r\n      </ng-template>\r\n    }\r\n    <!-- Toolbar Group -->\r\n    @case ('group') {\r\n      <sci-toolbar-group [menuItems]=\"menuItem.children\"\r\n                         [orientation]=\"orientation()\"\r\n                         [disabled]=\"disabled\"\r\n                         [popoverViewContainerRef]=\"popoverViewContainerRef()\"\r\n                         [class]=\"menuItem.cssClass\" class=\"e2e-toolbar-group\"/>\r\n    }\r\n  }\r\n}\r\n\r\n<!-- Renders the icon of a menu item, if any. -->\r\n<ng-template #icon_template let-menuItem>\r\n  @if (menuItem.iconLigature) {\r\n    <sci-icon>\r\n      {{menuItem.iconLigature()}}\r\n    </sci-icon>\r\n  } @else if (menuItem.iconComponent) {\r\n    <sci-toolbar-icon>\r\n      <ng-container *sciComponentOutlet=\"menuItem.iconComponent\"/>\r\n    </sci-toolbar-icon>\r\n  }\r\n</ng-template>\r\n\r\n<!-- Renders the label of a menu item, if any. -->\r\n<ng-template #label_template let-menuItem>\r\n  @if (menuItem.labelText) {\r\n    <sci-toolbar-label>\r\n      {{menuItem.labelText()}}\r\n    </sci-toolbar-label>\r\n  } @else if (menuItem.labelComponent) {\r\n    <sci-toolbar-label>\r\n      <ng-container *sciComponentOutlet=\"menuItem.labelComponent\"/>\r\n    </sci-toolbar-label>\r\n  }\r\n</ng-template>\r\n", styles: ["@charset \"UTF-8\";:host{--sci-icon-size: var(--sci-toolbar-item-size);--sci-toolbar-item-padding-inline: calc(.5 * var(--sci-toolbar-item-size));--sci-toolbar-item-padding-block: calc(.125 * var(--sci-toolbar-item-size));display:flex;gap:2px}:host[data-orientation=vertical]{flex-direction:column}:host>sci-toolbar-group:not(:first-child):not(:has(>sci-toolbar-group:first-child)):before{content:\"\";background-color:var(--sci-color-border);margin:2px}:host>sci-toolbar-group:not(:first-child):not(:has(>sci-toolbar-group:first-child))[data-orientation=horizontal]:before{width:1px}:host>sci-toolbar-group:not(:first-child):not(:has(>sci-toolbar-group:first-child))[data-orientation=vertical]:before{height:1px}:host>sci-toolbar-group:not(:last-child):not(:has(+sci-toolbar-group)):after{content:\"\";background-color:var(--sci-color-border);margin:2px}:host>sci-toolbar-group:not(:last-child):not(:has(+sci-toolbar-group))[data-orientation=horizontal]:after{width:1px}:host>sci-toolbar-group:not(:last-child):not(:has(+sci-toolbar-group))[data-orientation=vertical]:after{height:1px}:host>sci-toolbar-split-button{display:flex;--\\275sci-toolbar-split-button: true}:host>sci-toolbar-split-button:has(>button:first-child.checked){--\\275sci-toolbar-split-button-checked: true}:host>sci-toolbar-split-button:has(>button:last-child.menu-open){--sci-toolbar-split-button-menu-open: true}:host>sci-toolbar-split-button:hover{--sci-toolbar-split-button-hover: true}:host>sci-toolbar-split-button:hover,:host>sci-toolbar-split-button:has(>button:last-child.menu-open),:host>sci-toolbar-split-button:has(>button:first-child.checked),:host>sci-toolbar-split-button:has(>sci-toolbar-control:focus-within){--sci-toolbar-split-button-outline-visible: true}:host>sci-toolbar-split-button:focus-within{--sci-toolbar-split-button-focus-within: true}:host>sci-toolbar-split-button>sci-toolbar-control{border:1px solid var(--sci-color-border);border-radius:var(--sci-toolbar-item-border-radius);overflow:hidden}@container style(--sci-toolbar-split-button-outline-visible: true){:host>sci-toolbar-split-button>sci-toolbar-control{border-top-right-radius:0;border-bottom-right-radius:0}}:host button:is(.menu-item,#sci-reset){all:unset;display:inline-flex;gap:.3em;place-content:center;align-items:center;text-wrap:nowrap;padding:var(--sci-toolbar-item-padding-block) var(--sci-toolbar-item-padding-inline);border-radius:var(--sci-toolbar-item-border-radius);border:1px solid transparent;background-color:var(--sci-toolbar-item-background-color);color:var(--sci-toolbar-item-text-color);-webkit-user-select:none;user-select:none;cursor:var(--sci-toolbar-item-cursor)}:host button:is(.menu-item,#sci-reset):where(:not(:has(>sci-toolbar-label))){--sci-toolbar-item-padding-inline: var(--sci-toolbar-item-padding-block);aspect-ratio:1/1}@container style(--\\275sci-toolbar-split-button: true){:host button:is(.menu-item,#sci-reset):where(:first-child){border-top-right-radius:0;border-bottom-right-radius:0}@container style(--sci-toolbar-split-button-menu-open: true) or (style(--\\275sci-toolbar-split-button-checked: true) and (not style(--sci-toolbar-split-button-hover: true))){:host button:is(.menu-item,#sci-reset):where(:first-child){border-right:0;padding-right:calc(var(--sci-toolbar-item-padding-inline) + 1px)}}:host button:is(.menu-item,#sci-reset):where(:last-child){border-top-left-radius:0;border-bottom-left-radius:0;border-left:0;padding:0 .125em;aspect-ratio:auto}@container style(--sci-toolbar-split-button-outline-visible: true){:host button:is(.menu-item,#sci-reset){border-color:var(--sci-toolbar-item-border-color-checked)}}@container style(--\\275sci-toolbar-split-button-checked: true){:host button:is(.menu-item,#sci-reset){border-color:var(--sci-toolbar-item-border-color-checked)}:host button:is(.menu-item,#sci-reset):where(:not(:disabled)){background-color:var(--sci-toolbar-item-background-color-checked)}}@container style(--sci-toolbar-split-button-menu-open: true){:host button:is(.menu-item,#sci-reset){background-color:var(--sci-toolbar-item-background-color-hover)}}:host button:is(.menu-item,#sci-reset):focus-visible{border-radius:var(--sci-toolbar-item-border-radius)}}:host button:is(.menu-item,#sci-reset)>sci-toolbar-icon{display:inline-grid;height:var(--sci-toolbar-item-size);width:var(--sci-toolbar-item-size)}:host button:is(.menu-item,#sci-reset)>sci-icon.visual-menu-hint{--sci-icon-size: var(--sci-toolbar-item-chevron-size)}:host button:is(.menu-item,#sci-reset):has(>sci-toolbar-label)>sci-icon.visual-menu-hint{margin-left:calc(var(--sci-toolbar-item-padding-inline) / 2)}:host button:is(.menu-item,#sci-reset).menu.visual-menu-hint{position:relative}:host button:is(.menu-item,#sci-reset).menu.visual-menu-hint:after{content:\"\";position:absolute;box-sizing:border-box;width:var(--sci-toolbar-item-visual-menu-hint-size);height:var(--sci-toolbar-item-visual-menu-hint-size);border:var(--sci-toolbar-item-visual-menu-hint-size) solid transparent;border-right-color:var(--sci-toolbar-item-visual-menu-hint-color);border-bottom-color:var(--sci-toolbar-item-visual-menu-hint-color);bottom:calc(var(--sci-corner) / 4);right:calc(var(--sci-corner) / 4)}:host button:is(.menu-item,#sci-reset).menu.visual-menu-hint:disabled:after{border-right-color:var(--sci-toolbar-item-visual-menu-hint-color-disabled);border-bottom-color:var(--sci-toolbar-item-visual-menu-hint-color-disabled)}@container not style(--\\275sci-toolbar-split-button: true){:host button:is(.menu-item,#sci-reset).checked{border-color:var(--sci-toolbar-item-border-color-checked)}:host button:is(.menu-item,#sci-reset).checked:where(:not(:disabled)){background-color:var(--sci-toolbar-item-background-color-checked)}}:host button:is(.menu-item,#sci-reset):disabled{color:var(--sci-toolbar-item-text-color-disabled)}:host button:is(.menu-item,#sci-reset):hover:where(:not(:disabled)){background-color:var(--sci-toolbar-item-background-color-hover)}:host button:is(.menu-item,#sci-reset):active:where(:not(:disabled)){background-color:var(--sci-toolbar-item-background-color-active)}:host button:is(.menu-item,#sci-reset):focus:not(:focus-visible){outline:none}:host button:is(.menu-item,#sci-reset):focus-visible{outline:var(--sci-toolbar-item-outline-width-focus) solid var(--sci-color-accent)}@container not style(--\\275sci-toolbar-split-button: true){:host button:is(.menu-item,#sci-reset).menu.menu-open{background-color:var(--sci-toolbar-item-background-color-hover)}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { menuItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "menuItems", required: true }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], popoverViewContainerRef: [{ type: i0.Input, args: [{ isSignal: true, alias: "popoverViewContainerRef", required: true }] }], _childToolbarGroups: [{ type: i0.ViewChildren, args: [i0.forwardRef(() => SciToolGroupComponent), { isSignal: true }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class SciMenuGroupLabelComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuGroupLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.0", type: SciMenuGroupLabelComponent, isStandalone: true, selector: "sci-menu-group-label", ngImport: i0, template: '<ng-content/>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuGroupLabelComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-menu-group-label',
                    template: '<ng-content/>',
                }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class SciMenuItemLabelComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuItemLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.0", type: SciMenuItemLabelComponent, isStandalone: true, selector: "sci-menu-item-label", ngImport: i0, template: '<ng-content/>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuItemLabelComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-menu-item-label',
                    template: '<ng-content/>',
                }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class SciMenuItemIconComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuItemIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.0", type: SciMenuItemIconComponent, isStandalone: true, selector: "sci-menu-item-icon", ngImport: i0, template: '<ng-content/>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuItemIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-menu-item-icon',
                    template: '<ng-content/>',
                }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Represents a menu or a group of menu items.
 */
class SciMenuComponent {
    /**
     * Specifies the menu items to display in this menu or group.
     */
    menuItems = input.required(...(ngDevMode ? [{ debugName: "menuItems" }] : []));
    /**
     * Controls whether to disable menu items in this menu or group.
     */
    disabled = input(...(ngDevMode ? [undefined, { debugName: "disabled" }] : []));
    /**
     * Enables and configures filtering of this menu.
     *
     * Has no effect if a menu group.
     */
    filter = input(...(ngDevMode ? [undefined, { debugName: "filter" }] : []));
    /**
     * Configures features of this group.
     *
     * Has no effect if a menu or submenu
     */
    group = input(...(ngDevMode ? [undefined, { debugName: "group" }] : []));
    /**
     * Specifies the preferred menu width.
     *
     * Has no effect if a menu group.
     */
    width = input(...(ngDevMode ? [undefined, { debugName: "width" }] : []));
    /**
     * Specifies the preferred minimum menu width.
     *
     * Defaults to the `--sci-menu-min-width` or `--sci-menu-submenu-min-width` CSS variables.
     *
     * If {@link anchorWidth} is specified (e.g., for toolbar menus), the effective minimum width evaluates to `max(anchorWidth, minWidth)`.
     *
     * Has no effect if a menu group.
     */
    minWidth = input(...(ngDevMode ? [undefined, { debugName: "minWidth" }] : []));
    /**
     * Specifies the maximum menu width.
     *
     * Has no effect if a menu group.
     */
    maxWidth = input(...(ngDevMode ? [undefined, { debugName: "maxWidth" }] : []));
    /**
     * Specifies the maximum menu height.
     *
     * Has no effect if a menu group.
     */
    maxHeight = input(...(ngDevMode ? [undefined, { debugName: "maxHeight" }] : []));
    /**
     * Controls whether to display the glyph area.
     *
     * The glyph area is the leftmost column reserved for displaying icons and checkmarks.
     */
    glyphArea = input(...(ngDevMode ? [undefined, { debugName: "glyphArea" }] : []));
    /**
     * Specifies the width of the popover anchor.
     *
     * Used to compute the minimum width of the menu or submenu.
     */
    anchorWidth = input(undefined, ...(ngDevMode ? [{ debugName: "anchorWidth", transform: (width) => width ? `${width}px` : undefined }] : [{ transform: (width) => width ? `${width}px` : undefined }]));
    /**
     * Specifies CSS classes to associate with the menu, submenu, or group.
     */
    cssClass = input(...(ngDevMode ? [undefined, { debugName: "cssClass" }] : []));
    _menuService = inject(ɵSciMenuService);
    _menuFilter = inject(MenuFilter);
    _popoverRef = inject(PopoverRef);
    _filterField = viewChild(SciMenuFilterComponent, ...(ngDevMode ? [{ debugName: "_filterField", read: (ElementRef) }] : [{ read: (ElementRef) }]));
    _viewport = viewChild(SciViewportComponent, ...(ngDevMode ? [{ debugName: "_viewport" }] : []));
    hasGlyphArea = computed(() => this.glyphArea() ?? requiresGlyphArea(this.menuItems()), ...(ngDevMode ? [{ debugName: "hasGlyphArea" }] : []));
    menuItemsFiltered = computed(() => this.menuItems().filter(menuItem => this.matchesFilter(menuItem)()), ...(ngDevMode ? [{ debugName: "menuItemsFiltered" }] : []));
    popoverViewContainerRef = viewChild.required('popover_view_container_ref', { read: ViewContainerRef });
    scrolling = computed(() => this._viewport()?.scrolling(), ...(ngDevMode ? [{ debugName: "scrolling" }] : []));
    activeSubmenuItem = linkedSignal(...(ngDevMode ? [{ debugName: "activeSubmenuItem", source: this.menuItemsFiltered, // Unset when filtered menu items change. Otherwise, popopver may lose anchor and render left-top of the page viewport.
            computation: () => null,
            equal: (a, b) => a?.menuItem === b?.menuItem }] : [{
            source: this.menuItemsFiltered, // Unset when filtered menu items change. Otherwise, popopver may lose anchor and render left-top of the page viewport.
            computation: () => null,
            equal: (a, b) => a?.menuItem === b?.menuItem, // ignore if clicking an already opened menu item
        }]));
    isGroupExpanded = this.computeGroupExpanded();
    menuSize = this.computeMenuSize();
    constructor() {
        this.installSubmenuOpener();
        this.closeChildPopoverOnComponentReuse();
        this.lockInitialMenuWidth();
        this.focusFilterField();
    }
    /**
     * Method invoked when clicking on a menu item.
     */
    async onSelect(menuItem) {
        if (await menuItem.onSelect()) {
            this._popoverRef.close({ closeParents: true });
        }
    }
    /**
     * Method invoked when clicking on the group header of a collapsible group.
     */
    onGroupButtonClick() {
        this.isGroupExpanded.update(expanded => !expanded);
    }
    /**
     * Method invoked when entering a menu item.
     */
    onMenuItemMouseEnter(menuItem) {
        const disabled = this.disabled() || menuItem?.disabled?.(); // eslint-disable-line @typescript-eslint/prefer-nullish-coalescing
        if (disabled) {
            return;
        }
        this.activeSubmenuItem.set(null);
        // Close submenu when hovering over a menu item.
        if (this._popoverRef.childPopover()?.isSubmenu) {
            this._popoverRef.childPopover().close();
        }
    }
    /**
     * Method invoked when entering a menu item of a submenu.
     */
    onSubmenuItemMouseEnter(menuItem) {
        this.onSubmenuItemClick(menuItem);
    }
    /**
     * Method invoked when entering a menu item of a submenu.
     */
    onSubmenuItemClick(menuItem) {
        const disabled = this.disabled() || menuItem.menuItem.disabled?.(); // eslint-disable-line @typescript-eslint/prefer-nullish-coalescing
        if (disabled) {
            return;
        }
        this.activeSubmenuItem.set(menuItem);
    }
    /**
     * Method invoked when changing the menu filter.
     */
    onFilterChange(filter) {
        this._menuFilter.setFilterText(filter);
    }
    /**
     * Opens a submenu based on {@link activeSubmenuItem}.
     */
    installSubmenuOpener() {
        effect(onCleanup => {
            if (!this.activeSubmenuItem()) {
                return;
            }
            const { menuItem, element } = this.activeSubmenuItem();
            const menu = menuItem.menu;
            untracked(() => {
                const menuRef = this._menuService.open(menu.children, {
                    anchor: element,
                    viewContainerRef: this.popoverViewContainerRef(),
                    filter: menu.filter,
                    width: menu.width,
                    minWidth: menu.minWidth,
                    maxWidth: menu.maxWidth,
                    maxHeight: menu.maxHeight,
                    cssClass: menuItem.cssClass,
                    attributes: menuItem.attributes,
                    submenu: true,
                    align: 'horizontal',
                });
                // Close when opening another submenu.
                onCleanup(() => menuRef.close());
                // Unset when closing submenu, but only if no other submenu has been opened in the meantime.
                menuRef.onClose(() => {
                    const activeSubmenuItem = this.activeSubmenuItem();
                    // Do not unset if another submenu was opened in the meantime.
                    if (activeSubmenuItem?.menuItem !== menuItem) {
                        return;
                    }
                    this.activeSubmenuItem.set(null);
                });
            });
        });
    }
    /**
     * Closes an open popover (submenu or action menu) when this component is reused.
     */
    closeChildPopoverOnComponentReuse() {
        effect(() => {
            // Track change of menu items.
            this.menuItems();
            // Close child popover, if any.
            untracked(() => this._popoverRef.childPopover()?.close());
        });
    }
    /**
     * Locks the initial menu width to maintain a stable width when expanding/collapsing groups or hovering menu items having an action toolbar.
     *
     * Has no effect if a menu group.
     */
    lockInitialMenuWidth() {
        if (inject(SCI_MENU_COMPONENT_ROLE) === 'group') {
            return;
        }
        const host = inject(ElementRef).nativeElement;
        void waitUntilInitialRender().then(() => {
            this.menuSize.update(size => ({ ...size, width: `${host.getBoundingClientRect().width}px` }));
        });
    }
    /**
     * Focuses the filter field based on {@link filter.focus} option.
     */
    focusFilterField() {
        void waitUntilInitialRender().then(() => {
            if (this.filter()?.focus) {
                const filterField = this._filterField()?.nativeElement;
                filterField?.focus();
            }
        });
    }
    /**
     * Computes whether menu items are visible.
     */
    computeGroupExpanded() {
        return linkedSignal(() => {
            const group = this.group();
            return !group || !group.collapsible || !group.collapsed || this._menuFilter.active();
        });
    }
    /**
     * Computes the menu size based on configured size constraints.
     */
    computeMenuSize() {
        const role = inject(SCI_MENU_COMPONENT_ROLE);
        return linkedSignal(() => {
            if (role === 'group') {
                return {};
            }
            const defaultMinWidth = role === 'submenu' ? 'var(--sci-menu-submenu-min-width)' : 'var(--sci-menu-min-width)';
            const preferredMinWidth = this.minWidth() ?? defaultMinWidth;
            return {
                width: this.width(),
                minWidth: this.anchorWidth() ? `max(${preferredMinWidth}, ${this.anchorWidth()})` : preferredMinWidth,
                maxWidth: this.maxWidth() ?? this.width(),
                maxHeight: this.maxHeight(),
            };
        });
    }
    /**
     * Evaluates whether the given menu item (or any of its child menu items) match the active filter.
     */
    matchesFilter(menuItem) {
        return computed(() => {
            if (!this._menuFilter.active()) {
                return true;
            }
            switch (menuItem.type) {
                case 'menu-item':
                    return menuItem.menu ? menuItem.menu.children.some(menuItem => this.matchesFilter(menuItem)()) : this._menuFilter.matches(menuItem)();
                case 'group':
                    return menuItem.children.some(menuItem => this.matchesFilter(menuItem)());
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.0", type: SciMenuComponent, isStandalone: true, selector: "sci-menu", inputs: { menuItems: { classPropertyName: "menuItems", publicName: "menuItems", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, group: { classPropertyName: "group", publicName: "group", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, minWidth: { classPropertyName: "minWidth", publicName: "minWidth", isSignal: true, isRequired: false, transformFunction: null }, maxWidth: { classPropertyName: "maxWidth", publicName: "maxWidth", isSignal: true, isRequired: false, transformFunction: null }, maxHeight: { classPropertyName: "maxHeight", publicName: "maxHeight", isSignal: true, isRequired: false, transformFunction: null }, glyphArea: { classPropertyName: "glyphArea", publicName: "glyphArea", isSignal: true, isRequired: false, transformFunction: null }, anchorWidth: { classPropertyName: "anchorWidth", publicName: "anchorWidth", isSignal: true, isRequired: false, transformFunction: null }, cssClass: { classPropertyName: "cssClass", publicName: "cssClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "style.width": "menuSize().width", "style.min-width": "menuSize().minWidth", "style.max-width": "menuSize().maxWidth", "style.--\u0275menu-max-height": "menuSize().maxHeight", "style.--\u0275menu-scrolling": "scrolling() ? `true` : null", "attr.data-glyph-area": "hasGlyphArea() ? null : `none`", "class": "cssClass()" } }, providers: [
            provideMenuFilter(),
            providePopoverRef(),
        ], viewQueries: [{ propertyName: "_filterField", first: true, predicate: SciMenuFilterComponent, descendants: true, read: ElementRef, isSignal: true }, { propertyName: "_viewport", first: true, predicate: SciViewportComponent, descendants: true, isSignal: true }, { propertyName: "popoverViewContainerRef", first: true, predicate: ["popover_view_container_ref"], descendants: true, read: ViewContainerRef, isSignal: true }], hostDirectives: [{ directive: i1$1.SciAttributesDirective, inputs: ["sciAttributes", "attributes"] }], ngImport: i0, template: "<!-- Filter Field -->\r\n@let filter = this.filter();\r\n@if (filter) {\r\n  <div class=\"filter e2e-filter\">\r\n    <sci-icon>scion.search</sci-icon>\r\n    @let message = filter.placeholder?.() ?? '%scion.components.menu.type_to_filter.action';\r\n    <sci-menu-filter (textChange)=\"onFilterChange($event)\" [placeholder]=\"(message | sciText)()\"/>\r\n  </div>\r\n  <hr>\r\n}\r\n\r\n<!-- Group Header -->\r\n@if (group(); as group) {\r\n  @if (group.collapsible) {\r\n    <button class=\"group-header e2e-group-header\" (click)=\"onGroupButtonClick()\" (mouseenter)=\"onMenuItemMouseEnter(null)\">\r\n      <!-- TODO [menu] use SCION icon -->\r\n      <sci-icon>{{isGroupExpanded() ? 'keyboard_arrow_down' : 'chevron_right'}}</sci-icon>\r\n\r\n      <div class=\"content\">\r\n        <ng-container *ngTemplateOutlet=\"group_header_template\"/>\r\n      </div>\r\n    </button>\r\n  } @else if (group.label) {\r\n    <header class=\"group-header e2e-group-header\">\r\n      <ng-container *ngTemplateOutlet=\"group_header_template\"/>\r\n    </header>\r\n  }\r\n\r\n  <!-- Template for rendering group header. -->\r\n  <ng-template #group_header_template>\r\n    <sci-menu-group-label>{{group.label}}</sci-menu-group-label>\r\n\r\n    @if (group.actions.length && !this.disabled()) {\r\n      <sci-toolbar-group [menuItems]=\"group.actions\"\r\n                         [orientation]=\"'horizontal'\"\r\n                         [popoverViewContainerRef]=\"popoverViewContainerRef()\"\r\n                         (click)=\"$event.stopPropagation()\"\r\n                         class=\"actions e2e-actions\"/>\r\n    }\r\n  </ng-template>\r\n}\r\n\r\n<!-- Render menu items, but only if not collapsed if a group. -->\r\n@if (isGroupExpanded()) {\r\n  <!-- Wrap menu items in a viewport if maximum menu height is set. -->\r\n  @if (maxHeight()) {\r\n    <sci-viewport>\r\n      <ng-container *ngTemplateOutlet=\"menu_items\"/>\r\n    </sci-viewport>\r\n  } @else {\r\n    <ng-container *ngTemplateOutlet=\"menu_items\"/>\r\n  }\r\n\r\n  <ng-template #menu_items>\r\n    @for (menuItem of menuItemsFiltered(); track $index) {\r\n      @let disabled = this.disabled() || menuItem.disabled?.() || false;\r\n\r\n      @switch (menuItem.type) {\r\n        @case ('menu-item') {\r\n          <!-- Menu Item -->\r\n          @if (!menuItem.menu) {\r\n\r\n            <button (mouseenter)=\"onMenuItemMouseEnter(menuItem)\"\r\n                    [attr.disabled]=\"disabled || null\"\r\n                    [class.checked]=\"menuItem.checked?.()\"\r\n                    [class.active]=\"menuItem.active?.()\"\r\n                    [class]=\"menuItem.cssClass\" class=\"menu-item e2e-menu-item\"\r\n                    [sciAttributes]=\"menuItem.attributes\"\r\n                    (click)=\"onSelect(menuItem)\">\r\n              <!-- Render icon if glyph area. -->\r\n              @if (hasGlyphArea() && !group()?.hideGlyphArea) {\r\n                <ng-container *ngTemplateOutlet=\"icon_template; context: {$implicit: menuItem}\"/>\r\n              }\r\n\r\n              <!-- Render label plus accelerators and actions. -->\r\n              <div class=\"content\">\r\n                <ng-container *ngTemplateOutlet=\"label_template; context: {$implicit: menuItem}\"/>\r\n\r\n                @if (menuItem.accelerator) {\r\n                  <span class=\"accelerator\">{{menuItem.accelerator | sciFormatAccelerator}}</span>\r\n                }\r\n\r\n                @if (!disabled && menuItem.actions?.length) {\r\n                  <sci-toolbar-group [menuItems]=\"menuItem.actions!\"\r\n                                     [orientation]=\"'horizontal'\"\r\n                                     [popoverViewContainerRef]=\"popoverViewContainerRef()\"\r\n                                     (click)=\"$event.stopPropagation()\"\r\n                                     [class.menu-open]=\"actions_toolbar.toolbarMenuOpen()\"\r\n                                     class=\"actions e2e-actions\"\r\n                                     #actions_toolbar/>\r\n                }\r\n              </div>\r\n            </button>\r\n          }\r\n\r\n          <!-- Submenu Item -->\r\n          @if (menuItem.menu) {\r\n            <button [attr.disabled]=\"disabled || null\"\r\n                    [attr.title]=\"menuItem.tooltip?.()\"\r\n                    [class.open]=\"activeSubmenuItem()?.menuItem === menuItem\"\r\n                    [class]=\"menuItem.cssClass\" class=\"menu e2e-menu-item\"\r\n                    [sciAttributes]=\"menuItem.attributes\"\r\n                    (mouseenter)=\"onSubmenuItemMouseEnter({menuItem, element})\"\r\n                    (click)=\"onSubmenuItemClick({menuItem, element})\"\r\n                    #element>\r\n              @if (hasGlyphArea() && !group()?.hideGlyphArea) {\r\n                <!-- Render icon if glyph area. -->\r\n                <ng-container *ngTemplateOutlet=\"icon_template; context: {$implicit: menuItem}\"/>\r\n              }\r\n\r\n              <!-- Render label. -->\r\n              <div class=\"content\">\r\n                <ng-container *ngTemplateOutlet=\"label_template; context: {$implicit: menuItem}\"/>\r\n                <!-- TODO [menu] use SCION icon -->\r\n                <sci-icon class=\"chevron\">chevron_right</sci-icon>\r\n              </div>\r\n            </button>\r\n          }\r\n        }\r\n        @case ('group') {\r\n          <sci-menu-group [group]=\"menuItem\"\r\n                          [glyphArea]=\"hasGlyphArea()\"\r\n                          [disabled]=\"disabled\"\r\n                          [class]=\"menuItem.cssClass\" class=\"e2e-menu-group\"/>\r\n        }\r\n      }\r\n    } @empty {\r\n      @let message = filter?.notFoundText?.() ?? '%scion.components.menu.no_items.message';\r\n      <div class=\"message no-items e2e-no-items\">{{(message | sciText)()}}</div>\r\n    }\r\n  </ng-template>\r\n}\r\n\r\n<!-- Location where to insert the menu popover. Must not be a child of the menu item button to prevent hovering the menu item when hovering menu items in the popover. -->\r\n<ng-container #popover_view_container_ref/>\r\n\r\n<!-- Renders the icon of the passed menu item. -->\r\n<ng-template #icon_template let-menuItem>\r\n  @if (menuItem.checked !== undefined) {\r\n    <!-- TODO [menu] use SCION icon -->\r\n    <sci-icon>{{menuItem.checked() ? 'check' : undefined}}</sci-icon>\r\n  } @else if (menuItem.iconLigature) {\r\n    <sci-icon>{{menuItem.iconLigature()}}</sci-icon>\r\n  } @else if (menuItem.iconComponent) {\r\n    <sci-menu-item-icon>\r\n      <ng-container *sciComponentOutlet=\"menuItem.iconComponent\"/>\r\n    </sci-menu-item-icon>\r\n  } @else {\r\n    <sci-menu-item-icon/>\r\n  }\r\n</ng-template>\r\n\r\n<!-- Renders the label of the passed menu item. -->\r\n<ng-template #label_template let-menuItem>\r\n  @if (menuItem.labelText) {\r\n    <sci-menu-item-label>\r\n      {{menuItem.labelText()}}\r\n    </sci-menu-item-label>\r\n  } @else if (menuItem.labelComponent) {\r\n    <sci-menu-item-label>\r\n      <ng-container *sciComponentOutlet=\"menuItem.labelComponent\"/>\r\n    </sci-menu-item-label>\r\n  }\r\n</ng-template>\r\n", styles: ["@charset \"UTF-8\";:host{--sci-icon-size: var(--sci-menu-item-size);--\\275sci-menu-item-padding-inline: calc(.5 * var(--sci-menu-item-size));--\\275sci-menu-item-padding-block: calc(.225 * var(--sci-menu-item-size));--\\275sci-menu-item-min-height: calc(var(--sci-menu-item-size) + 2px);--\\275sci-menu-item-gap-inline: calc(.75 * var(--sci-menu-item-size));--\\275sci-menu-item-gap-block: calc(.125 * var(--sci-menu-item-size));--\\275sci-menu-padding-inline: .4em;--\\275sci-menu-padding-block: .3em;--\\275sci-menu-glyph-area: true;display:grid;gap:var(--\\275sci-menu-item-gap-block) var(--\\275sci-menu-item-gap-inline);align-items:center;font-size:var(--sci-menu-item-font-size);border:1px solid var(--sci-color-border);border-radius:var(--sci-menu-border-radius);color:var(--sci-color-text);background-color:var(--sci-color-background-elevation);padding:var(--\\275sci-menu-padding-block) var(--\\275sci-menu-padding-inline);margin:unset;inset:unset;outline:none;width:max-content;grid-template-columns:var(--sci-menu-item-size) minmax(0,1fr)}:host[data-glyph-area=none]{--\\275sci-menu-glyph-area: false;grid-template-columns:minmax(0,1fr)}:host[popover]:not(:popover-open){display:none}:host:not([popover]){grid-column:1/-1;grid-template-columns:subgrid;border:unset;border-radius:unset;color:inherit;padding:unset;background-color:inherit}:host:not([popover])>header.group-header{grid-column:1/-1;display:flex;gap:var(--\\275sci-menu-item-gap-inline);justify-content:space-between;align-items:center;padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline);-webkit-user-select:none;user-select:none;box-sizing:content-box;min-height:var(--\\275sci-menu-item-min-height)}:host:not([popover])>header.group-header>sci-menu-group-label{flex:auto;color:var(--sci-menu-group-font-color);font-family:var(--sci-menu-group-font-family),sans-serif;font-weight:var(--sci-menu-group-font-weight);font-size:var(--sci-menu-group-font-size);text-overflow:ellipsis;overflow:hidden;white-space:nowrap}:host:not([popover])>header.group-header>sci-toolbar-group.actions{flex:none;align-self:center}:host:not([popover])>button:is(.group-header,#sci-reset){all:unset;text-wrap:nowrap;padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline);border-radius:var(--sci-menu-button-border-radius);-webkit-user-select:none;user-select:none;cursor:var(--sci-menu-button-cursor);min-height:var(--\\275sci-menu-item-min-height);box-sizing:content-box}@container not style(--\\275menu-scrolling: true){:host:not([popover])>button:is(.group-header,#sci-reset):hover:where(:not(:disabled)){background-color:var(--sci-menu-button-background-color-hover)}}:host:not([popover])>button:is(.group-header,#sci-reset):active:where(:not(:disabled)):focus{background-color:var(--sci-menu-button-background-color-active)}:host:not([popover])>button:is(.group-header,#sci-reset):focus:not(:focus-visible){outline:none}:host:not([popover])>button:is(.group-header,#sci-reset):focus-visible{outline:var(--sci-menu-button-outline-width-focus) solid var(--sci-color-accent)}:host:not([popover])>button:is(.group-header,#sci-reset):disabled{color:var(--sci-menu-button-text-color-disabled)}:host:not([popover])>button:is(.group-header,#sci-reset){grid-column:1/-1;display:inline-grid;grid-template-columns:subgrid;align-items:center}:host:not([popover])>button:is(.group-header,#sci-reset):hover{--\\275sci-menu-button-hover: true}:host:not([popover])>button:is(.group-header,#sci-reset)>div.content{display:flex;gap:var(--\\275sci-menu-item-gap-inline);justify-content:space-between;align-items:center}:host:not([popover])>button:is(.group-header,#sci-reset)>div.content>sci-menu-group-label{flex:auto;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}:host:not([popover])>button:is(.group-header,#sci-reset)>div.content>sci-toolbar-group.actions{flex:none;align-self:center}@container style(--\\275sci-menu-button-hover: true){:host:not([popover])>button:is(.group-header,#sci-reset)>div.content>sci-toolbar-group.actions{--sci-toolbar-item-background-color-hover: var(--sci-menu-action-background-color-hover);--sci-toolbar-item-background-color-active: var(--sci-menu-action-background-color-active)}}:host:has(>sci-viewport){padding:var(--\\275sci-menu-padding-block) 0}:host:has(>sci-viewport)>header.group-header,:host:has(>sci-viewport)>button.group-header,:host:has(>sci-viewport)>div.filter,:host:has(>sci-viewport)>hr{margin:0 var(--\\275sci-menu-padding-inline)}:host>sci-viewport{grid-column:1/-1;max-height:var(--\\275menu-max-height)}:host>sci-viewport::part(content){grid-column:1/-1;display:grid;gap:var(--\\275sci-menu-item-gap-block) var(--\\275sci-menu-item-gap-inline);grid-template-columns:var(--sci-menu-item-size) minmax(0,1fr);padding:2px var(--\\275sci-menu-padding-inline)}@container style(--\\275sci-menu-glyph-area: false){:host>sci-viewport::part(content){grid-template-columns:minmax(0,1fr)}}:host>div.filter{grid-column:1/-1;display:inline-grid;grid-template-columns:subgrid;align-items:center;padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline);-webkit-user-select:none;user-select:none;border-radius:var(--sci-menu-filter-outline-border-radius);box-sizing:content-box;min-height:var(--\\275sci-menu-item-min-height)}:host>div.filter:focus-within{outline:var(--sci-menu-filter-outline-width-focus) solid var(--sci-color-accent)}@container style(--\\275sci-menu-glyph-area: false){:host>div.filter{display:flex;gap:var(--\\275sci-menu-item-gap-inline)}:host>div.filter>sci-icon{flex:none}:host>div.filter>sci-menu-filter{flex:auto}}:host>hr{all:unset;grid-column:1/-1;height:1px;background-color:var(--sci-color-border)}:host div.message.no-items{grid-column:1/-1;justify-self:center;display:block;color:var(--sci-color-text-subtlest);padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline)}:host *:not(hr)+sci-menu-group:not(:has(>sci-menu-group:first-child)):before{content:\"\";grid-column:1/-1;height:1px;background-color:var(--sci-color-border)}:host sci-menu-group:not(:last-child):not(:has(+sci-menu-group,+sci-menu:last-child)):after{content:\"\";grid-column:1/-1;height:1px;background-color:var(--sci-color-border)}:host button:is(.menu-item,.menu,#sci-reset){all:unset;text-wrap:nowrap;padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline);border-radius:var(--sci-menu-button-border-radius);-webkit-user-select:none;user-select:none;cursor:var(--sci-menu-button-cursor);min-height:var(--\\275sci-menu-item-min-height);box-sizing:content-box}@container not style(--\\275menu-scrolling: true){:host button:is(.menu-item,.menu,#sci-reset):hover:where(:not(:disabled)){background-color:var(--sci-menu-button-background-color-hover)}}:host button:is(.menu-item,.menu,#sci-reset):active:where(:not(:disabled)):focus{background-color:var(--sci-menu-button-background-color-active)}:host button:is(.menu-item,.menu,#sci-reset):focus:not(:focus-visible){outline:none}:host button:is(.menu-item,.menu,#sci-reset):focus-visible{outline:var(--sci-menu-button-outline-width-focus) solid var(--sci-color-accent)}:host button:is(.menu-item,.menu,#sci-reset):disabled{color:var(--sci-menu-button-text-color-disabled)}:host button:is(.menu-item,.menu,#sci-reset){grid-column:1/-1;display:inline-grid;grid-template-columns:subgrid;align-items:center;position:relative}:host button:is(.menu-item,.menu,#sci-reset):hover{--\\275sci-menu-button-hover: true}:host button:is(.menu-item,.menu,#sci-reset):not(:disabled):is(:hover,.checked,.active,:has(sci-toolbar-group.actions.menu-open)){--\\275sci-action-toolbar-visible: true}:host button:is(.menu-item,.menu,#sci-reset).menu-item.active:before{position:absolute;content:\"\";box-sizing:border-box;height:calc(100% - var(--sci-menu-item-activemark-border-radius));width:var(--sci-menu-item-activemark-width);left:calc(-1 * var(--\\275sci-menu-padding-inline) + 1px);border-radius:var(--sci-menu-item-activemark-border-radius);background-color:var(--sci-menu-item-activemark-background-color)}:host button:is(.menu-item,.menu,#sci-reset).menu.open{background-color:var(--sci-menu-button-background-color-hover)}:host button:is(.menu-item,.menu,#sci-reset).menu>div.content>sci-icon.chevron{--sci-icon-size: var(--sci-menu-submenu-chevron-size)}:host button:is(.menu-item,.menu,#sci-reset)>sci-menu-item-icon{display:inline-grid;place-content:center;height:var(--sci-menu-item-size);width:var(--sci-menu-item-size)}:host button:is(.menu-item,.menu,#sci-reset)>div.content:first-child{grid-column:1/-1}:host button:is(.menu-item,.menu,#sci-reset)>div.content{display:flex;align-items:center;gap:var(--\\275sci-menu-item-gap-inline)}:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-menu-item-label{flex:auto;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}:host button:is(.menu-item,.menu,#sci-reset)>div.content>span.accelerator{flex:none;color:var(--sci-color-text-subtlest);font-size:var(--sci-menu-item-accelerator-font-size)}@container style(--\\275sci-action-toolbar-visible: true){:host button:is(.menu-item,.menu,#sci-reset)>div.content>span.accelerator:has(+sci-toolbar-group.actions){display:none}}:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-toolbar-group.actions{flex:none;align-self:center}@container style(--\\275sci-menu-button-hover: true){:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-toolbar-group.actions{--sci-toolbar-item-background-color-hover: var(--sci-menu-action-background-color-hover);--sci-toolbar-item-background-color-active: var(--sci-menu-action-background-color-active)}}@container style(--\\275menu-scrolling: true){:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-toolbar-group.actions{visibility:hidden}}@container not style(--\\275sci-action-toolbar-visible: true){:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-toolbar-group.actions{display:none}}:host sci-toolbar-group.actions{margin-right:calc(var(--\\275sci-menu-item-padding-inline) / -2);--sci-toolbar-item-border-radius: var(--sci-corner-small);--sci-toolbar-item-padding-block: 0}\n"], dependencies: [{ kind: "component", type: SciMenuGroupComponent, selector: "sci-menu-group", inputs: ["group", "glyphArea", "disabled"] }, { kind: "component", type: SciMenuFilterComponent, selector: "sci-menu-filter", inputs: ["placeholder", "text"], outputs: ["textChange"] }, { kind: "component", type: SciToolGroupComponent, selector: "sci-toolbar-group", inputs: ["menuItems", "orientation", "disabled", "popoverViewContainerRef"] }, { kind: "component", type: SciViewportComponent, selector: "sci-viewport", inputs: ["scrollbarStyle"], outputs: ["scroll"] }, { kind: "directive", type: SciComponentOutletDirective, selector: "ng-template[sciComponentOutlet]", inputs: ["sciComponentOutlet"] }, { kind: "directive", type: SciAttributesDirective, selector: "[sciAttributes]", inputs: ["sciAttributes"] }, { kind: "component", type: SciIconComponent, selector: "sci-icon" }, { kind: "component", type: SciMenuGroupLabelComponent, selector: "sci-menu-group-label" }, { kind: "component", type: SciMenuItemLabelComponent, selector: "sci-menu-item-label" }, { kind: "component", type: SciMenuItemIconComponent, selector: "sci-menu-item-icon" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: SciTextPipe, name: "sciText" }, { kind: "pipe", type: SciFormatAcceleratorPipe, name: "sciFormatAccelerator" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sci-menu', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        SciMenuGroupComponent,
                        SciMenuFilterComponent,
                        SciToolGroupComponent,
                        SciViewportComponent,
                        SciTextPipe,
                        SciComponentOutletDirective,
                        SciAttributesDirective,
                        SciIconComponent,
                        SciMenuGroupLabelComponent,
                        SciMenuItemLabelComponent,
                        SciMenuItemIconComponent,
                        SciFormatAcceleratorPipe,
                        NgTemplateOutlet,
                    ], providers: [
                        provideMenuFilter(),
                        providePopoverRef(),
                    ], host: {
                        '[style.width]': 'menuSize().width',
                        '[style.min-width]': 'menuSize().minWidth',
                        '[style.max-width]': 'menuSize().maxWidth',
                        '[style.--ɵmenu-max-height]': 'menuSize().maxHeight',
                        '[style.--ɵmenu-scrolling]': 'scrolling() ? `true` : null',
                        '[attr.data-glyph-area]': 'hasGlyphArea() ? null : `none`',
                        '[class]': 'cssClass()',
                    }, hostDirectives: [
                        { directive: SciAttributesDirective, inputs: ['sciAttributes: attributes'] },
                    ], template: "<!-- Filter Field -->\r\n@let filter = this.filter();\r\n@if (filter) {\r\n  <div class=\"filter e2e-filter\">\r\n    <sci-icon>scion.search</sci-icon>\r\n    @let message = filter.placeholder?.() ?? '%scion.components.menu.type_to_filter.action';\r\n    <sci-menu-filter (textChange)=\"onFilterChange($event)\" [placeholder]=\"(message | sciText)()\"/>\r\n  </div>\r\n  <hr>\r\n}\r\n\r\n<!-- Group Header -->\r\n@if (group(); as group) {\r\n  @if (group.collapsible) {\r\n    <button class=\"group-header e2e-group-header\" (click)=\"onGroupButtonClick()\" (mouseenter)=\"onMenuItemMouseEnter(null)\">\r\n      <!-- TODO [menu] use SCION icon -->\r\n      <sci-icon>{{isGroupExpanded() ? 'keyboard_arrow_down' : 'chevron_right'}}</sci-icon>\r\n\r\n      <div class=\"content\">\r\n        <ng-container *ngTemplateOutlet=\"group_header_template\"/>\r\n      </div>\r\n    </button>\r\n  } @else if (group.label) {\r\n    <header class=\"group-header e2e-group-header\">\r\n      <ng-container *ngTemplateOutlet=\"group_header_template\"/>\r\n    </header>\r\n  }\r\n\r\n  <!-- Template for rendering group header. -->\r\n  <ng-template #group_header_template>\r\n    <sci-menu-group-label>{{group.label}}</sci-menu-group-label>\r\n\r\n    @if (group.actions.length && !this.disabled()) {\r\n      <sci-toolbar-group [menuItems]=\"group.actions\"\r\n                         [orientation]=\"'horizontal'\"\r\n                         [popoverViewContainerRef]=\"popoverViewContainerRef()\"\r\n                         (click)=\"$event.stopPropagation()\"\r\n                         class=\"actions e2e-actions\"/>\r\n    }\r\n  </ng-template>\r\n}\r\n\r\n<!-- Render menu items, but only if not collapsed if a group. -->\r\n@if (isGroupExpanded()) {\r\n  <!-- Wrap menu items in a viewport if maximum menu height is set. -->\r\n  @if (maxHeight()) {\r\n    <sci-viewport>\r\n      <ng-container *ngTemplateOutlet=\"menu_items\"/>\r\n    </sci-viewport>\r\n  } @else {\r\n    <ng-container *ngTemplateOutlet=\"menu_items\"/>\r\n  }\r\n\r\n  <ng-template #menu_items>\r\n    @for (menuItem of menuItemsFiltered(); track $index) {\r\n      @let disabled = this.disabled() || menuItem.disabled?.() || false;\r\n\r\n      @switch (menuItem.type) {\r\n        @case ('menu-item') {\r\n          <!-- Menu Item -->\r\n          @if (!menuItem.menu) {\r\n\r\n            <button (mouseenter)=\"onMenuItemMouseEnter(menuItem)\"\r\n                    [attr.disabled]=\"disabled || null\"\r\n                    [class.checked]=\"menuItem.checked?.()\"\r\n                    [class.active]=\"menuItem.active?.()\"\r\n                    [class]=\"menuItem.cssClass\" class=\"menu-item e2e-menu-item\"\r\n                    [sciAttributes]=\"menuItem.attributes\"\r\n                    (click)=\"onSelect(menuItem)\">\r\n              <!-- Render icon if glyph area. -->\r\n              @if (hasGlyphArea() && !group()?.hideGlyphArea) {\r\n                <ng-container *ngTemplateOutlet=\"icon_template; context: {$implicit: menuItem}\"/>\r\n              }\r\n\r\n              <!-- Render label plus accelerators and actions. -->\r\n              <div class=\"content\">\r\n                <ng-container *ngTemplateOutlet=\"label_template; context: {$implicit: menuItem}\"/>\r\n\r\n                @if (menuItem.accelerator) {\r\n                  <span class=\"accelerator\">{{menuItem.accelerator | sciFormatAccelerator}}</span>\r\n                }\r\n\r\n                @if (!disabled && menuItem.actions?.length) {\r\n                  <sci-toolbar-group [menuItems]=\"menuItem.actions!\"\r\n                                     [orientation]=\"'horizontal'\"\r\n                                     [popoverViewContainerRef]=\"popoverViewContainerRef()\"\r\n                                     (click)=\"$event.stopPropagation()\"\r\n                                     [class.menu-open]=\"actions_toolbar.toolbarMenuOpen()\"\r\n                                     class=\"actions e2e-actions\"\r\n                                     #actions_toolbar/>\r\n                }\r\n              </div>\r\n            </button>\r\n          }\r\n\r\n          <!-- Submenu Item -->\r\n          @if (menuItem.menu) {\r\n            <button [attr.disabled]=\"disabled || null\"\r\n                    [attr.title]=\"menuItem.tooltip?.()\"\r\n                    [class.open]=\"activeSubmenuItem()?.menuItem === menuItem\"\r\n                    [class]=\"menuItem.cssClass\" class=\"menu e2e-menu-item\"\r\n                    [sciAttributes]=\"menuItem.attributes\"\r\n                    (mouseenter)=\"onSubmenuItemMouseEnter({menuItem, element})\"\r\n                    (click)=\"onSubmenuItemClick({menuItem, element})\"\r\n                    #element>\r\n              @if (hasGlyphArea() && !group()?.hideGlyphArea) {\r\n                <!-- Render icon if glyph area. -->\r\n                <ng-container *ngTemplateOutlet=\"icon_template; context: {$implicit: menuItem}\"/>\r\n              }\r\n\r\n              <!-- Render label. -->\r\n              <div class=\"content\">\r\n                <ng-container *ngTemplateOutlet=\"label_template; context: {$implicit: menuItem}\"/>\r\n                <!-- TODO [menu] use SCION icon -->\r\n                <sci-icon class=\"chevron\">chevron_right</sci-icon>\r\n              </div>\r\n            </button>\r\n          }\r\n        }\r\n        @case ('group') {\r\n          <sci-menu-group [group]=\"menuItem\"\r\n                          [glyphArea]=\"hasGlyphArea()\"\r\n                          [disabled]=\"disabled\"\r\n                          [class]=\"menuItem.cssClass\" class=\"e2e-menu-group\"/>\r\n        }\r\n      }\r\n    } @empty {\r\n      @let message = filter?.notFoundText?.() ?? '%scion.components.menu.no_items.message';\r\n      <div class=\"message no-items e2e-no-items\">{{(message | sciText)()}}</div>\r\n    }\r\n  </ng-template>\r\n}\r\n\r\n<!-- Location where to insert the menu popover. Must not be a child of the menu item button to prevent hovering the menu item when hovering menu items in the popover. -->\r\n<ng-container #popover_view_container_ref/>\r\n\r\n<!-- Renders the icon of the passed menu item. -->\r\n<ng-template #icon_template let-menuItem>\r\n  @if (menuItem.checked !== undefined) {\r\n    <!-- TODO [menu] use SCION icon -->\r\n    <sci-icon>{{menuItem.checked() ? 'check' : undefined}}</sci-icon>\r\n  } @else if (menuItem.iconLigature) {\r\n    <sci-icon>{{menuItem.iconLigature()}}</sci-icon>\r\n  } @else if (menuItem.iconComponent) {\r\n    <sci-menu-item-icon>\r\n      <ng-container *sciComponentOutlet=\"menuItem.iconComponent\"/>\r\n    </sci-menu-item-icon>\r\n  } @else {\r\n    <sci-menu-item-icon/>\r\n  }\r\n</ng-template>\r\n\r\n<!-- Renders the label of the passed menu item. -->\r\n<ng-template #label_template let-menuItem>\r\n  @if (menuItem.labelText) {\r\n    <sci-menu-item-label>\r\n      {{menuItem.labelText()}}\r\n    </sci-menu-item-label>\r\n  } @else if (menuItem.labelComponent) {\r\n    <sci-menu-item-label>\r\n      <ng-container *sciComponentOutlet=\"menuItem.labelComponent\"/>\r\n    </sci-menu-item-label>\r\n  }\r\n</ng-template>\r\n", styles: ["@charset \"UTF-8\";:host{--sci-icon-size: var(--sci-menu-item-size);--\\275sci-menu-item-padding-inline: calc(.5 * var(--sci-menu-item-size));--\\275sci-menu-item-padding-block: calc(.225 * var(--sci-menu-item-size));--\\275sci-menu-item-min-height: calc(var(--sci-menu-item-size) + 2px);--\\275sci-menu-item-gap-inline: calc(.75 * var(--sci-menu-item-size));--\\275sci-menu-item-gap-block: calc(.125 * var(--sci-menu-item-size));--\\275sci-menu-padding-inline: .4em;--\\275sci-menu-padding-block: .3em;--\\275sci-menu-glyph-area: true;display:grid;gap:var(--\\275sci-menu-item-gap-block) var(--\\275sci-menu-item-gap-inline);align-items:center;font-size:var(--sci-menu-item-font-size);border:1px solid var(--sci-color-border);border-radius:var(--sci-menu-border-radius);color:var(--sci-color-text);background-color:var(--sci-color-background-elevation);padding:var(--\\275sci-menu-padding-block) var(--\\275sci-menu-padding-inline);margin:unset;inset:unset;outline:none;width:max-content;grid-template-columns:var(--sci-menu-item-size) minmax(0,1fr)}:host[data-glyph-area=none]{--\\275sci-menu-glyph-area: false;grid-template-columns:minmax(0,1fr)}:host[popover]:not(:popover-open){display:none}:host:not([popover]){grid-column:1/-1;grid-template-columns:subgrid;border:unset;border-radius:unset;color:inherit;padding:unset;background-color:inherit}:host:not([popover])>header.group-header{grid-column:1/-1;display:flex;gap:var(--\\275sci-menu-item-gap-inline);justify-content:space-between;align-items:center;padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline);-webkit-user-select:none;user-select:none;box-sizing:content-box;min-height:var(--\\275sci-menu-item-min-height)}:host:not([popover])>header.group-header>sci-menu-group-label{flex:auto;color:var(--sci-menu-group-font-color);font-family:var(--sci-menu-group-font-family),sans-serif;font-weight:var(--sci-menu-group-font-weight);font-size:var(--sci-menu-group-font-size);text-overflow:ellipsis;overflow:hidden;white-space:nowrap}:host:not([popover])>header.group-header>sci-toolbar-group.actions{flex:none;align-self:center}:host:not([popover])>button:is(.group-header,#sci-reset){all:unset;text-wrap:nowrap;padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline);border-radius:var(--sci-menu-button-border-radius);-webkit-user-select:none;user-select:none;cursor:var(--sci-menu-button-cursor);min-height:var(--\\275sci-menu-item-min-height);box-sizing:content-box}@container not style(--\\275menu-scrolling: true){:host:not([popover])>button:is(.group-header,#sci-reset):hover:where(:not(:disabled)){background-color:var(--sci-menu-button-background-color-hover)}}:host:not([popover])>button:is(.group-header,#sci-reset):active:where(:not(:disabled)):focus{background-color:var(--sci-menu-button-background-color-active)}:host:not([popover])>button:is(.group-header,#sci-reset):focus:not(:focus-visible){outline:none}:host:not([popover])>button:is(.group-header,#sci-reset):focus-visible{outline:var(--sci-menu-button-outline-width-focus) solid var(--sci-color-accent)}:host:not([popover])>button:is(.group-header,#sci-reset):disabled{color:var(--sci-menu-button-text-color-disabled)}:host:not([popover])>button:is(.group-header,#sci-reset){grid-column:1/-1;display:inline-grid;grid-template-columns:subgrid;align-items:center}:host:not([popover])>button:is(.group-header,#sci-reset):hover{--\\275sci-menu-button-hover: true}:host:not([popover])>button:is(.group-header,#sci-reset)>div.content{display:flex;gap:var(--\\275sci-menu-item-gap-inline);justify-content:space-between;align-items:center}:host:not([popover])>button:is(.group-header,#sci-reset)>div.content>sci-menu-group-label{flex:auto;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}:host:not([popover])>button:is(.group-header,#sci-reset)>div.content>sci-toolbar-group.actions{flex:none;align-self:center}@container style(--\\275sci-menu-button-hover: true){:host:not([popover])>button:is(.group-header,#sci-reset)>div.content>sci-toolbar-group.actions{--sci-toolbar-item-background-color-hover: var(--sci-menu-action-background-color-hover);--sci-toolbar-item-background-color-active: var(--sci-menu-action-background-color-active)}}:host:has(>sci-viewport){padding:var(--\\275sci-menu-padding-block) 0}:host:has(>sci-viewport)>header.group-header,:host:has(>sci-viewport)>button.group-header,:host:has(>sci-viewport)>div.filter,:host:has(>sci-viewport)>hr{margin:0 var(--\\275sci-menu-padding-inline)}:host>sci-viewport{grid-column:1/-1;max-height:var(--\\275menu-max-height)}:host>sci-viewport::part(content){grid-column:1/-1;display:grid;gap:var(--\\275sci-menu-item-gap-block) var(--\\275sci-menu-item-gap-inline);grid-template-columns:var(--sci-menu-item-size) minmax(0,1fr);padding:2px var(--\\275sci-menu-padding-inline)}@container style(--\\275sci-menu-glyph-area: false){:host>sci-viewport::part(content){grid-template-columns:minmax(0,1fr)}}:host>div.filter{grid-column:1/-1;display:inline-grid;grid-template-columns:subgrid;align-items:center;padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline);-webkit-user-select:none;user-select:none;border-radius:var(--sci-menu-filter-outline-border-radius);box-sizing:content-box;min-height:var(--\\275sci-menu-item-min-height)}:host>div.filter:focus-within{outline:var(--sci-menu-filter-outline-width-focus) solid var(--sci-color-accent)}@container style(--\\275sci-menu-glyph-area: false){:host>div.filter{display:flex;gap:var(--\\275sci-menu-item-gap-inline)}:host>div.filter>sci-icon{flex:none}:host>div.filter>sci-menu-filter{flex:auto}}:host>hr{all:unset;grid-column:1/-1;height:1px;background-color:var(--sci-color-border)}:host div.message.no-items{grid-column:1/-1;justify-self:center;display:block;color:var(--sci-color-text-subtlest);padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline)}:host *:not(hr)+sci-menu-group:not(:has(>sci-menu-group:first-child)):before{content:\"\";grid-column:1/-1;height:1px;background-color:var(--sci-color-border)}:host sci-menu-group:not(:last-child):not(:has(+sci-menu-group,+sci-menu:last-child)):after{content:\"\";grid-column:1/-1;height:1px;background-color:var(--sci-color-border)}:host button:is(.menu-item,.menu,#sci-reset){all:unset;text-wrap:nowrap;padding:var(--\\275sci-menu-item-padding-block) var(--\\275sci-menu-item-padding-inline);border-radius:var(--sci-menu-button-border-radius);-webkit-user-select:none;user-select:none;cursor:var(--sci-menu-button-cursor);min-height:var(--\\275sci-menu-item-min-height);box-sizing:content-box}@container not style(--\\275menu-scrolling: true){:host button:is(.menu-item,.menu,#sci-reset):hover:where(:not(:disabled)){background-color:var(--sci-menu-button-background-color-hover)}}:host button:is(.menu-item,.menu,#sci-reset):active:where(:not(:disabled)):focus{background-color:var(--sci-menu-button-background-color-active)}:host button:is(.menu-item,.menu,#sci-reset):focus:not(:focus-visible){outline:none}:host button:is(.menu-item,.menu,#sci-reset):focus-visible{outline:var(--sci-menu-button-outline-width-focus) solid var(--sci-color-accent)}:host button:is(.menu-item,.menu,#sci-reset):disabled{color:var(--sci-menu-button-text-color-disabled)}:host button:is(.menu-item,.menu,#sci-reset){grid-column:1/-1;display:inline-grid;grid-template-columns:subgrid;align-items:center;position:relative}:host button:is(.menu-item,.menu,#sci-reset):hover{--\\275sci-menu-button-hover: true}:host button:is(.menu-item,.menu,#sci-reset):not(:disabled):is(:hover,.checked,.active,:has(sci-toolbar-group.actions.menu-open)){--\\275sci-action-toolbar-visible: true}:host button:is(.menu-item,.menu,#sci-reset).menu-item.active:before{position:absolute;content:\"\";box-sizing:border-box;height:calc(100% - var(--sci-menu-item-activemark-border-radius));width:var(--sci-menu-item-activemark-width);left:calc(-1 * var(--\\275sci-menu-padding-inline) + 1px);border-radius:var(--sci-menu-item-activemark-border-radius);background-color:var(--sci-menu-item-activemark-background-color)}:host button:is(.menu-item,.menu,#sci-reset).menu.open{background-color:var(--sci-menu-button-background-color-hover)}:host button:is(.menu-item,.menu,#sci-reset).menu>div.content>sci-icon.chevron{--sci-icon-size: var(--sci-menu-submenu-chevron-size)}:host button:is(.menu-item,.menu,#sci-reset)>sci-menu-item-icon{display:inline-grid;place-content:center;height:var(--sci-menu-item-size);width:var(--sci-menu-item-size)}:host button:is(.menu-item,.menu,#sci-reset)>div.content:first-child{grid-column:1/-1}:host button:is(.menu-item,.menu,#sci-reset)>div.content{display:flex;align-items:center;gap:var(--\\275sci-menu-item-gap-inline)}:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-menu-item-label{flex:auto;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}:host button:is(.menu-item,.menu,#sci-reset)>div.content>span.accelerator{flex:none;color:var(--sci-color-text-subtlest);font-size:var(--sci-menu-item-accelerator-font-size)}@container style(--\\275sci-action-toolbar-visible: true){:host button:is(.menu-item,.menu,#sci-reset)>div.content>span.accelerator:has(+sci-toolbar-group.actions){display:none}}:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-toolbar-group.actions{flex:none;align-self:center}@container style(--\\275sci-menu-button-hover: true){:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-toolbar-group.actions{--sci-toolbar-item-background-color-hover: var(--sci-menu-action-background-color-hover);--sci-toolbar-item-background-color-active: var(--sci-menu-action-background-color-active)}}@container style(--\\275menu-scrolling: true){:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-toolbar-group.actions{visibility:hidden}}@container not style(--\\275sci-action-toolbar-visible: true){:host button:is(.menu-item,.menu,#sci-reset)>div.content>sci-toolbar-group.actions{display:none}}:host sci-toolbar-group.actions{margin-right:calc(var(--\\275sci-menu-item-padding-inline) / -2);--sci-toolbar-item-border-radius: var(--sci-corner-small);--sci-toolbar-item-padding-block: 0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { menuItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "menuItems", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], group: [{ type: i0.Input, args: [{ isSignal: true, alias: "group", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], minWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "minWidth", required: false }] }], maxWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxWidth", required: false }] }], maxHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxHeight", required: false }] }], glyphArea: [{ type: i0.Input, args: [{ isSignal: true, alias: "glyphArea", required: false }] }], anchorWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "anchorWidth", required: false }] }], cssClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "cssClass", required: false }] }], _filterField: [{ type: i0.ViewChild, args: [i0.forwardRef(() => SciMenuFilterComponent), { ...{ read: (ElementRef) }, isSignal: true }] }], _viewport: [{ type: i0.ViewChild, args: [i0.forwardRef(() => SciViewportComponent), { isSignal: true }] }], popoverViewContainerRef: [{ type: i0.ViewChild, args: ['popover_view_container_ref', { ...{ read: ViewContainerRef }, isSignal: true }] }] } });
/**
 * Evaluates whether the given menu items (or any child groups) require a glyph area for displaying icons and checkmarks.
 */
function requiresGlyphArea(menuItems) {
    return menuItems.some(menuItem => {
        switch (menuItem.type) {
            case 'menu-item':
                return !!menuItem.iconLigature || !!menuItem.iconComponent || !!menuItem.checked;
            case 'group':
                return !!menuItem.collapsible || requiresGlyphArea(menuItem.children);
        }
    });
}
/**
 * Provides {@link SCI_MENU_COMPONENT_ROLE} for injection.
 *
 * To support dynamic component creation via {@link ViewContainerRef.createComponent}, returns a directive instead of a static provider.
 */
function provideMenuComponentRole(role) {
    class RoleProvider {
        static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: RoleProvider, deps: [], target: i0.ɵɵFactoryTarget.Directive });
        static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.0.0", type: RoleProvider, isStandalone: true, providers: [{ provide: SCI_MENU_COMPONENT_ROLE, useValue: role }], ngImport: i0 });
    }
    i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: RoleProvider, decorators: [{
                type: Directive,
                args: [{ providers: [{ provide: SCI_MENU_COMPONENT_ROLE, useValue: role }] }]
            }] });
    return RoleProvider;
}
/**
 * Provides {@link MenuFilter} for injection.
 */
function provideMenuFilter() {
    return {
        provide: MenuFilter,
        useFactory: () => {
            // To prevent filtering of menu items in menus of action toolbars, inherit parent filter only if a group or submenu.
            const role = inject(SCI_MENU_COMPONENT_ROLE);
            const inheritFilter = role === 'group' || role == 'submenu';
            return new MenuFilter(inheritFilter ? inject(MenuFilter, { skipSelf: true, optional: true }) : null);
        },
    };
}
/**
 * Provides {@link PopoverRef} for injection.
 */
function providePopoverRef() {
    return {
        provide: PopoverRef,
        useFactory: () => {
            const parentPopover = inject(PopoverRef, { skipSelf: true, optional: true });
            if (!parentPopover) {
                return new PopoverRef({ isSubmenu: false }); // top-level menu
            }
            switch (inject(SCI_MENU_COMPONENT_ROLE)) {
                case 'submenu':
                    return new PopoverRef({ isSubmenu: true });
                case 'menu':
                    return new PopoverRef({ isSubmenu: false }); // menu in an action toolbar
                case 'group':
                    return parentPopover;
            }
        },
    };
}
/**
 * Resolves when the component becomes visible.
 */
function waitUntilInitialRender() {
    const host = inject(ElementRef).nativeElement;
    return firstValueFrom(fromResize$(host, { box: 'border-box' })
        .pipe(subscribeOn(animationFrameScheduler), filter(() => host.checkVisibility()), // display set to `none` until initial menu items
    map(() => undefined)));
}
/**
 * Indicates whether {@link SciMenuComponent} is acting as a menu, submenu, or group.
 */
const SCI_MENU_COMPONENT_ROLE = new InjectionToken('SCI_MENU_COMPONENT_ROLE');

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class SciMenuOpener {
    _injector = inject(Injector);
    openMenu(menu, options) {
        // Create injection context to dispose resources when closing the menu.
        const injector = createDestroyableInjector({ parent: this._injector });
        const menuItems = Array.isArray(menu) ? signal(menu) : this.menuService.menuItems(menu, options.context ?? new Map(), { injector, metadata: options.metadata });
        return runInInjectionContext(injector, () => {
            // Get or create anchor at specified origin.
            const anchorElement = options.anchor instanceof ElementRef || options.anchor instanceof HTMLElement ? coerceElement(options.anchor) : this.createVirtualAnchor(options.anchor, { viewContainerRef: options.viewContainerRef });
            // Create menu popover.
            const componentRef = this.createMenuPopover(menuItems, anchorElement, options);
            componentRef.onDestroy(() => injector.destroy());
            return {
                close: () => componentRef.destroy(),
                onClose: onClose => componentRef.hostView.destroyed ? onClose() : componentRef.onDestroy(onClose), // Call callback immediately if already destroyed.
            };
        });
    }
    /**
     * Reference to the menu service.
     *
     * - Do not inject during construction to prevent injection cycle.
     * - Do not use {@link SciMenuRegistry} to proxy calls through the adapter chain.
     */
    get menuService() {
        return this._injector.get(ɵSciMenuService);
    }
    createMenuPopover(menuItems, anchorElement, options) {
        const anchorSize = dimension(anchorElement);
        const bindings = [
            inputBinding('menuItems', menuItems),
            inputBinding('filter', signal(coerceFilterDescriptor(options.filter))),
            inputBinding('width', signal(options.width)),
            inputBinding('minWidth', signal(options.minWidth)),
            inputBinding('maxWidth', signal(options.maxWidth)),
            inputBinding('maxHeight', signal(options.maxHeight)),
            inputBinding('anchorWidth', computed(() => options.align === 'vertical' ? anchorSize().offsetWidth : undefined)),
            inputBinding('cssClass', signal(Arrays.coerce(options.cssClass))),
            inputBinding('attributes', signal(options.attributes)),
        ];
        // Create menu component and attach it to the DOM.
        const componentRef = (() => {
            if (options.viewContainerRef) {
                return options.viewContainerRef.createComponent(SciMenuComponent, {
                    directives: [provideMenuComponentRole(options.submenu ? 'submenu' : 'menu')],
                    bindings,
                });
            }
            else {
                const popoverElement = inject(DOCUMENT).createElement('sci-menu');
                const componentRef = createComponent(SciMenuComponent, {
                    environmentInjector: inject(EnvironmentInjector),
                    hostElement: popoverElement, // is removed when destroying the component
                    directives: [provideMenuComponentRole(options.submenu ? 'submenu' : 'menu')],
                    bindings,
                });
                // Insert popover after the anchor node.
                anchorElement.after(popoverElement);
                // Attach component to include in change detection.
                inject(ApplicationRef).attachView(componentRef.hostView);
                return componentRef;
            }
        })();
        // Bind popover to anchor.
        const popoverElement = componentRef.location.nativeElement;
        this.bindPopoverToAnchor({ popoverElement, anchorElement, align: options.align ?? 'vertical' });
        // Destroy component when closing the popover.
        popoverElement.addEventListener('toggle', (event) => {
            if (event.newState === 'closed') {
                componentRef.destroy();
            }
        });
        // Run change detection.
        componentRef.changeDetectorRef.detectChanges();
        // Show popover.
        popoverElement.showPopover();
        // Focus popover and delay display until menu items.
        this.focusAndDelayPopover(menuItems, popoverElement, { focus: !options.submenu });
        return componentRef;
    }
    /**
     * Popup must receive focus for microfrontends to work with escape.
     * Prevent flickering while opening, so wait until items.
     *
     * TODO [menu] Find better name.
     */
    focusAndDelayPopover(menuItems, popoverElement, options) {
        if (!menuItems().length && menuItems() !== NULL_MENU_CONTRIBUTIONS) {
            setStyles(popoverElement, { 'display': 'none' });
            effect(() => {
                if (menuItems().length) {
                    setStyles(popoverElement, { 'display': null });
                    if (options.focus) {
                        setAttributes(popoverElement, { 'tabindex': '-1' });
                        popoverElement.focus();
                    }
                }
            });
        }
        else if (options.focus) {
            setAttributes(popoverElement, { 'tabindex': '-1' });
            popoverElement.focus();
        }
    }
    bindPopoverToAnchor(binding) {
        const { popoverElement, anchorElement, align } = binding;
        const popoverId = `scimenu-${UUID.randomUUID().substring(0, 8)}`;
        // Connect anchor to popover.
        setAttributes(anchorElement, {
            'popovertarget': popoverId,
            'popovertargetaction': 'show',
        });
        setStyles(anchorElement, {
            'anchor-name': `--${popoverId}`,
        });
        // Connect popover to anchor.
        setAttributes(popoverElement, {
            'id': popoverId,
            'popover': 'auto',
        });
        if (align === 'horizontal') {
            setStyles(popoverElement, {
                'position-anchor': `--${popoverId}`,
                'position-try-fallbacks': 'flip-inline, flip-block, flip-inline flip-block',
                'top': `calc(anchor(top) - var(--ɵsci-menu-padding-block))`,
                'left': 'calc(anchor(right) + 1px)',
            });
        }
        else {
            setStyles(popoverElement, {
                'position-anchor': `--${popoverId}`,
                'position-try-fallbacks': 'flip-block',
                'position-area': 'bottom right', // to not push popover out of the page viewport
                'top': 'calc(anchor(bottom) + 1px)',
                'left': 'anchor(left)',
            });
        }
        // Remove attributes and styles from the anchor element when the popover is closed.
        // No clean up is required for the popover element because it is destroyed when closed.
        inject(DestroyRef).onDestroy(() => {
            setAttributes(anchorElement, {
                'popovertarget': null,
                'popovertargetaction': null,
            });
            setStyles(anchorElement, {
                'anchor-name': null,
            });
        });
    }
    createVirtualAnchor(anchor, options) {
        // Coerce coordinates.
        const { x, y, width, height } = anchor instanceof MouseEvent ? ({ x: anchor.x, y: anchor.y }) : anchor;
        // Create virtual anchor element at anchor bounds.
        const virtualAnchorElement = inject(DOCUMENT).createElement('div');
        inject(DestroyRef).onDestroy(() => virtualAnchorElement.remove());
        // Position the anchor element.
        setStyles(virtualAnchorElement, {
            'position': 'fixed',
            'left': `${x}px`,
            'top': `${y}px`,
            'width': width ? `${width}px` : '0',
            'height': height ? `${height}px` : '0',
            'pointer-events': 'none',
        });
        // Attach the anchor element to the DOM.
        if (options.viewContainerRef) {
            options.viewContainerRef.element.nativeElement.after(virtualAnchorElement);
        }
        else {
            inject(DOCUMENT).body.appendChild(virtualAnchorElement);
        }
        return virtualAnchorElement;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuOpener, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuOpener, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuOpener, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
function setAttributes(element, attributes) {
    Object.entries(attributes).forEach(([name, value]) => {
        if (value === null) {
            element.removeAttribute(name);
        }
        else {
            element.setAttribute(name, value);
        }
    });
}
function setStyles(element, styles) {
    Object.entries(styles).forEach(([name, value]) => {
        if (value === null) {
            element.style.removeProperty(name);
        }
        else {
            element.style.setProperty(name, value);
        }
    });
}
function coerceFilterDescriptor(filter) {
    if (typeof filter === 'object') {
        return {
            placeholder: coerceSignal(filter.placeholder),
            notFoundText: coerceSignal(filter.notFoundText),
            focus: filter.focus,
        };
    }
    return filter === true ? {} : undefined;
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Translation note: Texts are translated when added (not lazily when rendered) to simplify filtering.
 */
class ɵSciMenubarFactory {
    menuItems = [];
    /** @inheritDoc */
    addMenu(descriptor, menuFactoryFn) {
        this.menuItems.push({
            type: 'menu-item',
            name: descriptor.name,
            labelText: translate(descriptor.label),
            cssClass: Arrays.coerce(descriptor.cssClass),
            attributes: descriptor.attributes,
            menu: constructMenu(menuFactoryFn, descriptor.menu),
        });
        return this;
    }
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
class ɵSciMenuRegistry {
    _contributions = new Map();
    _menuItemsCache = new MenuItemsCache();
    _contributionInstantProvider = inject(SciMenuContributionInstantProvider);
    _menuOpener = inject(SciMenuOpener);
    _injector = inject(Injector);
    _menuContextProviders = inject(SciMenuEnvironmentProviders);
    /** @inheritDoc */
    contributeMenu(locationLike, factoryFn, options) {
        const { scope, location } = parseMenuLocation(locationLike.location);
        const { before, after, position } = locationLike;
        const contribution = {
            scope: scope,
            factoryFn: factoryFn,
            position: prune({ before, after, position }, { pruneIfEmpty: true }),
            requiredContext: options.requiredContext ?? new Map(),
            contributionInstant: options.contributionInstant ?? this._contributionInstantProvider.next(),
            metadata: options.metadata ?? {},
        };
        if (!this._contributions.has(location)) {
            this._contributions.set(location, signal([]));
        }
        this._contributions.get(location).update(contributions => contributions.concat(contribution));
        return {
            dispose: () => {
                // Do not remove signal for listener to never have a "stale" signal.
                this._contributions.get(location).update(contributions => contributions.filter(it => it !== contribution));
                this._menuItemsCache.dispose(contribution);
            },
        };
    }
    /** @inheritDoc */
    menuContributions(location, context, options) {
        return computed(() => {
            // Ensure the location is tracked for later registrations.
            if (!this._contributions.has(location())) {
                this._contributions.set(location(), signal([]));
            }
            const contributions = this._contributions.get(location())();
            const environmentContext = context();
            return untracked(() => contributions
                // Filter contributions not matching the environment context.
                .filter(contribution => {
                const requiredContext = contribution.requiredContext;
                for (const [name, value] of requiredContext.entries()) {
                    // Skip check if the required context value has been cleared.
                    if (value === undefined) {
                        continue;
                    }
                    // Only include contributions matching the environment context.
                    if (!Objects.isEqual(environmentContext.get(name), value, { ignoreArrayOrder: true })) {
                        return false;
                    }
                }
                return true;
            })
                // Sort contributions by contribution instant.
                .sort((a, b) => a.contributionInstant - b.contributionInstant));
        }, { equal: (a, b) => Objects.isEqual(a, b) });
    }
    /** @inheritDoc */
    menuItems(location, context, options) {
        assertNotInReactiveContext(this.menuItems, 'Call menuItems() in a non-reactive (non-tracking) context, such as within the untracked() function.');
        if (!options.injector) {
            assertInInjectionContext(this.menuItems, 'Call menuItems() in an injection context, as it may allocate resources that are not released until the injection context is destroyed.');
        }
        const callingContextInjector = options.injector ?? inject(Injector);
        const menuService = this.menuService;
        const menuItemsCache = this._menuItemsCache;
        const menuContextProviders = this._menuContextProviders;
        // Get contributions for this location.
        const menuContributions = menuService.menuContributions(location, context, options);
        // Construct menu items from contributions, recursively.
        return computed(() => {
            if (!menuContributions().length) {
                return NULL_MENU_CONTRIBUTIONS;
            }
            const callingContext = context();
            const menuItems = menuContributions()
                // Construct menu items for each contribution in this context.
                .flatMap(menuContribution => untracked(() => computeMenuItems(menuContribution, callingContext))())
                // Federate menu items, recursively for each submenu and group.
                .map(menuItem => federateMenuItems(menuItem, callingContext, { injector: callingContextInjector, metadata: options.metadata }))
                // Filter empty submenus and groups.
                .flatMap(filterEmpty);
            return sortMenuItems(menuItems);
        });
        /**
         * Computes the menu items of given contribution based on given context.
         */
        function computeMenuItems(menuContribution, context) {
            assertNotInReactiveContext(computeMenuItems, 'Call computeMenuItems() in a non-reactive (non-tracking) context, such as within the untracked() function.');
            return menuItemsCache.computeIfAbsent(menuContribution, context, () => {
                const injector = createDestroyableInjector({
                    parent: inject(Injector),
                    providers: menuContextProviders.provideInjectionContext(context),
                });
                return computed(() => {
                    switch (menuContribution.scope) {
                        case 'menu': {
                            const menuFactory = new ɵSciMenuFactory();
                            const menuFactoryFn = menuContribution.factoryFn;
                            runInInjectionContext(injector, () => menuFactoryFn(menuFactory, context));
                            return menuFactory.menuItems.map(menuItem => ({ ...menuItem, position: menuContribution.position }));
                        }
                        case 'toolbar': {
                            const toolbarFactory = new ɵSciToolbarFactory();
                            const toolbarFactoryFn = menuContribution.factoryFn;
                            runInInjectionContext(injector, () => toolbarFactoryFn(toolbarFactory, context));
                            return toolbarFactory.menuItems.map(menuItem => ({ ...menuItem, position: menuContribution.position }));
                        }
                        case 'menubar': {
                            const menubarFactory = new ɵSciMenubarFactory();
                            const menubarFactoryFn = menuContribution.factoryFn;
                            runInInjectionContext(injector, () => menubarFactoryFn(menubarFactory, context));
                            return menubarFactory.menuItems.map(menuItem => ({ ...menuItem, position: menuContribution.position }));
                        }
                    }
                });
            }, { injector: callingContextInjector });
        }
        /**
         * Federates passed menu or group with contributions based on its name. Federation is recursive.
         */
        function federateMenuItems(menuItem, context, options) {
            const federatedItem = { ...menuItem };
            // Federate actions of the menu item.
            if (federatedItem.actions?.length) {
                federatedItem.actions = sortMenuItems(federatedItem.actions.map(action => federateMenuItems(action, context, options)).flatMap(filterEmpty));
            }
            // Federate menu items of group.
            if (federatedItem.type === 'group') {
                const contributions = federatedItem.name ? untracked(() => menuService.menuItems(federatedItem.name, context, { injector: options?.injector, metadata: options?.metadata }))() : [];
                federatedItem.children = sortMenuItems([
                    ...federatedItem.children.map(child => federateMenuItems(child, context, options)),
                    ...contributions,
                ]);
            }
            // Federate menu items of menu.
            if (federatedItem.type === 'menu-item' && federatedItem.menu) {
                const contributions = federatedItem.menu.name ? untracked(() => menuService.menuItems(federatedItem.menu.name, context, { injector: options?.injector, metadata: options?.metadata }))() : [];
                federatedItem.menu = {
                    ...federatedItem.menu,
                    children: sortMenuItems([
                        ...federatedItem.menu.children.map(child => federateMenuItems(child, context, options)),
                        ...contributions,
                    ]),
                };
            }
            return federatedItem;
        }
    }
    /** @inheritDoc */
    openMenu(menu, options) {
        return this._menuOpener.openMenu(menu, options);
    }
    /** @inheritDoc */
    accelerators(context) {
        return this._menuItemsCache.accelerators(context);
    }
    /**
     * Reference to the menu service.
     *
     * Use to call methods like {@link ɵSciMenuService.menuContributions} or {@link ɵSciMenuService.menuItems} through the adapter chain.
     */
    get menuService() {
        return this._injector.get(ɵSciMenuService);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ɵSciMenuRegistry, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ɵSciMenuRegistry, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ɵSciMenuRegistry, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
function filterEmpty(menuItem) {
    switch (menuItem.type) {
        case 'menu-item': {
            if (!menuItem.menu) {
                return [menuItem];
            }
            const children = menuItem.menu.children.flatMap(filterEmpty);
            if (children.length) {
                return [{ ...menuItem, menu: { ...menuItem.menu, children } }];
            }
            // Never filter controls or push buttons.
            if (menuItem.control || menuItem.onSelect) {
                return [menuItem];
            }
            return [];
        }
        case 'group': {
            const children = menuItem.children.flatMap(filterEmpty);
            return children.length ? [{ ...menuItem, children }] : [];
        }
    }
}
class MenuItemsCache {
    _cache = signal(new Set(), ...(ngDevMode ? [{ debugName: "_cache" }] : []));
    _cacheByContribution = computed(() => {
        return Array.from(this._cache()).reduce((map, cacheEntry) => Maps.addListValue(map, cacheEntry.contribution, cacheEntry), new Map());
    }, ...(ngDevMode ? [{ debugName: "_cacheByContribution" }] : []));
    computeIfAbsent(contribution, context, computeFn, options) {
        assertNotInReactiveContext(this.computeIfAbsent, 'Call computeIfAbsent() in a non-reactive (non-tracking) context, such as within the untracked() function.');
        const injector = options?.injector ?? inject(Injector);
        const cacheEntry = this._cacheByContribution().get(contribution)?.find(cacheEntry => Objects.isEqual(cacheEntry.context, context)) ?? (() => {
            const cacheEntryInjector = createDestroyableInjector({ parent: injector.get(ApplicationRef).injector });
            const cacheEntry = {
                injector: cacheEntryInjector,
                contribution,
                menuItems: runInInjectionContext(cacheEntryInjector, () => computeFn()),
                context,
                refCount: 0,
                dispose: () => cacheEntryInjector.destroy(),
            };
            this._cache.update(cache => new Set(cache).add(cacheEntry));
            return cacheEntry;
        })();
        cacheEntry.refCount++;
        // Decrement ref count if calling context is destroyed.
        injector.get(DestroyRef).onDestroy(() => {
            if (--cacheEntry.refCount === 0) {
                cacheEntry.dispose();
                this._cache.update(cache => {
                    const cacheCopy = new Set(cache);
                    cacheCopy.delete(cacheEntry);
                    return cacheCopy;
                });
            }
        });
        return cacheEntry.menuItems;
    }
    /**
     * Gets accelerators of currently used menu items, optionally filtered by context.
     *
     * An accelerator matches if its menu item's context is the same as, a subset of, or has extra values compared to the given context. It never matches if a context value is different.
     *
     * IMPORTANT: Unlike {@link computeIfAbsent}, this method is based on currently used menu items, not available contributions.
     * If a contribution is not used in the application, its accelerators are not returned.
     */
    accelerators(context) {
        return computed(() => {
            return Array.from(this._cache().values())
                // Filter by context.
                .filter(cacheEntry => {
                for (const [name, value] of context().entries()) {
                    // Skip check if the context value has been cleared.
                    if (value === undefined) {
                        continue;
                    }
                    // Match if the menu item's context is the same as, a subset of, or has extra values compared to the given context.
                    // Never match if a context value is different.
                    if (cacheEntry.context.has(name) && !Objects.isEqual(cacheEntry.context.get(name), value, { ignoreArrayOrder: true })) {
                        return false;
                    }
                }
                return true;
            })
                .flatMap(cacheEntry => collectAccelerators(cacheEntry.menuItems()))
                // Remove duplicate accelerators.
                .reduce((accelerators, menuItem) => {
                if (!accelerators.some(accelerator => Objects.isEqual(accelerator, menuItem.accelerator, { ignoreArrayOrder: true }))) {
                    return [...accelerators, menuItem.accelerator];
                }
                return accelerators;
            }, new Array());
        }, { equal: (a, b) => Objects.isEqual(a, b, { ignoreArrayOrder: true }) });
    }
    dispose(contribution) {
        assertNotInReactiveContext(this.dispose, 'Call dispose() in a non-reactive (non-tracking) context, such as within the untracked() function.');
        const cacheEntriesToRemove = this._cacheByContribution().get(contribution) ?? [];
        this._cache.update(cache => {
            const cacheCopy = new Set(cache);
            cacheEntriesToRemove.forEach(cacheEntry => {
                cacheEntry.dispose();
                cacheCopy.delete(cacheEntry);
            });
            return cacheCopy;
        });
    }
}

class SciMenuRegistry {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuRegistry, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuRegistry, providedIn: 'root', useClass: ɵSciMenuRegistry });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuRegistry, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root', useClass: ɵSciMenuRegistry }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Allows intercepting calls to the menu registry.
 *
 * Adapters can handle or augment calls. Multiple adapters form a chain and are called one by one in registration order.
 *
 * Calling 'next' passes the call to the next adapter, or to the registry if it is the last adapter in the chain.
 */
class SciMenuAdapter {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuAdapter, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuAdapter });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuAdapter, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * @docs-private Not public API. For internal use only.
 */
class ɵSciMenuService {
    _menuRegistry = interceptMenuRegistry(inject(SciMenuRegistry));
    _injector = inject(Injector);
    _menuEnvironmentProviders = inject(SciMenuEnvironmentProviders);
    /** @inheritDoc */
    open(menu, options) {
        const context = this._menuEnvironmentProviders.provideContext(options.context, { injector: this._injector })();
        // Prevent default if opening context menu.
        if (options.anchor instanceof MouseEvent && options.anchor.type === 'contextmenu') {
            options.anchor.preventDefault();
            options.anchor.stopPropagation();
        }
        return this._menuRegistry.openMenu(menu, { ...options, context });
    }
    /**
     * The function:
     * - Must be called within an injection context, or an explicit {@link Injector} passed.
     * - Must be called in a non-reactive (non-tracking) context.
     *
     * @docs-private Not public API. For internal use only.
     */
    menuItems(location, context, options) {
        return this._menuRegistry.menuItems(coerceSignal(location), coerceSignal(context), options ?? {});
    }
    /** @docs-private Not public API. For internal use only. */
    menuContributions(location, context, options) {
        return this._menuRegistry.menuContributions(coerceSignal(location), coerceSignal(context), options ?? {});
    }
    /** @docs-private Not public API. For internal use only. */
    contributeMenu(location, factoryFn, options) {
        return this._menuRegistry.contributeMenu(location, factoryFn, options ?? {});
    }
    /**
     * Gets accelerators of currently used menu items, optionally filtered by context.
     *
     * An accelerator matches if its menu item's context is the same as, a subset of, or has extra values compared to the given context. It never matches if a context value is different.
     *
     * IMPORTANT: Unlike {@link menuItems}, this method is based on currently used menu items, not available contributions.
     * If a contribution is not used in the application, its accelerators are not returned.
     *
     * @docs-private Not public API. For internal use only.
     */
    accelerators(options) {
        const context = this._menuEnvironmentProviders.provideContext(options?.context, { injector: this._injector });
        return this._menuRegistry.accelerators(context);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ɵSciMenuService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ɵSciMenuService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ɵSciMenuService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * Intercepts calls to the menu registry by chaining registered menu adapters.
 *
 * Each adapter can handle the call, modify it, or pass it to the next.
 */
function interceptMenuRegistry(menuRegistry) {
    // TODO [Angular 22] Remove cast when Angular supports type safety for multi-injection with abstract class DI tokens. See https://github.com/angular/angular/issues/55555
    const menuAdapters = inject(SciMenuAdapter, { optional: true }) ?? [];
    return menuAdapters.reduceRight((next, adapter) => ({
        contributeMenu: (location, factoryFn, options) => adapter.contributeMenu ? adapter.contributeMenu(location, factoryFn, options, next) : next.contributeMenu(location, factoryFn, options),
        menuContributions: (location, context, options) => adapter.menuContributions ? adapter.menuContributions(location, context, options, next) : next.menuContributions(location, context, options),
        menuItems: (location, context, options) => adapter.menuItems ? adapter.menuItems(location, context, options, next) : next.menuItems(location, context, options),
        openMenu: (menu, options) => adapter.openMenu ? adapter.openMenu(menu, options, next) : next.openMenu(menu, options),
        accelerators: context => adapter.accelerators ? adapter.accelerators(context, next) : next.accelerators(context),
    }), menuRegistry);
}
/**
 * Provides {@link SciMenuService} for dependency injection.
 */
function provideMenuService() {
    return [
        ɵSciMenuService,
        { provide: SciMenuService, useExisting: ɵSciMenuService },
    ];
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
// TODO [menu] Consider moving open (with menuitems) and menuContributions to separate service
class SciMenuService {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuService, providedIn: 'root', useExisting: ɵSciMenuService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenuService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root', useExisting: ɵSciMenuService }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
function contributeMenu(locationLike, factoryFn, options) {
    assertNotInReactiveContext(contributeMenu, 'Call contributeMenu in a non-reactive (non-tracking) context, such as within the untracked() function.');
    if (!options?.injector) {
        assertInInjectionContext$1(contributeMenu);
    }
    const injector = createDestroyableInjector({ parent: options?.injector ?? inject(Injector) });
    const location = typeof locationLike === 'string' ? { location: locationLike } : locationLike;
    const menuService = injector.get(ɵSciMenuService);
    const context = injector.get(SciMenuEnvironmentProviders).provideContext(options?.requiredContext, { injector });
    // Each contribution is assigned a unique contribution instant to keep its original order even if the reactive context changes.
    const contributionInstant = options?.contributionInstant ?? injector.get(SciMenuContributionInstantProvider).next();
    effect(onCleanup => {
        const requiredContext = context();
        untracked(() => {
            const contributionRef = menuService.contributeMenu(location, factoryFn, { ...options, requiredContext, contributionInstant });
            onCleanup(() => contributionRef.dispose());
        });
    }, { injector });
    return {
        dispose: () => injector.destroy(),
    };
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * TODO [menu]: Explain how to size the toolbar. (height can be set; icon size by setting a CSS variable)
 *
 * TODO [menu]: Mention that component is :empty if no menu items, e.g., to hide empty toolbar:
 * ```scss
 * sci-toolbar:empty {
 *   display: none;
 * }
 * ```
 *
 * Control the toolbar item size by setting the `--sci-toolbar-item-size` CSS variable, globally in the document root or on a specific toolbar component. Defaults to 16px.
 */
class SciToolbarComponent {
    name = input.required(...(ngDevMode ? [{ debugName: "name" }] : []));
    orientation = input('horizontal', ...(ngDevMode ? [{ debugName: "orientation" }] : []));
    context = input(...(ngDevMode ? [undefined, { debugName: "context" }] : []));
    acceleratorTarget = input(...(ngDevMode ? [undefined, { debugName: "acceleratorTarget" }] : []));
    popoverViewContainerRef = input(inject(ViewContainerRef), ...(ngDevMode ? [{ debugName: "popoverViewContainerRef" }] : []));
    _context = inject(SciMenuEnvironmentProviders).provideContext(this.context);
    menuItems = inject(ɵSciMenuService).menuItems(this.name, this._context);
    constructor() {
        this.installAccelerators();
    }
    installAccelerators() {
        const injector = inject(Injector);
        effect(onCleanup => {
            const name = this.name();
            const target = this.acceleratorTarget();
            const context = this._context();
            untracked(() => {
                const accelerators = installMenuAccelerators(name, { target, context, injector });
                onCleanup(() => accelerators.dispose());
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.0", type: SciToolbarComponent, isStandalone: true, selector: "sci-toolbar", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, context: { classPropertyName: "context", publicName: "context", isSignal: true, isRequired: false, transformFunction: null }, acceleratorTarget: { classPropertyName: "acceleratorTarget", publicName: "acceleratorTarget", isSignal: true, isRequired: false, transformFunction: null }, popoverViewContainerRef: { classPropertyName: "popoverViewContainerRef", publicName: "popoverViewContainerRef", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.name": "name()" } }, ngImport: i0, template: "<!-- Render no content if empty for the application to hide it using the `:empty` CSS pseudo class. -->\r\n@if (menuItems().length) {\r\n  <sci-toolbar-group [menuItems]=\"menuItems()\"\r\n                     [popoverViewContainerRef]=\"popoverViewContainerRef()\"\r\n                     [orientation]=\"orientation()\"/>\r\n}\r\n", styles: [":host{display:flex}\n"], dependencies: [{ kind: "component", type: SciToolGroupComponent, selector: "sci-toolbar-group", inputs: ["menuItems", "orientation", "disabled", "popoverViewContainerRef"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sci-toolbar', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        SciToolGroupComponent,
                    ], host: {
                        '[attr.name]': 'name()', // Enable selection by name if passing the name via dynamic input binding.
                    }, template: "<!-- Render no content if empty for the application to hide it using the `:empty` CSS pseudo class. -->\r\n@if (menuItems().length) {\r\n  <sci-toolbar-group [menuItems]=\"menuItems()\"\r\n                     [popoverViewContainerRef]=\"popoverViewContainerRef()\"\r\n                     [orientation]=\"orientation()\"/>\r\n}\r\n", styles: [":host{display:flex}\n"] }]
        }], ctorParameters: () => [], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: true }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], context: [{ type: i0.Input, args: [{ isSignal: true, alias: "context", required: false }] }], acceleratorTarget: [{ type: i0.Input, args: [{ isSignal: true, alias: "acceleratorTarget", required: false }] }], popoverViewContainerRef: [{ type: i0.Input, args: [{ isSignal: true, alias: "popoverViewContainerRef", required: false }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * TODO [menu]: Explain how to size the menubar. (height can be set)
 */
class SciMenubarComponent {
    name = input.required(...(ngDevMode ? [{ debugName: "name" }] : []));
    context = input(...(ngDevMode ? [undefined, { debugName: "context" }] : []));
    acceleratorTarget = input(...(ngDevMode ? [undefined, { debugName: "acceleratorTarget" }] : []));
    viewContainerRef = input(...(ngDevMode ? [undefined, { debugName: "viewContainerRef" }] : []));
    _menuService = inject(ɵSciMenuService);
    _context = inject(SciMenuEnvironmentProviders).provideContext(this.context);
    menuItems = inject(ɵSciMenuService).menuItems(this.name, this._context);
    activeMenuItem = linkedSignal(...(ngDevMode ? [{ debugName: "activeMenuItem", source: this.menuItems, // reset active menu when menus change.
            computation: () => null,
            equal: (a, b) => a?.menuItem === b?.menuItem }] : [{
            source: this.menuItems, // reset active menu when menus change.
            computation: () => null,
            equal: (a, b) => a?.menuItem === b?.menuItem,
        }]));
    constructor() {
        this.installAccelerators();
        const injector = inject(Injector);
        // Open or close popover.
        effect(onCleanup => {
            if (!this.activeMenuItem()) {
                return;
            }
            const { menuItem, element } = this.activeMenuItem();
            const menu = menuItem.menu;
            // Attach popover to configured view ref. Defaults to this component's view ref.
            // Controls where to add the popup.
            const viewContainerRef = this.viewContainerRef() ?? injector.get(ViewContainerRef);
            untracked(() => {
                const ref = this._menuService.open(menu.children, {
                    anchor: element,
                    viewContainerRef,
                    filter: menu.filter,
                    width: menu.width,
                    minWidth: menu.minWidth,
                    maxWidth: menu.maxWidth,
                    maxHeight: menu.maxHeight,
                    cssClass: menuItem.cssClass,
                    attributes: menuItem.attributes,
                    align: 'vertical',
                });
                ref.onClose(() => {
                    const activeMenuItem = this.activeMenuItem();
                    // Do not unset if another menu has been opened in the meantime.
                    if (activeMenuItem?.menuItem !== menuItem) {
                        return;
                    }
                    // Prevent immediate re-opening race condition when toolbar button is clicked to close.
                    if (activeMenuItem.closing) {
                        activeMenuItem.closing = 'prevented';
                        return;
                    }
                    this.activeMenuItem.set(null);
                });
                onCleanup(() => ref.close());
            });
        });
    }
    /**
     * Method invoked when clicking on a menu button.
     */
    onMenuItemClick(menuItem, element) {
        this.activeMenuItem.update(activeMenuItem => activeMenuItem?.menuItem === menuItem ? null : { menuItem, element });
    }
    /**
     * Method invoked before clicking on a menu button.
     *
     * When clicking on the active menu button, mark it as closing to prevent immediate re-opening race condition on subsequent click event.
     */
    onMenuItemMouseDown(menuItem) {
        const activeMenuItem = this.activeMenuItem();
        if (activeMenuItem?.menuItem === menuItem) {
            activeMenuItem.closing = true;
        }
    }
    /**
     * Method invoked when entering a menu button.
     *
     * Open menu if menubar is in 'menu-open' state.
     */
    onMenuItemMouseEnter(menuItem, element) {
        this.activeMenuItem.update(activeMenuItem => activeMenuItem ? { menuItem, element } : null);
    }
    /**
     * Method invoked when leaving a menu button.
     *
     * Clean up closing state set by {@link onMenuButtonMouseDown}, if any.
     */
    onMenuItemMouseLeave(menuItem) {
        const activeMenuItem = this.activeMenuItem();
        if (activeMenuItem?.menuItem !== menuItem) {
            return;
        }
        if (activeMenuItem.closing === 'prevented') {
            this.activeMenuItem.set(null); // unset active menu
        }
        else if (activeMenuItem.closing) {
            delete activeMenuItem.closing; // unset closing state
        }
    }
    installAccelerators() {
        const injector = inject(Injector);
        // TODO [menu] Do we have to use a root effect? Was the case in previous implementation
        // // Use root effect to run even if the parent component is detached from change detection (e.g., if the view is not visible).
        // rootEffect(onCleanup => {
        effect(onCleanup => {
            const name = this.name();
            const target = this.acceleratorTarget();
            const context = this._context();
            untracked(() => {
                const ref = installMenuAccelerators(name, { target, context, injector });
                onCleanup(() => ref.dispose());
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenubarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.0.0", type: SciMenubarComponent, isStandalone: true, selector: "sci-menubar", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, context: { classPropertyName: "context", publicName: "context", isSignal: true, isRequired: false, transformFunction: null }, acceleratorTarget: { classPropertyName: "acceleratorTarget", publicName: "acceleratorTarget", isSignal: true, isRequired: false, transformFunction: null }, viewContainerRef: { classPropertyName: "viewContainerRef", publicName: "viewContainerRef", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.name": "name()" } }, ngImport: i0, template: "@for (menuItem of menuItems(); track $index) {\r\n  <button [class.open]=\"activeMenuItem()?.menuItem === menuItem\"\r\n          [class]=\"menuItem.cssClass\" class=\"menu-item\"\r\n          [sciAttributes]=\"menuItem.attributes\"\r\n          (mousedown)=\"onMenuItemMouseDown(menuItem)\"\r\n          (click)=\"onMenuItemClick(menuItem, element)\"\r\n          (mouseenter)=\"onMenuItemMouseEnter(menuItem, element)\"\r\n          (mouseleave)=\"onMenuItemMouseLeave(menuItem)\"\r\n          #element>\r\n    {{menuItem.labelText!()}}\r\n  </button>\r\n}\r\n", styles: [":host{display:flex}:host>button:is(.menu-item,#sci-reset){all:unset;display:inline-flex;align-items:center;text-wrap:nowrap;padding:var(--sci-menubar-item-padding);border-radius:var(--sci-menubar-button-border-radius);-webkit-user-select:none;user-select:none;overflow:hidden;cursor:var(--sci-menubar-button-cursor)}:host>button:is(.menu-item,#sci-reset):hover{background-color:var(--sci-menubar-button-background-color-hover)}:host>button:is(.menu-item,#sci-reset):active{background-color:var(--sci-menubar-button-background-color-active)}:host>button:is(.menu-item,#sci-reset):focus:not(:focus-visible){outline:none}:host>button:is(.menu-item,#sci-reset):focus-visible{outline:var(--sci-menubar-button-outline-width-focus) solid var(--sci-color-accent)}:host>button:is(.menu-item,#sci-reset).open{background-color:var(--sci-menubar-button-background-color-hover)}\n"], dependencies: [{ kind: "directive", type: SciAttributesDirective, selector: "[sciAttributes]", inputs: ["sciAttributes"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciMenubarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sci-menubar', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        SciAttributesDirective,
                    ], host: {
                        '[attr.name]': 'name()', // Enable selection by name if passing the name via dynamic input binding.
                    }, template: "@for (menuItem of menuItems(); track $index) {\r\n  <button [class.open]=\"activeMenuItem()?.menuItem === menuItem\"\r\n          [class]=\"menuItem.cssClass\" class=\"menu-item\"\r\n          [sciAttributes]=\"menuItem.attributes\"\r\n          (mousedown)=\"onMenuItemMouseDown(menuItem)\"\r\n          (click)=\"onMenuItemClick(menuItem, element)\"\r\n          (mouseenter)=\"onMenuItemMouseEnter(menuItem, element)\"\r\n          (mouseleave)=\"onMenuItemMouseLeave(menuItem)\"\r\n          #element>\r\n    {{menuItem.labelText!()}}\r\n  </button>\r\n}\r\n", styles: [":host{display:flex}:host>button:is(.menu-item,#sci-reset){all:unset;display:inline-flex;align-items:center;text-wrap:nowrap;padding:var(--sci-menubar-item-padding);border-radius:var(--sci-menubar-button-border-radius);-webkit-user-select:none;user-select:none;overflow:hidden;cursor:var(--sci-menubar-button-cursor)}:host>button:is(.menu-item,#sci-reset):hover{background-color:var(--sci-menubar-button-background-color-hover)}:host>button:is(.menu-item,#sci-reset):active{background-color:var(--sci-menubar-button-background-color-active)}:host>button:is(.menu-item,#sci-reset):focus:not(:focus-visible){outline:none}:host>button:is(.menu-item,#sci-reset):focus-visible{outline:var(--sci-menubar-button-outline-width-focus) solid var(--sci-color-accent)}:host>button:is(.menu-item,#sci-reset).open{background-color:var(--sci-menubar-button-background-color-hover)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: true }] }], context: [{ type: i0.Input, args: [{ isSignal: true, alias: "context", required: false }] }], acceleratorTarget: [{ type: i0.Input, args: [{ isSignal: true, alias: "acceleratorTarget", required: false }] }], viewContainerRef: [{ type: i0.Input, args: [{ isSignal: true, alias: "viewContainerRef", required: false }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/*
 * Secondary entrypoint: '@scion/components/menu'
 *
 * @see https://github.com/ng-packagr/ng-packagr/blob/master/docs/secondary-entrypoints.md
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SciMenuAdapter, SciMenuEnvironmentProvider, SciMenuEnvironmentProviders, SciMenuService, SciMenubarComponent, SciToolbarComponent, contributeMenu, installMenuAccelerators, provideMenuEnvironmentProvider, provideMenuService, ɵSciMenuService };
//# sourceMappingURL=scion-components-menu.mjs.map
