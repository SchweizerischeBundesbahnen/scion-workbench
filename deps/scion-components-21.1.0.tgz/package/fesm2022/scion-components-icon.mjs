import * as i0 from '@angular/core';
import { inputBinding, signal, input, Component, inject, InjectionToken, Injector, runInInjectionContext, Injectable, viewChild, effect, untracked, ChangeDetectionStrategy, computed, Directive, makeEnvironmentProviders } from '@angular/core';
import { SciComponentOutletDirective, coerceSignal } from '@scion/components/common';
import { fromMutation$ } from '@scion/toolkit/observable';
import { of, concatWith, map } from 'rxjs';

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides Material icons for non-scion icons.
 */
const materialIconProvider = (ligature) => {
    if (ligature.startsWith('scion.')) {
        return undefined; // delegate to next provider
    }
    return { component: MaterialIconComponent, bindings: [inputBinding('ligature', signal(ligature))] };
};
/**
 * Renders a Material icon based on its ligature.
 *
 * This component requires a Material icon font to be included in the HTML.
 *
 * Supported fonts:
 * - https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded
 * - https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined
 * - https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp
 * - https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Round|Material+Icons+Sharp
 */
class MaterialIconComponent {
    /**
     * Specifies the ligature of the Material icon.
     */
    ligature = input.required(...(ngDevMode ? [{ debugName: "ligature" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: MaterialIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.0.0", type: MaterialIconComponent, isStandalone: true, selector: "sci-material-icon", inputs: { ligature: { classPropertyName: "ligature", publicName: "ligature", isSignal: true, isRequired: true, transformFunction: null } }, host: { properties: { "class.material-icons": "true", "class.material-icons-outlined": "true", "class.material-icons-round": "true", "class.material-icons-sharp": "true", "class.material-symbols-sharp": "true", "class.material-symbols-outlined": "true", "class.material-symbols-rounded": "true" } }, ngImport: i0, template: '{{ligature()}}', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: MaterialIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-material-icon',
                    template: '{{ligature()}}',
                    host: {
                        '[class.material-icons]': 'true',
                        '[class.material-icons-outlined]': 'true',
                        '[class.material-icons-round]': 'true',
                        '[class.material-icons-sharp]': 'true',
                        '[class.material-symbols-sharp]': 'true',
                        '[class.material-symbols-outlined]': 'true',
                        '[class.material-symbols-rounded]': 'true',
                    },
                }]
        }], propDecorators: { ligature: [{ type: i0.Input, args: [{ isSignal: true, alias: "ligature", required: true }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides icons used in SCION libraries.
 *
 * Register this provider as the last icon provider, enabling replacement of built-in SCION icons.
 */
const scionIconProvider = (icon) => {
    const ligature = scionIcons[icon];
    if (ligature) {
        return { component: ScionIconComponent, bindings: [inputBinding('ligature', signal(ligature))] };
    }
    return undefined;
};
/**
 * Maps icons to ligatures of the SCION icon font.
 */
const scionIcons = {
    'scion.clear': 'clear',
    'scion.close': 'close',
    'scion.dirty': 'dirty',
    'scion.menu_down': 'chevron_down',
    'scion.minimize': 'minimize',
    'scion.pin': 'pin',
    'scion.search': 'search',
};
/**
 * Renders the icon for a ligature of the SCION icon font.
 *
 * This component requires the SCION icon font 'scion-icons' to be included in the HTML.
 *
 * Supported ligatures:
 * - `chevron_down`: Menu button of drop down menus
 * - `clear`: Clear button in input fields
 * - `close`: Close button in views, dialogs and notifications
 * - `dirty`: Visual indicator for view with unsaved content
 * - `minimize`: Minimize button in docked parts
 * - `pin`: Visual indicator for a pinned view
 * - `search`: Visual indicator in search or filter fields
 */
class ScionIconComponent {
    /**
     * Specifies the ligature of the icon.
     */
    ligature = input.required(...(ngDevMode ? [{ debugName: "ligature" }] : []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ScionIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.0.0", type: ScionIconComponent, isStandalone: true, selector: "sci-scion-icon", inputs: { ligature: { classPropertyName: "ligature", publicName: "ligature", isSignal: true, isRequired: true, transformFunction: null } }, host: { properties: { "class.scion-icons": "true" } }, ngImport: i0, template: '{{ligature()}}', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ScionIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sci-scion-icon',
                    template: '{{ligature()}}',
                    host: {
                        '[class.scion-icons]': 'true',
                    },
                }]
        }], propDecorators: { ligature: [{ type: i0.Input, args: [{ isSignal: true, alias: "ligature", required: true }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides icons based on registered icon providers.
 */
class IconProviders {
    _iconProviders = [
        // Provide app-specific icons.
        ...inject(SCI_ICON_PROVIDER, { optional: true }) ?? [],
        // Provide built-in icons.
        scionIconProvider,
        // Provide material icons.
        materialIconProvider,
    ];
    _injector = inject(Injector);
    /**
     * Provides the icon descriptor for the given icon based on icon providers registered under the {@link SCI_ICON_PROVIDER} DI token.
     *
     * Icon providers are called in registration order. If a provider does not provide the icon, the next provider is called, and so on.
     */
    provide(icon) {
        if (!icon) {
            return undefined;
        }
        if (!this._iconProviders.length) {
            return undefined;
        }
        for (const iconProvider of this._iconProviders) {
            const componentOrDescriptor = runInInjectionContext(this._injector, () => iconProvider(icon));
            if (componentOrDescriptor) {
                return typeof componentOrDescriptor === 'function' ? { component: componentOrDescriptor } : componentOrDescriptor;
            }
        }
        return undefined;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: IconProviders, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: IconProviders, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: IconProviders, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * Multi-DI token for injecting icon providers.
 *
 * Multiple icon providers can be registered. Providers are called in registration order.
 * If a provider does not provide the icon, the next provider is called, and so on.
 */
const SCI_ICON_PROVIDER = new InjectionToken('SCI_ICON_PROVIDER');

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Renders an icon based on registered icon providers.
 *
 * Use the icon name as slotted content of the `<sci-icon>` component.
 *
 * Example:
 * ```html
 * <sci-icon>home</sci-icon>
 * ```
 *
 * Providers are called in registration order. If a provider does not provide the icon, the next provider is called, and so on.
 * If no provider provides the icon, defaults to a Material icon provider, interpreting the icon as a Material icon ligature.
 *
 * The icon size depends on the font size at its position in the DOM.
 * To change the size, set a font-size on the `<sci-icon>` element or set the `--sci-icon-size` CSS variable.
 *
 * @see provideIconProvider
 */
class SciIconComponent {
    _slottedContent = viewChild.required('slotted_content');
    icon = this.computeIcon();
    /**
     * Reads the icon from slotted content and passes it to registered icon providers for resolution.
     */
    computeIcon() {
        const icon = signal(undefined, ...(ngDevMode ? [{ debugName: "icon" }] : []));
        const iconProviders = inject(IconProviders);
        effect(onCleanup => {
            const slottedContent = this._slottedContent();
            untracked(() => {
                // Instantiate template to "read" slotted content.
                const view = slottedContent.createEmbeddedView(undefined);
                onCleanup(() => view.destroy());
                // Return if empty, i.e., no icon to render.
                if (!view.rootNodes.length) {
                    icon.set(undefined);
                    return;
                }
                // Ensure only text is provided as slotted content.
                if (view.rootNodes.length > 1 || view.rootNodes[0].nodeType !== Node.TEXT_NODE) {
                    throw Error('[InvalidInputError] Only text (ligature) is allowed in slotted content of <sci-icon>.');
                }
                // Watch slotted content.
                const textNode = view.rootNodes[0];
                const subscription = of(textNode.textContent)
                    .pipe(concatWith(fromMutation$(textNode, { characterData: true }).pipe(map(() => textNode.textContent))), map(slottedContent => iconProviders.provide(slottedContent.trim() || undefined)), augmentIconDescriptor())
                    .subscribe(iconDescriptor => icon.set(iconDescriptor));
                onCleanup(() => subscription.unsubscribe());
            });
        });
        return icon;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "21.0.0", type: SciIconComponent, isStandalone: true, selector: "sci-icon", viewQueries: [{ propertyName: "_slottedContent", first: true, predicate: ["slotted_content"], descendants: true, isSignal: true }], ngImport: i0, template: "<ng-container *sciComponentOutlet=\"icon()\"/>\n\n<!--Template to capture slotted content. -->\n<ng-template #slotted_content>\n  <ng-content/>\n</ng-template>\n", styles: [":host{display:inline-grid;place-content:center;-webkit-user-select:none;user-select:none}\n"], dependencies: [{ kind: "directive", type: SciComponentOutletDirective, selector: "ng-template[sciComponentOutlet]", inputs: ["sciComponentOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sci-icon', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        SciComponentOutletDirective,
                    ], template: "<ng-container *sciComponentOutlet=\"icon()\"/>\n\n<!--Template to capture slotted content. -->\n<ng-template #slotted_content>\n  <ng-content/>\n</ng-template>\n", styles: [":host{display:inline-grid;place-content:center;-webkit-user-select:none;user-select:none}\n"] }]
        }], propDecorators: { _slottedContent: [{ type: i0.ViewChild, args: ['slotted_content', { isSignal: true }] }] } });
/**
 * Augments the icon descriptor:
 *
 * - Prevents the browser from translating the icon.
 * - Sets the icon's font size to 'var(--sci-icon-size, 1em)', required to inherit the location's font size for icons with a fixed font size.
 *   For example, Material sets a fixed font size of 24px.
 */
function augmentIconDescriptor() {
    return map((icon) => icon && {
        ...icon,
        attributes: computed(() => ({
            ...coerceSignal(icon.attributes)?.(),
            translate: 'no',
        })),
        directives: [
            ...icon.directives ?? [],
            IconFontSizeDirective,
        ],
    });
}
/**
 * Sets the font size to 'var(--sci-icon-size, 1em)', required to inherit the location's font size for icons with a fixed font size.
 * For example, Material sets a fixed font size of 24px.
 */
class IconFontSizeDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: IconFontSizeDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.0.0", type: IconFontSizeDirective, isStandalone: true, host: { properties: { "style.font-size": "'var(--sci-icon-size, 1em)'" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: IconFontSizeDirective, decorators: [{
            type: Directive,
            args: [{ host: { '[style.font-size]': `'var(--sci-icon-size, 1em)'` } }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Enables contribution or replacement of icons used in SCION.
 *
 * An icon provider is a function that returns a component for an icon. The component renders the icon.
 *
 * Multiple icon providers can be registered. Providers are called in registration order. If a provider does not provide the icon,
 * the next provider is called, and so on.
 *
 * Defaults to a Material icon provider, interpreting the icon as a Material icon ligature.
 *
 * The default icon provider requires the application to include the Material icon font, for example in `styles.scss`, as follows:
 * ```scss
 * @import url('https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded');
 * ```
 *
 * SCION uses the following icons:
 * - `scion.clear`: Clear button in input fields
 * - `scion.close`: Close button in views, dialogs and notifications
 * - `scion.dirty`: Visual indicator for view with unsaved content
 * - `scion.menu_down`: Menu button of drop down menus
 * - `scion.minimize`: Minimize button in docked parts
 * - `scion.pin`: Visual indicator for a pinned view
 * - `scion.search`: Visual indicator in search or filter fields
 *
 * To not replace built-in icons, the icon provider can return `undefined` for icons starting with the `scion.` prefix.
 *
 * The function can call `inject` to get any required dependencies.
 *
 * @see SciIconProviderFn
 * @see SciIconComponent
 */
function provideIconProvider(iconProviderFn) {
    return makeEnvironmentProviders(iconProviderFn ? [
        {
            provide: SCI_ICON_PROVIDER,
            useValue: iconProviderFn,
            multi: true,
        },
    ] : []);
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SciIconComponent, provideIconProvider };
//# sourceMappingURL=scion-components-icon.mjs.map
