import * as i0 from '@angular/core';
import { inject, InjectionToken, assertNotInReactiveContext, signal, Injector, runInInjectionContext, computed, isSignal, Injectable, makeEnvironmentProviders, untracked, Pipe } from '@angular/core';
import { Maps, runSafe } from '@scion/toolkit/util';
import { createDestroyableInjector } from '@scion/components/common';

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Texts used in @scion/components.
 *
 * To express the usage of a translation, add a suffix to the key:
 *
 * ```md
 * | Suffix   | Usage                    | Conventions                                 | Examples           |
 * |----------|--------------------------|---------------------------------------------|--------------------|
 * | .title   | - view title             | - Starts with a capital letter.             | - Settings         |
 * |          | - dialog title           | - No punctuation.                           | - Page Not Found   |
 * |          | - popup title            | - Words in capital letter.                  | - Confirm Deletion |
 * |          | - tab name               | - Verbs in the imperative form.             |                    |
 * |          | - column header in table |                                             |                    |
 * |          |                          |                                             |                    |
 * | .label   | - field label            | - Starts with a capital letter.             |                    |
 * |          |                          | - No punctuation.                           |                    |
 * |          |                          |                                             |                    |
 * | .action  | - button                 | - Starts with a capital letter.             | - Cancel           |
 * |          | - menu item              | - No punctuation.                           | - Close            |
 * |          |                          | - Verbs in the imperative form.             | - Delete...        |
 * |          |                          | - Suffix the action with an ellipsis        |                    |
 * |          |                          |   if there are additional options to enter. |                    |
 * |          |                          |                                             |                    |
 * | .tooltip | - tooltip                | - Starts with a capital letter.             | - Show Open Tabs   |
 * |          |                          | - No punctuation.                           | - Close            |
 * |          |                          | - Words in capital letter, unless a full    |                    |
 * |          |                          |   sentence.                                 |                    |
 * |          |                          |                                             |                    |
 * | .value   | - table cell             | - No punctuation.                           |                    |
 * |          | - drop down proposal     |                                             |                    |
 * |          | - list content           |                                             |                    |
 * |          |                          |                                             |                    |
 * | .message | - message                | - Full sentences.                           |                    |
 * |          | - warning                | - Punctuation.                              |                    |
 * |          | - error                  |                                             |                    |
 * |          | - info                   |                                             |                    |
 * ```
 */
const texts = {
    'scion.components.menu.no_items.message': 'No items found.',
    'scion.components.menu.type_to_filter.action': 'Type to filter',
    'scion.components.menu.clear.tooltip': 'Clear',
};
/**
 * Provides built-in texts of @scion/components.
 */
const scionComponentsTextProvider = (key, params) => {
    // Get the text.
    const text = texts[key];
    if (text === undefined) {
        return undefined;
    }
    // Replace params, if any.
    if (Object.keys(params).length) {
        return text.replace(/{{(?<param>[^}]+)}}/g, (match, param) => params[param] ?? match);
    }
    return text;
};

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Provides texts based on registered text providers.
 */
class TextProviders {
    _textProviders = [
        // Provide app-specific texts.
        ...inject(SCI_TEXT_PROVIDER, { optional: true }) ?? [],
        // Provide built-in texts of @scion/components.
        scionComponentsTextProvider,
    ];
    /**
     * Provides the text for the given {@link Translatable} based on text providers registered under the {@link SCI_TEXT_PROVIDER} DI token.
     *
     * Text providers are called in registration order. If a provider does not provide the text, the next provider is called, and so on.
     *
     * This function must be called within an injection context, or an explicit {@link Injector} passed. Text providers may allocate resources
     * that are released only when the injector is destroyed. Destroy the injector when the text is no longer needed.
     */
    provide(translatable, options) {
        assertNotInReactiveContext(this.provide, 'Call TextProviders.provide() in a non-reactive (non-tracking) context.');
        if (!translatable?.startsWith('%') || translatable === '%' || !this._textProviders.length) {
            return signal(translatable);
        }
        // Parse translatable into key and params.
        const { key, params } = parseTranslatable(translatable);
        // Append params from options.
        Maps.coerce(options.params).forEach((value, name) => params.set(name, `${value}`));
        const injector = options.injector ?? inject(Injector);
        const errorHandler = (error) => {
            // Prefix the key with an additional `%` character to escape the leading `%` character. See console formatting rules: https://developer.mozilla.org/en-US/docs/Web/API/console
            console.error(`[TextProviderError] Failed to get text for '%${translatable}'. Caused by:`, error);
            return translatable;
        };
        for (const textProvider of this._textProviders) {
            // If `textProvider` throws an error, `runSafe` catches it and delegates execution to the error handler, logging the error and returning the translatable.
            const text = runInInjectionContext(injector, () => runSafe(() => textProvider(key, Object.fromEntries(params)), errorHandler));
            if (text !== undefined) {
                // If signal, wrap it in `computed` to handle errors.
                return isSignal(text) ? computed(() => runSafe(() => text(), errorHandler)) : signal(text);
            }
        }
        return signal(translatable);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: TextProviders, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: TextProviders, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: TextProviders, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * Parses a translation key into its key and parameters, if any.
 *
 * Examples:
 * - `%key`: translation key
 * - `%key;param=value`: translation key with a single interpolation parameter
 * - `%key;param1=value1;param2=value2`: translation key with multiple interpolation parameters
 */
function parseTranslatable(translationKey) {
    const { key, params } = /^%(?<key>[^;]+)(;(?<params>.*))?$/.exec(translationKey).groups;
    return { key: key, params: parseMatrixParams(params) };
}
/**
 * Parses params in matrix notation.
 *
 * Format: `param1=value1;param2=value2`
 */
function parseMatrixParams(matrixParams) {
    if (!matrixParams?.length) {
        return new Map();
    }
    const params = new Map();
    for (const match of encodeEscapedSemicolons(matrixParams).matchAll(/(?<paramName>[^=;]+)=(?<paramValue>[^;]*)/g)) {
        const { paramName, paramValue } = match.groups;
        params.set(paramName, decodeSemicolons(paramValue));
    }
    return params;
    /**
     * Encodes escaped semicolons (`\\;`) as `&#x3b` (Unicode) to prevent interpretation as interpolation parameter separators.
     */
    function encodeEscapedSemicolons(value) {
        return value.replaceAll('\\;', '&#x3b');
    }
    /**
     * Decodes encoded semicolons (`&#x3b`) back to semicolons (`;`).
     */
    function decodeSemicolons(value) {
        return value.replaceAll('&#x3b', ';');
    }
}
/**
 * Multi-DI token for injecting text providers.
 *
 * Multiple text providers can be registered. Providers are called in registration order.
 * If a provider does not provide the text, the next provider is called, and so on.
 */
const SCI_TEXT_PROVIDER = new InjectionToken('SCI_TEXT_PROVIDER');

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Enables localization of texts used in SCION.
 *
 * A text provider is a function that returns the text for a translation key.
 *
 * Multiple text providers can be registered. Providers are called in registration order. If a provider does not provide the text,
 * the next provider is called, and so on.
 *
 * The translation keys of built-in SCION texts start with the `scion.` prefix. To not localize built-in SCION texts, the text provider can return `undefined` instead.
 *
 * The function:
 * - Can call `inject` to get any required dependencies.
 * - Can call `toSignal` to convert an Observable to a Signal.
 *
 * @see SciTextProviderFn
 * @see text
 */
function provideTextProvider(textProviderFn) {
    return makeEnvironmentProviders(textProviderFn ? [
        {
            provide: SCI_TEXT_PROVIDER,
            useValue: textProviderFn,
            multi: true,
        },
    ] : []);
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
function text(translatable, options) {
    assertNotInReactiveContext(text, 'Call text() in a non-reactive (non-tracking) context, as it may allocate resources that are not released until the injection context is destroyed.');
    const callingContextInjector = options?.injector ?? inject(Injector);
    // Use a separate injection context per translatable to clean up allocated resources when it changes.
    let injector;
    // Call the text provider function.
    const translation = computed(() => {
        const keyOrText = isSignal(translatable) ? translatable() : translatable;
        return untracked(() => {
            // Destroy previous injection context, if any, to clean up allocated resources, like RxJS subscriptions.
            injector?.destroy();
            // Create new injection context.
            injector = createDestroyableInjector({ parent: callingContextInjector });
            // Call text providers.
            return injector.get(TextProviders).provide(keyOrText, { params: options?.params, injector });
        });
    }, ...(ngDevMode ? [{ debugName: "translation" }] : []));
    // Track translation in separate reactive context to not call the text provider function on translation change.
    return computed(() => translation()());
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Gets the text for given {@link Translatable} from registered text providers.
 *
 * A {@link Translatable} is a string that, if starting with the percent symbol (`%`), is passed to registered text providers for translation, with the percent symbol omitted.
 * Otherwise, the text is returned as is.
 *
 * A translation key may include parameters in matrix notation for text interpolation. Escape semicolons with two backslashes (`\\;`).
 *
 * Examples:
 * - `%key`: translation key
 * - `%key;param=value`: translation key with a single interpolation parameter
 * - `%key;param1=value1;param2=value2`: translation key with multiple interpolation parameters
 * - `text`: no translation key, text is returned as is
 */
class SciTextPipe {
    _translatable = signal(undefined, ...(ngDevMode ? [{ debugName: "_translatable" }] : []));
    _text = text(this._translatable);
    transform(translatable) {
        // DO NOT call text() on key change to avoid stale RxJS subscriptions of previous texts,
        // as allocated resources are only cleaned up when the injection context, such as this pipe, is destroyed.
        untracked(() => this._translatable.set(translatable));
        return this._text;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciTextPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "21.0.0", ngImport: i0, type: SciTextPipe, isStandalone: true, name: "sciText" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciTextPipe, decorators: [{
            type: Pipe,
            args: [{ name: 'sciText' }]
        }] });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SciTextPipe, provideTextProvider, text };
//# sourceMappingURL=scion-components-text.mjs.map
