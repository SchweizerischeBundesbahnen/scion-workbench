import * as i0 from '@angular/core';
import { signal, isSignal, inject, Injector, effect, untracked, DestroyRef, assertInInjectionContext as assertInInjectionContext$1, input, ElementRef, IterableDiffers, Renderer2, Directive, ViewContainerRef, inputBinding } from '@angular/core';
import { of, Observable } from 'rxjs';

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
function coerceSignal(value, options) {
    if (value === undefined) {
        return options?.defaultValue !== undefined ? signal(options.defaultValue) : undefined;
    }
    return isSignal(value) ? value : signal(value);
}
function toLazyObservable(signal, options) {
    if (signal === undefined) {
        return undefined;
    }
    if (!isSignal(signal)) {
        return of(signal);
    }
    const injector = options?.injector ?? inject(Injector);
    return new Observable(observer => {
        const initialValue = signal();
        let isFirstEffectRun = true;
        // Emit initial value synchronously.
        observer.next(initialValue);
        const effectRef = effect(() => {
            const value = signal();
            untracked(() => {
                if (!isFirstEffectRun || initialValue !== value) {
                    observer.next(value);
                }
                isFirstEffectRun = false;
            });
        }, ...(ngDevMode ? [{ debugName: "effectRef", injector, manualCleanup: true }] : [{ injector, manualCleanup: true }]));
        return () => effectRef.destroy();
    });
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Creates an injector that can be destroyed.
 *
 * Unlike when creating an injector using `Injector.create`, this injector also gets destroyed when the parent injector is destroyed,
 * plus, does not error when invoking destroyed if already destroyed.
 *
 * `parent`: (optional) A parent injector.
 * `name`: (optional) A developer-defined identifying name for the new injector.
 */
function createDestroyableInjector(options) {
    const parentInjector = options?.parent ?? inject(Injector);
    const injector = Injector.create({ parent: parentInjector, providers: options?.providers ?? [], name: options?.name });
    // Destroy injector manually as not destroyed when the parent injector is destroyed, unless used in the injection context of a component.
    parentInjector.get(DestroyRef).onDestroy(() => injector.destroy());
    const destroyFnDelegate = injector.destroy.bind(injector);
    const destroyRef = injector.get(DestroyRef);
    injector.destroy = () => {
        if (!destroyRef.destroyed) {
            destroyFnDelegate();
        }
    };
    return injector;
}
/**
 * Asserts that the current stack frame is within an injection context and has access to inject.
 *
 * Delegates to `assertInInjectionContext` from @angular/core, adding the given message to the error if the assertion fails.
 */
function assertInInjectionContext(debugFn, message) {
    try {
        assertInInjectionContext$1(debugFn);
    }
    catch {
        throw Error([`${debugFn.name}() can only be used within an injection context.`].concat(message ? message : []).join(' '));
    }
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Adds specified attributes to the host element.
 */
class SciAttributesDirective {
    attributes = input(undefined, ...(ngDevMode ? [{ debugName: "attributes", alias: 'sciAttributes' }] : [{ alias: 'sciAttributes' }]));
    constructor() {
        const host = inject(ElementRef).nativeElement;
        const attributeDiffer = inject(IterableDiffers).find([]).create();
        const renderer = inject(Renderer2);
        effect(() => {
            const attributes = this.attributes() ?? {};
            untracked(() => {
                // Delete removed attributes.
                const diff = attributeDiffer.diff(Object.keys(attributes));
                if (diff) {
                    diff.forEachRemovedItem(({ item: name }) => renderer.removeAttribute(host, name));
                }
                // Update added or changed attributes.
                Object.entries(attributes).forEach(([key, value]) => {
                    if (value !== undefined && value !== null) {
                        renderer.setAttribute(host, key, value);
                    }
                    else {
                        renderer.removeAttribute(host, key);
                    }
                });
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciAttributesDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.0.0", type: SciAttributesDirective, isStandalone: true, selector: "[sciAttributes]", inputs: { attributes: { classPropertyName: "attributes", publicName: "sciAttributes", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciAttributesDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[sciAttributes]' }]
        }], ctorParameters: () => [], propDecorators: { attributes: [{ type: i0.Input, args: [{ isSignal: true, alias: "sciAttributes", required: false }] }] } });

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
/**
 * Renders a component, similar to `ngComponentOutlet`, but with input bindings.
 *
 * Usage:
 *
 * ```html
 * <ng-container *sciComponentOutlet="descriptor"/>
 * ````
 *
 * @see WbComponentPortal
 */
class SciComponentOutletDirective {
    descriptor = input.required(...(ngDevMode ? [{ debugName: "descriptor", alias: 'sciComponentOutlet' }] : [{ alias: 'sciComponentOutlet' }]));
    constructor() {
        const viewContainerRef = inject(ViewContainerRef);
        effect(onCleanup => {
            const descriptor = this.descriptor();
            untracked(() => {
                const component = descriptor && createComponent(viewContainerRef, descriptor);
                onCleanup(() => component?.destroy());
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciComponentOutletDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.0.0", type: SciComponentOutletDirective, isStandalone: true, selector: "ng-template[sciComponentOutlet]", inputs: { descriptor: { classPropertyName: "descriptor", publicName: "sciComponentOutlet", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: SciComponentOutletDirective, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[sciComponentOutlet]' }]
        }], ctorParameters: () => [], propDecorators: { descriptor: [{ type: i0.Input, args: [{ isSignal: true, alias: "sciComponentOutlet", required: true }] }] } });
function createComponent(viewContainerRef, descriptor) {
    // Provide providers via host directive.
    class ProvidersDirective {
        static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ProvidersDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
        static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.0.0", type: ProvidersDirective, isStandalone: true, providers: descriptor.providers ?? [], ngImport: i0 });
    }
    i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: ProvidersDirective, decorators: [{
                type: Directive,
                args: [{ providers: descriptor.providers ?? [] }]
            }] });
    // Provide CSS classes via host directive.
    class CssClassDirective {
        cssClass = coerceSignal(descriptor.cssClass);
        static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: CssClassDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
        static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.0.0", type: CssClassDirective, isStandalone: true, host: { properties: { "class": "cssClass?.()" } }, ngImport: i0 });
    }
    i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: CssClassDirective, decorators: [{
                type: Directive,
                args: [{ host: { '[class]': 'cssClass?.()' } }]
            }] });
    return viewContainerRef.createComponent(descriptor.component, {
        directives: [
            ProvidersDirective,
            CssClassDirective,
            { type: SciAttributesDirective, bindings: [inputBinding('sciAttributes', coerceSignal(descriptor.attributes ?? {}))] },
            ...descriptor.directives ?? [],
        ],
        bindings: descriptor.bindings,
        injector: descriptor.injector,
    });
}

/*
 * Copyright (c) 2018-2026 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/*
 * Secondary entrypoint: '@scion/components/common'
 *
 * @see https://github.com/ng-packagr/ng-packagr/blob/master/docs/secondary-entrypoints.md
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SciAttributesDirective, SciComponentOutletDirective, assertInInjectionContext, coerceSignal, createDestroyableInjector, toLazyObservable };
//# sourceMappingURL=scion-components-common.mjs.map
