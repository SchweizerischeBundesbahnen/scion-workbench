import { SciComponentDescriptor } from '@scion/components/common';
import { ComponentType } from '@angular/cdk/portal';
import * as i0 from '@angular/core';
import { Signal, EnvironmentProviders } from '@angular/core';

/**
 * Signature of a function to provide icons.
 *
 * An icon provider is a function that returns the component for an icon. The component renders the icon.
 *
 * Alternatively, the icon provider can return a descriptor, allowing for additional configuration such as inputs.
 * Inputs are available as input properties in the component. The component can use the inputs to render the icon.
 *
 * Icon keys used by SCION start with the `scion.` prefix. To not replace built-in icons, the icon provider can
 * return `undefined` for icons starting with the `scion.` prefix.
 *
 * An icon provider can be registered via {@link provideIconProvider} function.
 *
 * The function can call `inject` to get any required dependencies.
 *
 * @param icon - The key of the icon for which to provide the icon component.
 * @return ComponentType or {@link SciComponentDescriptor} to render the icon, or `undefined` if not provided by the icon provider.
 */
type SciIconProviderFn = (icon: string) => ComponentType<unknown> | SciComponentDescriptor | undefined;

/**
 * Renders an icon based on registered icon providers.
 *
 * Use the icon name as slotted content of the `<sci-icon>` component.
 *
 * Example:
 * ```html
 * <sci-icon>home</sci-icon>
 * ```
 *
 * Providers are called in registration order. If a provider does not provide the icon, the next provider is called, and so on.
 * If no provider provides the icon, defaults to a Material icon provider, interpreting the icon as a Material icon ligature.
 *
 * The icon size depends on the font size at its position in the DOM.
 * To change the size, set a font-size on the `<sci-icon>` element or set the `--sci-icon-size` CSS variable.
 *
 * @see provideIconProvider
 */
declare class SciIconComponent {
    private readonly _slottedContent;
    protected readonly icon: Signal<SciComponentDescriptor | undefined>;
    /**
     * Reads the icon from slotted content and passes it to registered icon providers for resolution.
     */
    private computeIcon;
    static ɵfac: i0.ɵɵFactoryDeclaration<SciIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SciIconComponent, "sci-icon", never, {}, {}, never, ["*"], true, never>;
}

/**
 * Enables contribution or replacement of icons used in SCION.
 *
 * An icon provider is a function that returns a component for an icon. The component renders the icon.
 *
 * Multiple icon providers can be registered. Providers are called in registration order. If a provider does not provide the icon,
 * the next provider is called, and so on.
 *
 * Defaults to a Material icon provider, interpreting the icon as a Material icon ligature.
 *
 * The default icon provider requires the application to include the Material icon font, for example in `styles.scss`, as follows:
 * ```scss
 * @import url('https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded');
 * ```
 *
 * SCION uses the following icons:
 * - `scion.clear`: Clear button in input fields
 * - `scion.close`: Close button in views, dialogs and notifications
 * - `scion.dirty`: Visual indicator for view with unsaved content
 * - `scion.menu_down`: Menu button of drop down menus
 * - `scion.minimize`: Minimize button in docked parts
 * - `scion.pin`: Visual indicator for a pinned view
 * - `scion.search`: Visual indicator in search or filter fields
 *
 * To not replace built-in icons, the icon provider can return `undefined` for icons starting with the `scion.` prefix.
 *
 * The function can call `inject` to get any required dependencies.
 *
 * @see SciIconProviderFn
 * @see SciIconComponent
 */
declare function provideIconProvider(iconProviderFn: SciIconProviderFn | undefined): EnvironmentProviders;

export { SciIconComponent, provideIconProvider };
export type { SciIconProviderFn };
