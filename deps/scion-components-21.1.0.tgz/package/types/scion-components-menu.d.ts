import * as i0 from '@angular/core';
import { ElementRef, ViewContainerRef, Injector, Binding, Provider, Signal, Type, EnvironmentProviders } from '@angular/core';
import { Translatable } from '@scion/components/text';
import { MaybeSignal, SciComponentDescriptor } from '@scion/components/common';
import { RequireOne, MaybeArray, Disposable, OneOf } from '@scion/toolkit/types';
import { ComponentType } from '@angular/cdk/portal';
import * as _scion_components_menu from '@scion/components/menu';

declare abstract class SciMenuService {
    abstract open(name: `menu:${string}`, options: SciMenuOptions): SciMenuRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<SciMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SciMenuService>;
}
interface SciMenuOptions {
    /**
     * Controls where to open the menu.
     *
     * Can be an HTML element or a coordinate. The coordinate is relative to the page viewport.
     *
     * Supported coordinate pairs:
     * - x/y: Relative to the top/left corner of the page viewport.
     * - top/left: Same as x/y.
     * - top/right: Relative to the top/right corner of the page viewport.
     * - bottom/left: Relative to the bottom/left corner of the page viewport.
     * - bottom/right: Relative to the bottom/right corner of the page viewport.
     */
    anchor: HTMLElement | ElementRef<HTMLElement> | SciMenuOrigin | MouseEvent;
    context?: Map<string, unknown>;
    /**
     * Controls where to align the menu relative to the menu anchor, unless there is not enough space available in that area. Defaults to `vertical`.
     */
    align?: 'vertical' | 'horizontal';
    /**
     * Controls where the menu will be added to the DOM. If not specified, adds the menu after the anchor element.
     */
    viewContainerRef?: ViewContainerRef;
    width?: string;
    minWidth?: string;
    maxWidth?: string;
    maxHeight?: string;
    filter?: boolean | RequireOne<{
        placeholder?: MaybeSignal<Translatable>;
        notFoundText?: MaybeSignal<Translatable>;
        focus?: boolean;
    }>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    /**
     * Arbitrary metadata to be associated with the operation.
     */
    metadata?: {
        [key: string]: unknown;
    };
}
/**
 * Represents a point on the page, optionally with a dimension, where a menu should be attached.
 */
interface SciMenuOrigin {
    x: number;
    y: number;
    width?: number;
    height?: number;
}
interface SciMenuRef {
    close(): void;
    /**
     * Registers a close callback.  Returns a cleanup function that can be invoked to unregister the callback.
     *
     * The callback is immediately called if registering a callback and the menu is already closed.
     */
    onClose: (fn: () => void) => void;
}

/**
 * INPUTS FOR DOCUMENTING THIS FUNCTION:
 *
 * Installs accelerator keys of specified menu items on specified element.
 *
 * Accelerators are strings that can be used to represent keyboard shortcuts throughout your Electron. These strings can contain multiple modifier keys and a single key code joined by the + character.
 *
 * Represents a keyboard shortcut (or accelerator) that lets a user perform an action using the keyboard instead of navigating the app UI (directly or through access keys).
 *
 * An accelerator key can be a single key, such as F1 - F12 and Esc, or a combination of keys (Ctrl + Shift + B, or Ctrl C) that invoke a command. They differ from access keys (mnemonics), which are typically modified with the Alt key and simply activate a command or control.
 *
 * Unsubscribes from keyboard events when the injection context is destroyed.
 *
 * TODO [menu] consider renaming to registerAccelerator (like in electron)
 */
declare function installMenuAccelerators(location: `menu:${string}` | `toolbar:${string}` | `menubar:${string}`, options?: SciMenuAcceleratorOptions): Disposable;
interface SciMenuAcceleratorOptions {
    target?: MaybeArray<Element | ElementRef<Element>>;
    context?: Map<string, unknown>;
    injector?: Injector;
    metadata?: {
        [key: string]: unknown;
    };
}
/**
 * Single key (A, Delete, F2, Spacebar, Esc, Multimedia Key) accelerators and multi-key accelerators (Ctrl+Shift+M) are supported.
 */
interface SciKeyboardAccelerator {
    key: string;
    /**
     * Specifies if the Control or Command (macOS) is required.
     */
    ctrl?: boolean;
    /**
     * Specifies if the Shift key is required.
     */
    shift?: boolean;
    /**
     * Specifies if the Alt key is required.
     */
    alt?: boolean;
    /**
     * Defines the specific physical location of the key.
     *
     * - `numpad`: Keys on the number pad.
     * - `left`: Use only the left-side version of the key.
     * - `right`: Use only the right-side version of the key.
     *
     * @see https://developer.mozilla.org/en-US/docs/Web/API/KeyboardEvent/location
     */
    location?: 'numpad' | 'left' | 'right';
}

interface SciToolbarFactory {
    addToolbarButton(descriptor: SciToolbarButtonDescriptor): this;
    addToolbarSplitButton(descriptor: SciToolbarButtonDescriptor & {
        menu?: SciMenuDescriptor['menu'];
    }, menuFactoryFn: (menu: SciMenuFactory) => void): this;
    addToolbarMenu(descriptor: SciToolbarMenuDescriptor, menuFactoryFn: (menu: SciMenuFactory) => void): this;
    addToolbarControl(descriptor: SciToolbarControlDescriptor): this;
    addToolbarSplitControl(descriptor: SciToolbarControlDescriptor & {
        menu?: SciMenuDescriptor['menu'];
    }, menuFactoryFn: (menu: SciMenuFactory) => void): this;
    addGroup(groupFactoryFn: (group: SciToolbarFactory) => void): this;
    addGroup(descriptor: SciToolbarGroupDescriptor, groupFactoryFn?: (group: SciToolbarFactory) => void): this;
}
interface SciToolbarButtonDescriptor {
    name?: `menuitem:${string}`;
    label?: MaybeSignal<Translatable> | ComponentType<unknown> | SciComponentDescriptor;
    icon?: MaybeSignal<string> | ComponentType<unknown> | SciComponentDescriptor;
    checked?: MaybeSignal<boolean>;
    tooltip?: MaybeSignal<Translatable>;
    accelerator?: SciKeyboardAccelerator;
    disabled?: MaybeSignal<boolean>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    onSelect: () => void | boolean | Promise<void | boolean>;
}
interface SciToolbarMenuDescriptor {
    name?: `menuitem:${string}`;
    label?: MaybeSignal<Translatable> | ComponentType<unknown> | SciComponentDescriptor;
    icon?: MaybeSignal<string> | ComponentType<unknown> | SciComponentDescriptor;
    tooltip?: MaybeSignal<Translatable>;
    disabled?: MaybeSignal<boolean>;
    /**
     * Controls the display of a visual marker for menu dropdown. Defaults to `true`.
     */
    visualMenuHint?: boolean;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    menu?: SciMenuDescriptor['menu'];
}
interface SciToolbarControlDescriptor {
    name?: `menuitem:${string}`;
    component: ComponentType<unknown>;
    bindings?: Binding[];
    injector?: Injector;
    providers?: Provider[];
    tooltip?: MaybeSignal<Translatable>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
}
interface SciToolbarGroupDescriptor {
    name?: `toolbar:${string}`;
    disabled?: MaybeSignal<boolean>;
    cssClass?: string | string[];
}

interface SciMenuFactory {
    addMenuItem(descriptor: SciMenuItemDescriptor): this;
    addMenu(descriptor: SciMenuDescriptor, menuFactoryFn: (menu: SciMenuFactory) => void): this;
    addGroup(groupFactoryFn: (group: SciMenuFactory) => void): this;
    addGroup(descriptor: SciMenuGroupDescriptor, groupFactoryFn?: (group: SciMenuFactory) => void): this;
}
interface SciMenuItemDescriptor {
    name?: `menuitem:${string}`;
    label: MaybeSignal<Translatable> | ComponentType<unknown> | SciComponentDescriptor;
    icon?: MaybeSignal<string> | ComponentType<unknown> | SciComponentDescriptor;
    checked?: MaybeSignal<boolean>;
    active?: MaybeSignal<boolean>;
    tooltip?: MaybeSignal<Translatable>;
    accelerator?: SciKeyboardAccelerator;
    disabled?: MaybeSignal<boolean>;
    actions?: (actions: SciToolbarFactory) => void;
    onFilter?: (filter: string) => boolean;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    onSelect: () => void | boolean | Promise<void | boolean>;
}
interface SciMenuDescriptor {
    name?: `menuitem:${string}`;
    label: MaybeSignal<Translatable> | ComponentType<unknown> | SciComponentDescriptor;
    icon?: MaybeSignal<string> | ComponentType<unknown> | SciComponentDescriptor;
    disabled?: MaybeSignal<boolean>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    menu?: {
        name?: `menu:${string}`;
        width?: string;
        minWidth?: string;
        maxWidth?: string;
        maxHeight?: string;
        filter?: boolean | RequireOne<{
            placeholder?: MaybeSignal<Translatable>;
            notFoundText?: MaybeSignal<Translatable>;
            focus?: boolean;
        }>;
    };
}
interface SciMenuGroupDescriptor {
    name?: `menu:${string}`;
    label?: MaybeSignal<Translatable>;
    collapsible?: boolean | {
        collapsed: boolean;
    };
    /**
     * TODO [menu]: Explain what glyph area is.
     *
     * Controls whether to hide the glyph area in this group.
     * Defaults to displaying the glyph area if any menu item contained in the menu or its groups has an icon or is checkable.
     */
    glyphArea?: false;
    disabled?: MaybeSignal<boolean>;
    actions?: (actions: SciToolbarFactory) => void;
    cssClass?: string | string[];
}

interface SciMenubarFactory {
    addMenu(descriptor: SciMenubarMenuDescriptor, menuFactoryFn: (menu: SciMenuFactory) => void): this;
}
interface SciMenubarMenuDescriptor {
    name?: `menuitem:${string}`;
    label: MaybeSignal<Translatable>;
    cssClass?: string | string[];
    attributes?: {
        [name: string]: string;
    };
    menu?: SciMenuDescriptor['menu'];
}

interface SciMenuContribution {
    scope: 'menu' | 'toolbar' | 'menubar';
    factoryFn: SciMenuFactoryFnLike;
    requiredContext: Map<string, unknown>;
    position?: SciMenuContributionPositionLike;
    contributionInstant: number;
    /**
     * Arbitrary metadata to be associated with the contribution.
     */
    metadata: {
        [key: string]: unknown;
    };
}
type SciMenuContributionLocation = {
    location: `menu:${string}`;
} & SciMenuContributionPosition;
type SciToolbarContributionLocation = {
    location: `toolbar:${string}`;
} & SciToolbarContributionPosition;
type SciMenubarContributionLocation = {
    location: `menubar:${string}`;
} & SciMenubarContributionPosition;
type SciMenuContributionLocationLike = SciMenuContributionLocation | SciToolbarContributionLocation | SciMenubarContributionLocation;
interface SciMenuContributionOptions {
    /**
     * This function must be called within an injection context, or an explicit {@link Injector} passed. Destroying the injection context will unregister contributed menus.
     */
    injector?: Injector;
    /**
     * Context required by the contribution.
     */
    requiredContext?: Map<string, unknown>;
    /**
     * Arbitrary metadata to be associated with the contribution.
     */
    metadata?: {
        [key: string]: unknown;
    };
    contributionInstant?: number;
}
type SciMenuContributionPosition = OneOf<{
    before?: `menuitem:${string}` | `menu:${string}`;
    after?: `menuitem:${string}` | `menu:${string}`;
    position?: 'start' | 'end';
}>;
type SciToolbarContributionPosition = OneOf<{
    before?: `menuitem:${string}` | `toolbar:${string}`;
    after?: `menuitem:${string}` | `toolbar:${string}`;
    position?: 'start' | 'end';
}>;
type SciMenubarContributionPosition = OneOf<{
    before?: `menu:${string}`;
    after?: `menu:${string}`;
    position?: 'start' | 'end';
}>;
type SciMenuContributionPositionLike = SciMenuContributionPosition | SciToolbarContributionPosition | SciMenubarContributionPosition;
type SciMenuFactoryFn = (menu: SciMenuFactory, context: Map<string, unknown>) => void;
type SciToolbarFactoryFn = (toolbar: SciToolbarFactory, context: Map<string, unknown>) => void;
type SciMenubarFactoryFn = (menubar: SciMenubarFactory, context: Map<string, unknown>) => void;
type SciMenuFactoryFnLike = SciMenuFactoryFn | SciToolbarFactoryFn | SciMenubarFactoryFn;

/**
 * INPUTS FOR DESCRIPTION: https://www.electronjs.org/docs/latest/api/menu-item
 */
interface SciMenuItem {
    type: 'menu-item';
    name?: `menuitem:${string}`;
    labelText?: Signal<string>;
    labelComponent?: SciComponentDescriptor;
    iconLigature?: Signal<string>;
    iconComponent?: SciComponentDescriptor;
    control?: SciComponentDescriptor;
    tooltip?: Signal<string>;
    accelerator?: SciKeyboardAccelerator;
    disabled?: Signal<boolean>;
    checked?: Signal<boolean>;
    active?: Signal<boolean>;
    actions?: SciMenuItemLike[];
    matchesFilter?: (filter: string) => boolean;
    position?: SciMenuContributionPositionLike;
    visualMenuHint?: boolean;
    cssClass?: string[];
    attributes?: {
        [name: string]: string;
    };
    onSelect?: () => Promise<boolean>;
    menu?: {
        name?: `menu:${string}`;
        width?: string;
        minWidth?: string;
        maxWidth?: string;
        maxHeight?: string;
        filter?: {
            placeholder?: Signal<Translatable>;
            notFoundText?: Signal<Translatable>;
            focus?: boolean;
        };
        children: SciMenuItemLike[];
    };
}
interface SciMenuGroup {
    type: 'group';
    name?: `menu:${string}` | `toolbar:${string}`;
    label?: Signal<string>;
    collapsible?: {
        collapsed: boolean;
    };
    glyphArea?: false;
    disabled?: Signal<boolean>;
    position?: SciMenuContributionPositionLike;
    actions?: SciMenuItemLike[];
    children: SciMenuItemLike[];
    cssClass?: string[];
}
type SciMenuItemLike = SciMenuItem | SciMenuGroup;

/**
 * @docs-private Not public API. For internal use only.
 */
declare class ɵSciMenuService implements SciMenuService {
    private readonly _menuRegistry;
    private readonly _injector;
    private readonly _menuEnvironmentProviders;
    /** @inheritDoc */
    open(menu: `menu:${string}` | SciMenuItemLike[], options: SciMenuOptions): SciMenuRef;
    /**
     * The function:
     * - Must be called within an injection context, or an explicit {@link Injector} passed.
     * - Must be called in a non-reactive (non-tracking) context.
     *
     * @docs-private Not public API. For internal use only.
     */
    menuItems(location: MaybeSignal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: MaybeSignal<Map<string, unknown>>, options?: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }): Signal<SciMenuItemLike[]>;
    /** @docs-private Not public API. For internal use only. */
    menuContributions(location: MaybeSignal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: MaybeSignal<Map<string, unknown>>, options?: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }): Signal<SciMenuContribution[]>;
    /** @docs-private Not public API. For internal use only. */
    contributeMenu(location: SciMenuContributionLocationLike, factoryFn: SciMenuFactoryFnLike, options?: SciMenuContributionOptions): Disposable;
    /**
     * Gets accelerators of currently used menu items, optionally filtered by context.
     *
     * An accelerator matches if its menu item's context is the same as, a subset of, or has extra values compared to the given context. It never matches if a context value is different.
     *
     * IMPORTANT: Unlike {@link menuItems}, this method is based on currently used menu items, not available contributions.
     * If a contribution is not used in the application, its accelerators are not returned.
     *
     * @docs-private Not public API. For internal use only.
     */
    accelerators(options?: {
        context?: MaybeSignal<Map<string, unknown>>;
    }): Signal<SciKeyboardAccelerator[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ɵSciMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ɵSciMenuService>;
}
/**
 * Provides {@link SciMenuService} for dependency injection.
 */
declare function provideMenuService(): Provider[];

/**
 * Allows intercepting calls to the menu registry.
 *
 * Adapters can handle or augment calls. Multiple adapters form a chain and are called one by one in registration order.
 *
 * Calling 'next' passes the call to the next adapter, or to the registry if it is the last adapter in the chain.
 */
declare abstract class SciMenuAdapter {
    abstract contributeMenu?(location: SciMenuContributionLocationLike, factoryFn: SciMenuFactoryFnLike, options: SciMenuContributionOptions, next: SciMenuAdapterChain): Disposable;
    abstract menuContributions?(location: Signal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: Signal<Map<string, unknown>>, options: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }, next: SciMenuAdapterChain): Signal<SciMenuContribution[]>;
    abstract menuItems?(location: Signal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: Signal<Map<string, unknown>>, options: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }, next: SciMenuAdapterChain): Signal<SciMenuItemLike[]>;
    abstract openMenu?(menu: `menu:${string}` | SciMenuItemLike[], options: SciMenuOptions, next: SciMenuAdapterChain): SciMenuRef;
    abstract accelerators?(context: Signal<Map<string, unknown>>, next: SciMenuAdapterChain): Signal<SciKeyboardAccelerator[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SciMenuAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SciMenuAdapter>;
}
/**
 * Represents the next adapter in the adapter chain.
 */
interface SciMenuAdapterChain {
    contributeMenu(location: SciMenuContributionLocationLike, factoryFn: SciMenuFactoryFnLike, options: SciMenuContributionOptions): Disposable;
    menuContributions(location: Signal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: Signal<Map<string, unknown>>, options: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }): Signal<SciMenuContribution[]>;
    menuItems(location: Signal<`menu:${string}` | `toolbar:${string}` | `menubar:${string}`>, context: Signal<Map<string, unknown>>, options: {
        injector?: Injector;
        metadata?: {
            [key: string]: unknown;
        };
    }): Signal<SciMenuItemLike[]>;
    openMenu(menu: `menu:${string}` | SciMenuItemLike[], options: SciMenuOptions): SciMenuRef;
    accelerators(context: Signal<Map<string, unknown>>): Signal<SciKeyboardAccelerator[]>;
}

/**
 * By default, the contribution will be unregistered when the current injection context is destroyed.
 */
declare function contributeMenu(location: `menu:${string}` | SciMenuContributionLocation, menuFactoryFn: SciMenuFactoryFn, options?: SciMenuContributionOptions): Disposable;
declare function contributeMenu(location: `toolbar:${string}` | SciToolbarContributionLocation, toolbarFactoryFn: SciToolbarFactoryFn, options?: SciMenuContributionOptions): Disposable;
declare function contributeMenu(location: `menubar:${string}` | SciMenubarContributionLocation, menubarFactoryFn: SciMenubarFactoryFn, options?: SciMenuContributionOptions): Disposable;

/**
 * Provides a context for contributions and locations such as toolbars and context menus.
 *
 * The provided environment context is used as the "required" context for contributions and the "available" context for locations.
 *
 * Contributions and locations can override or extend the context.
 *
 * Can be registered via {@link provideMenuEnvironmentProvider}.
 *
 * @see provideMenuEnvironmentProvider
 */
declare abstract class SciMenuEnvironmentProvider {
    /**
     * Method invoked to provide the menu context from the calling injection context.
     *
     * The function can call `inject` to create the context based on the menu's injection context.
     */
    abstract provideContext?(): MaybeSignal<Map<string, unknown>>;
    /**
     * Method invoked to provide providers for dependency injection from given menu context.
     *
     * Returned providers are available for dependency injection in the menu factory passed to {@link contributeMenu}.
     */
    abstract provideInjectionContext?(context: Map<string, unknown>): Provider[];
    /**
     * The function can call `inject` to get targets based on the menu's injection context.
     */
    abstract provideAcceleratorTargets?(): MaybeSignal<MaybeArray<Element | ElementRef<Element>> | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SciMenuEnvironmentProvider, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SciMenuEnvironmentProvider>;
}

/**
 * Provides the environment for menus based on registered menu environment providers.
 *
 * @docs-private Not public API. For internal use only.
 */
declare class SciMenuEnvironmentProviders {
    private readonly _environmentProviders;
    provideContext(context: MaybeSignal<Map<string, unknown> | undefined>, options?: {
        injector?: Injector;
    }): Signal<Map<string, unknown>>;
    provideInjectionContext(menuContext: Map<string, unknown>): Provider[];
    provideAcceleratorTargets(options?: {
        injector?: Injector;
    }): Signal<Element[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SciMenuEnvironmentProviders, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SciMenuEnvironmentProviders>;
}
/**
 * @see SciMenuEnvironmentProvider
 */
declare function provideMenuEnvironmentProvider(menuEnvironmentProvider: Type<SciMenuEnvironmentProvider>): EnvironmentProviders;

/**
 * TODO [menu]: Explain how to size the toolbar. (height can be set; icon size by setting a CSS variable)
 *
 * TODO [menu]: Mention that component is :empty if no menu items, e.g., to hide empty toolbar:
 * ```scss
 * sci-toolbar:empty {
 *   display: none;
 * }
 * ```
 *
 * Control the toolbar item size by setting the `--sci-toolbar-item-size` CSS variable, globally in the document root or on a specific toolbar component. Defaults to 16px.
 */
declare class SciToolbarComponent {
    readonly name: i0.InputSignal<`toolbar:${string}`>;
    readonly orientation: i0.InputSignal<"horizontal" | "vertical">;
    readonly context: i0.InputSignal<Map<string, unknown> | undefined>;
    readonly acceleratorTarget: i0.InputSignal<MaybeArray<Element | ElementRef<Element>> | undefined>;
    readonly popoverViewContainerRef: i0.InputSignal<ViewContainerRef>;
    private readonly _context;
    protected readonly menuItems: i0.Signal<_scion_components_menu.SciMenuItemLike[]>;
    constructor();
    private installAccelerators;
    static ɵfac: i0.ɵɵFactoryDeclaration<SciToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SciToolbarComponent, "sci-toolbar", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "context": { "alias": "context"; "required": false; "isSignal": true; }; "acceleratorTarget": { "alias": "acceleratorTarget"; "required": false; "isSignal": true; }; "popoverViewContainerRef": { "alias": "popoverViewContainerRef"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * TODO [menu]: Explain how to size the menubar. (height can be set)
 */
declare class SciMenubarComponent {
    readonly name: i0.InputSignal<`menubar:${string}`>;
    readonly context: i0.InputSignal<Map<string, unknown> | undefined>;
    readonly acceleratorTarget: i0.InputSignal<MaybeArray<Element | ElementRef<Element>> | undefined>;
    readonly viewContainerRef: i0.InputSignal<ViewContainerRef | undefined>;
    private readonly _menuService;
    private readonly _context;
    protected readonly menuItems: Signal<SciMenuItem[]>;
    protected readonly activeMenuItem: i0.WritableSignal<{
        menuItem: SciMenuItem;
        element: HTMLElement;
        closing?: true | "prevented";
    } | null>;
    constructor();
    /**
     * Method invoked when clicking on a menu button.
     */
    protected onMenuItemClick(menuItem: SciMenuItem, element: HTMLElement): void;
    /**
     * Method invoked before clicking on a menu button.
     *
     * When clicking on the active menu button, mark it as closing to prevent immediate re-opening race condition on subsequent click event.
     */
    protected onMenuItemMouseDown(menuItem: SciMenuItem): void;
    /**
     * Method invoked when entering a menu button.
     *
     * Open menu if menubar is in 'menu-open' state.
     */
    protected onMenuItemMouseEnter(menuItem: SciMenuItem, element: HTMLElement): void;
    /**
     * Method invoked when leaving a menu button.
     *
     * Clean up closing state set by {@link onMenuButtonMouseDown}, if any.
     */
    protected onMenuItemMouseLeave(menuItem: SciMenuItem): void;
    private installAccelerators;
    static ɵfac: i0.ɵɵFactoryDeclaration<SciMenubarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SciMenubarComponent, "sci-menubar", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "context": { "alias": "context"; "required": false; "isSignal": true; }; "acceleratorTarget": { "alias": "acceleratorTarget"; "required": false; "isSignal": true; }; "viewContainerRef": { "alias": "viewContainerRef"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

export { SciMenuAdapter, SciMenuEnvironmentProvider, SciMenuEnvironmentProviders, SciMenuService, SciMenubarComponent, SciToolbarComponent, contributeMenu, installMenuAccelerators, provideMenuEnvironmentProvider, provideMenuService, ɵSciMenuService };
export type { SciKeyboardAccelerator, SciMenuAcceleratorOptions, SciMenuAdapterChain, SciMenuContribution, SciMenuContributionLocation, SciMenuContributionLocationLike, SciMenuContributionOptions, SciMenuContributionPosition, SciMenuContributionPositionLike, SciMenuDescriptor, SciMenuFactory, SciMenuFactoryFn, SciMenuFactoryFnLike, SciMenuGroup, SciMenuGroupDescriptor, SciMenuItem, SciMenuItemDescriptor, SciMenuItemLike, SciMenuOptions, SciMenuOrigin, SciMenuRef, SciMenubarContributionLocation, SciMenubarContributionPosition, SciMenubarFactory, SciMenubarFactoryFn, SciMenubarMenuDescriptor, SciToolbarButtonDescriptor, SciToolbarContributionLocation, SciToolbarContributionPosition, SciToolbarControlDescriptor, SciToolbarFactory, SciToolbarFactoryFn, SciToolbarGroupDescriptor, SciToolbarMenuDescriptor };
