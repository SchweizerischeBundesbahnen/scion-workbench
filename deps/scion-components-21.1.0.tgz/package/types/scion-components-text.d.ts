import { MaybeSignal } from '@scion/components/common';
import * as i0 from '@angular/core';
import { EnvironmentProviders, PipeTransform, Signal, Injector } from '@angular/core';

/**
 * Signature of a function to provide texts.
 *
 * Texts starting with the percent symbol (`%`) are passed to text providers for translation, with the percent symbol omitted.
 *
 * A text provider can be registered via {@link provideTextProvider} function.
 *
 * The function:
 * - Can call `inject` to get any required dependencies.
 * - Can call `toSignal` to convert an Observable to a Signal.
 *
 * @param key - Translation key of the text.
 * @param params - Parameters used for text interpolation.
 * @return Text associated with the key, or `undefined` if not found.
 *         Localized applications should return the text in the current language, and update the signal with the translated text each time when the language changes.
 */
type SciTextProviderFn = (key: string, params: {
    [name: string]: string;
}) => MaybeSignal<string> | undefined;
/**
 * Represents either a text or a key for translation.
 *
 * A translation key starts with the percent symbol (`%`) and may include parameters in matrix notation for text interpolation.
 *
 * Key and parameters are passed to registered text providers for translation. A text provider can be registered via
 * {@link provideTextProvider} function.
 *
 * Semicolons in interpolation parameters must be escaped with two backslashes (`\\;`).
 *
 * Examples:
 * - `%key`: translation key
 * - `%key;param=value`: translation key with a single interpolation parameter
 * - `%key;param1=value1;param2=value2`: translation key with multiple interpolation parameters
 * - `text`: no translation key, text is returned as is
 *
 * @see provideTextProvider
 */
type Translatable = string | `%${string}`;

/**
 * Enables localization of texts used in SCION.
 *
 * A text provider is a function that returns the text for a translation key.
 *
 * Multiple text providers can be registered. Providers are called in registration order. If a provider does not provide the text,
 * the next provider is called, and so on.
 *
 * The translation keys of built-in SCION texts start with the `scion.` prefix. To not localize built-in SCION texts, the text provider can return `undefined` instead.
 *
 * The function:
 * - Can call `inject` to get any required dependencies.
 * - Can call `toSignal` to convert an Observable to a Signal.
 *
 * @see SciTextProviderFn
 * @see text
 */
declare function provideTextProvider(textProviderFn: SciTextProviderFn | undefined): EnvironmentProviders;

/**
 * Gets the text for given {@link Translatable} from registered text providers.
 *
 * A {@link Translatable} is a string that, if starting with the percent symbol (`%`), is passed to registered text providers for translation, with the percent symbol omitted.
 * Otherwise, the text is returned as is.
 *
 * A translation key may include parameters in matrix notation for text interpolation. Escape semicolons with two backslashes (`\\;`).
 *
 * Examples:
 * - `%key`: translation key
 * - `%key;param=value`: translation key with a single interpolation parameter
 * - `%key;param1=value1;param2=value2`: translation key with multiple interpolation parameters
 * - `text`: no translation key, text is returned as is
 */
declare class SciTextPipe implements PipeTransform {
    private _translatable;
    private _text;
    transform(translatable: Translatable): Signal<string>;
    transform(translatable: Translatable | undefined): Signal<string | undefined>;
    transform(translatable: Translatable | null): Signal<string | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SciTextPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SciTextPipe, "sciText", true>;
}

/**
 * Gets the text for given {@link Translatable} from registered text providers.
 *
 * A {@link Translatable} is a string that, if starting with the percent symbol (`%`), is passed to registered text providers for translation, with the percent symbol omitted.
 * Otherwise, the text is returned as is.
 *
 * A translation key may include parameters for text interpolation. Interpolation parameters can be passed via options or appended to the translatable in matrix notation.
 * If appended, escape semicolons with two backslashes (`\\;`).
 *
 * Examples:
 * ```ts
 * // Get text for a key
 * text('%key');
 *
 * // Get text for a key and interpolation parameters
 * text('%key;param1=value1;param2=value2');
 *
 * // Or use the options object for interpolation parameters
 * text('%key', {params: {param1: 'value1', param2: 'value2'}});
 * ```
 *
 * The function:
 * - Must be called within an injection context, or an explicit {@link Injector} passed.
 * - Must be called in a non-reactive (non-tracking) context.
 *
 * @param translatable - Translation key (starts with `%`) or plain text.
 * @param options - Controls translation.
 * @param options.injector - Injector to call text providers. Defaults to the current injection context.
 *                           Note: Text providers may allocate resources that are released only when this injector is destroyed. Destroy the injector when the text is no longer needed.
 * @param options.params - Parameters for text interpolation.
 * @return Signal with the translated text.
 *
 * @see provideTextProvider
 */
declare function text(translatable: MaybeSignal<Translatable>, options?: {
    injector?: Injector;
    params?: Record<string, unknown> | Map<string, unknown>;
}): Signal<string>;
declare function text(translatable: MaybeSignal<Translatable | undefined>, options?: {
    injector?: Injector;
    params?: Record<string, unknown> | Map<string, unknown>;
}): Signal<string | undefined>;
declare function text(translatable: MaybeSignal<Translatable | null>, options?: {
    injector?: Injector;
    params?: Record<string, unknown> | Map<string, unknown>;
}): Signal<string | null>;
declare function text(translatable: MaybeSignal<Translatable | undefined | null>, options?: {
    injector?: Injector;
    params?: Record<string, unknown> | Map<string, unknown>;
}): Signal<string | undefined | null>;

export { SciTextPipe, provideTextProvider, text };
export type { SciTextProviderFn, Translatable };
