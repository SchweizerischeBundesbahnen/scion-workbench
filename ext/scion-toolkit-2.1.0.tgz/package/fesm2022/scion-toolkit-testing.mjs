import { AsyncSubject, ReplaySubject, bufferCount, throwError } from 'rxjs';
import { take, timeout } from 'rxjs/operators';

/**
 * Allows capturing emissions of an Observable.
 */
class ObserveCaptor {
    _projectFn;
    _values = [];
    _state;
    _error;
    _completeOrError$ = new AsyncSubject();
    _emitCount$ = new ReplaySubject(Infinity);
    /**
     * Constructs this captor. Optionally, you can provide a project function to map emitted values.
     */
    constructor(projectFn) {
        this._projectFn = projectFn ?? (value => value);
    }
    /**
     * @docs-private
     *
     * Note: Write as arrow function to retain the `this` reference when being invoked from another scope, e.g., from the global scope.
     */
    next = (value) => {
        this._values.push(this._projectFn(value));
        this._emitCount$.next();
    };
    /**
     * @docs-private
     *
     * Note: Write as arrow function to retain the `this` reference when being invoked from another scope, e.g., from the global scope.
     */
    error = (error) => {
        this._state = 'errored';
        this._error = error;
        this._completeOrError$.complete();
    };
    /**
     * @docs-private
     *
     * Note: Write as arrow function to retain the `this` reference when being invoked from another scope, e.g., from the global scope.
     */
    complete = () => {
        this._state = 'completed';
        this._completeOrError$.complete();
    };
    /**
     * Returns captured values in the order as emitted by the Observable.
     */
    getValues() {
        return this._values;
    }
    /**
     * Returns the last captured value, if any.
     */
    getLastValue() {
        return this._values.at(-1);
    }
    /**
     * Returns the error if the Observable errored.
     */
    getError() {
        return this._error;
    }
    /**
     * Indicates if the Observable completed. An Observable can either complete or error.
     */
    hasCompleted() {
        return this._state === 'completed';
    }
    /**
     * Indicates if the Observable errored. An Observable can either complete or error.
     */
    hasErrored() {
        return this._state === 'errored';
    }
    /**
     * Resets this captor.
     *
     * Pass options to control which aspects of this captor not to reset. By default, all aspects are reset.
     */
    reset(options) {
        const resetValues = options?.resetValues ?? true;
        const resetEmitCount = options?.resetEmitCount ?? true;
        if (resetValues) {
            this._values = [];
        }
        if (resetEmitCount) {
            this._emitCount$.error('[CaptorError] Captor has been reset.');
            this._emitCount$ = new ReplaySubject(Infinity);
        }
        return this;
    }
    /**
     * Waits until the Observable emits the given number of items, or throws if the given timeout elapses.
     */
    async waitUntilEmitCount(count, timeoutMs = 5000) {
        return new Promise((resolve, reject) => {
            this._emitCount$
                .pipe(bufferCount(count), // Swallow emissions in order not to deactivate the timeout timer.
            take(1), timeout({ first: timeoutMs, with: () => throwError(() => new Error('[CaptorTimeoutError] Timeout elapsed.')) }))
                .subscribe({
                error: error => reject(error instanceof Error ? error : Error(`${error}`)),
                complete: resolve,
            });
        });
    }
    /**
     * Waits until the Observable completes or errors.
     */
    async waitUntilCompletedOrErrored() {
        return new Promise(resolve => this._completeOrError$.subscribe({ complete: resolve }));
    }
}

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/*
 * Secondary entrypoint: '@scion/toolkit/testing'
 *
 * @see https://github.com/ng-packagr/ng-packagr/blob/master/docs/secondary-entrypoints.md
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ObserveCaptor };
//# sourceMappingURL=scion-toolkit-testing.mjs.map
