import { switchMap, defaultIfEmpty, catchError, distinctUntilChanged, map, take, mergeMap, share } from 'rxjs/operators';
import { of, combineLatest, pipe, identity, from, EMPTY, concat, Observable, ReplaySubject, takeUntil } from 'rxjs';
import { Observables, Objects, Arrays } from '@scion/toolkit/util';

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
function filterArray(predicate) {
    if (!predicate) {
        return source$ => source$;
    }
    return switchMap((items) => {
        if (!items.length) {
            return of([]);
        }
        // Filter items if all predicates return a boolean value.
        const matches = items.map(predicate);
        if (matches.every(match => typeof match === 'boolean')) {
            return of(items.filter((item, i) => matches[i]));
        }
        /*
         * Notes about `combineLatest` operator:
         * - Passing an empty array will result in an Observable that completes immediately.
         * - Waits for all Observables to emit at least once.
         * - If some Observable does not emit a value but completes, resulting Observable will complete at the same moment without emitting anything.
         * - If some Observable does not emit any value and never completes, `combineLatest` will also never emit and never complete.
         * - If any Observable errors, `combineLatest` will error immediately as well, and all other Observables will be unsubscribed.
         */
        return combineLatest(matches.map(match => Observables.coerce(match).pipe(defaultIfEmpty(false), catchError(() => of(false)))))
            .pipe(distinctUntilChanged((previous, current) => Objects.isEqual(previous, current)), map(matches => items.filter((item, i) => matches[i])));
    });
}
/**
 * Maps each element in the source array to its mapped value.
 */
function mapArray(projectFn) {
    return map((items) => items.map(item => projectFn(item)));
}
/**
 * Sorts items in the source array and emits an array with those items sorted.
 */
function sortArray(comparator) {
    return map((items) => [...items].sort(comparator));
}
/**
 * Combines the Observables contained in the source array by applying {@link combineLatest}, emitting an array with the latest
 * value of each Observable of the source array. Combines only the Observables of the most recently emitted array.
 *
 * <span class=“informal”>Each time the source emits an array of Observables, combines its Observables by subscribing to each
 * of them, cancelling any subscription of a previous source emission.</span>
 */
function combineArray() {
    return pipe(switchMap((items) => items.length ? combineLatest(items) : of([])), map((items) => new Array().concat(...items)));
}
/**
 * Removes duplicates of elements in the source array.
 *
 * <span class=“informal”>Each time the source emits, maps the array to a new array with duplicates removed.</span>
 */
function distinctArray(keySelector = identity) {
    return pipe(map((items) => Arrays.distinct(items, keySelector)));
}
/**
 * Buffers the source Observable values until `closingNotifier$` notifier resolves, emits or completes.
 *
 * Once closed the buffer, emits its buffered values as a separate emission per buffered value, in the
 * order as collected. After that, this operator mirrors the source Observable, i.e., emits values as they
 * arrive.
 *
 * Unlike {@link bufferWhen} RxJS operator, the buffer is not re-opened once closed.
 *
 * @param closingNotifier$ Closes the buffer when the passed Promise resolves, or when the passed Observable
 *                         emits or completes.
 */
function bufferUntil(closingNotifier$) {
    const guard$ = from(closingNotifier$)
        .pipe(take(1), mergeMap(() => EMPTY), share({ resetOnComplete: false, resetOnError: false, resetOnRefCountZero: false }));
    return mergeMap((item) => concat(guard$, of(item)));
}
/**
 * Executes a tap-function for the first percolating value.
 */
function tapFirst(tapFn, scheduler) {
    return map((value, index) => {
        if (index === 0) {
            scheduler ? scheduler.schedule(tapFn) : tapFn(value);
        }
        return value;
    });
}
/**
 * Mirrors the source observable, running downstream operators (operators after the `observeIn` operator) and subscription handlers
 * (next, error, complete) in the given function.
 *
 * This operator is similar to RxJS's {@link observeOn} operator, but instead of a scheduler, it accepts a function.
 * The function is invoked each time the source emits, errors or completes and must call the provided `doContinue` function
 * to continue.
 *
 * Use this operator to set up a context for downstream operators, such as inside or outside the Angular zone.
 *
 * **Usage**
 *
 * The following example runs downstream operators inside Angular:
 *
 * ```ts
 * // Code running outside the Angular zone.
 * const zone = inject(NgZone);
 *
 * interval(1000)
 *   .pipe(
 *     tap(() => ...), // runs outside Angular
 *     observeIn(doContinue => zone.run(doContinue)),
 *     tap(() => ...), // runs inside Angular
 *   )
 *   .subscribe(() => ...); // runs inside Angular
 * ```
 *
 * @param fn - A function to set up the execution context. The function must call the provided `doContinue` function to continue.
 * @return An Observable that mirrors the source, but with downstream operators executed in the provided function.
 */
function observeIn(fn) {
    return (source) => {
        return new Observable((observer) => {
            const subscription = source.subscribe({
                next: next => fn(() => observer.next(next)),
                error: error => fn(() => observer.error(error)),
                complete: () => fn(() => observer.complete()),
            });
            return () => subscription.unsubscribe();
        });
    };
}
/**
 * Mirrors the source observable, subscribing to the source in the given function.
 *
 * This operator is similar to RxJS's {@link subscribeOn} operator, but instead of a scheduler, it accepts a function.
 * The function is invoked when subscribing to the source and must call the provided `doSubscribe` function to subscribe.
 *
 * Use this operator to set up a context for the subscription, such as inside or outside the Angular zone.
 *
 * **Usage**
 *
 * The following example illustrates subscribing outside Angular:
 *
 * ```ts
 * // Code running inside the Angular zone.
 * const zone = inject(NgZone);
 *
 * interval(1000)
 *   .pipe(subscribeIn(doSubscribe => zone.runOutsideAngular(doSubscribe)))
 *   .subscribe(() => ...);
 * ```
 *
 * @param fn - A function to set up the subscription context. The function must call the provided `doSubscribe` function to subscribe.
 * @return An Observable that mirrors the source, but with the subscription executed in the provided function.
 */
function subscribeIn(fn) {
    return (source) => {
        return new Observable((observer) => {
            const unsubscribe$ = new ReplaySubject(1);
            fn(() => source.pipe(takeUntil(unsubscribe$)).subscribe(observer));
            return () => unsubscribe$.next();
        });
    };
}

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/*
 * Secondary entrypoint: '@scion/toolkit/operators'
 *
 * @see https://github.com/ng-packagr/ng-packagr/blob/master/docs/secondary-entrypoints.md
 */

/**
 * Generated bundle index. Do not edit.
 */

export { bufferUntil, combineArray, distinctArray, filterArray, mapArray, observeIn, sortArray, subscribeIn, tapFirst };
//# sourceMappingURL=scion-toolkit-operators.mjs.map
