import { Observable, Subject, takeUntil, fromEvent, distinctUntilChanged, switchMap } from 'rxjs';
import { observeIn } from '@scion/toolkit/operators';

/*
 * Copyright (c) 2018-2024 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Wraps the native {@link ResizeObserver} in an RxJS Observable to observe resizing of an element.
 *
 * Upon subscription, emits the current size, and then continuously when the size changes. The Observable never completes.
 *
 * For more details, see https://developer.mozilla.org/en-US/docs/Web/API/ResizeObserver.
 *
 * @param element - Specifies the element to observe.
 * @param options - Configures {@link ResizeObserver}.
 *                  For more details, see https://developer.mozilla.org/en-US/docs/Web/API/ResizeObserver.
 */
function fromResize$(element, options) {
    return new Observable(observer => {
        const resizeObserver = new ResizeObserver(entries => observer.next(entries));
        resizeObserver.observe(element, options);
        return () => resizeObserver.disconnect();
    });
}

/*
 * Copyright (c) 2018-2024 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Wraps the native {@link IntersectionObserver} in an RxJS Observable to observe intersection of an element.
 *
 * Upon subscription, emits the current intersection state, and then continuously when the intersection state changes. The Observable never completes.
 *
 * For more details, see https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API.
 *
 * @param element - Specifies the element to observe.
 * @param options - Configures {@link IntersectionObserver}.
 *                  For more details, see https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API.
 */
function fromIntersection$(element, options) {
    return new Observable(observer => {
        const intersectionObserver = new IntersectionObserver(entries => observer.next(entries), options);
        intersectionObserver.observe(element);
        return () => intersectionObserver.disconnect();
    });
}

/*
 * Copyright (c) 2018-2024 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Wraps the native {@link MutationObserver} in an RxJS Observable to observe mutations of an element.
 *
 * For more details, see https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver.
 *
 * @param element - Specifies the element to observe.
 * @param options - Configures {@link MutationObserver}.
 *                  For more details, see https://developer.mozilla.org/en-US/docs/Web/API/MutationObserverInit.
 */
function fromMutation$(element, options) {
    return new Observable(observer => {
        const mutationObserver = new MutationObserver((mutations) => observer.next(mutations));
        mutationObserver.observe(element, options);
        return () => mutationObserver.disconnect();
    });
}

/*
 * Copyright (c) 2018-2024 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/**
 * Observes changes to the bounding box of a specified element.
 *
 * The bounding box includes the element's position relative to the top-left of the viewport and its size.
 * Refer to https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect for more details.
 *
 * Upon subscription, emits the current bounding box, and then continuously when the bounding box changes. The Observable never completes.
 *
 * The element and the document root (`<html>`) must be positioned `relative` or `absolute`.
 * If not, positioning is changed to `relative`.

 * Note:
 * There is no native browser API to observe the position of an element. The observable uses {@link IntersectionObserver} and
 * {@link ResizeObserver} to detect position changes. For tracking only size changes, use {@link fromResize$} instead.
 *
 * @param element - The element to observe.
 * @returns {Observable<DOMRect>} An observable that emits the bounding box of the element.
 */
function fromBoundingClientRect$(element) {
    return new Observable(observer => {
        const clientRectObserver = new BoundingClientRectObserver(element, clientRect => observer.next(clientRect));
        return () => clientRectObserver.destroy();
    });
}
/**
 * Observes the position and size of an element using {@link IntersectionObserver} and {@link ResizeObserver}.
 *
 * Since there is no native browser API to observe element position, we create four vertices and set up
 * an {@link IntersectionObserver} for each vertex. Configured with root margins aligned to the vertices'
 * bounding boxes, we can detect when the element (specifically its vertices) moves. We then emit the changed
 * bounding box of the element, recompute the root margins for each vertex, and restart observations.
 *
 * Observing vertices instead of the element itself enables position change detection even if the element is partially
 * scrolled out of the viewport.
 */
class BoundingClientRectObserver {
    _element;
    _destroy$ = new Subject();
    _disposables = new Array();
    _clientRect$ = new Subject();
    _vertices;
    constructor(_element, onChange) {
        this._element = _element;
        this._disposables.push(positionElement(this._element));
        this._vertices = {
            topLeft: new Vertex(this._element, { top: 0, left: 0 }, () => this.emitClientRect()),
            topRight: new Vertex(this._element, { top: 0, right: 0 }, () => this.emitClientRect()),
            bottomRight: new Vertex(this._element, { bottom: 0, right: 0 }, () => this.emitClientRect()),
            bottomLeft: new Vertex(this._element, { bottom: 0, left: 0 }, () => this.emitClientRect()),
        };
        this.installElementResizeObserver();
        this.installDocumentResizeObserver();
        this.installChangeEmitter(onChange);
    }
    /**
     * Monitors changes to the element's size.
     */
    installElementResizeObserver() {
        fromResize$(this._element, { box: 'border-box' })
            .pipe(
        // Run in animation frame to prevent 'ResizeObserver loop completed with undelivered notifications' error.
        // Do not use `animationFrameScheduler` because the scheduler does not necessarily execute in the current execution context, such as inside or outside Angular.
        // The scheduler always executes tasks in the context (e.g. zone) where the scheduler was first used in the application.
        observeIn(fn => requestAnimationFrame(fn)), takeUntil(this._destroy$))
            .subscribe(() => {
            this.emitClientRect(); // emit for instant update
            this.forEachVertex(vertex => vertex.computeRootMargin());
        });
    }
    /**
     * Monitors changes to the document's size.
     */
    installDocumentResizeObserver() {
        fromEvent(window, 'resize')
            .pipe(takeUntil(this._destroy$))
            .subscribe(() => {
            this.emitClientRect(); // emit for instant update
            this.forEachVertex(vertex => vertex.computeRootMargin());
        });
    }
    installChangeEmitter(onChange) {
        this._clientRect$
            .pipe(distinctUntilChanged(isEqualDomRect), takeUntil(this._destroy$))
            .subscribe(boundingBox => {
            onChange(boundingBox);
        });
    }
    emitClientRect() {
        this._clientRect$.next(this._element.getBoundingClientRect());
    }
    forEachVertex(fn) {
        Object.values(this._vertices).forEach(fn);
    }
    destroy() {
        this.forEachVertex(vertex => vertex.destroy());
        this._disposables.forEach(disposable => disposable());
        this._destroy$.next();
    }
}
class Vertex {
    _onPositionChange;
    _element;
    _rootMargin$ = new Subject();
    _destroy$ = new Subject();
    constructor(parent, position, _onPositionChange) {
        this._onPositionChange = _onPositionChange;
        this._element = parent.appendChild(this.createVertexElement(position));
        this.installIntersectionObserver();
        this.computeRootMargin();
    }
    /**
     * Computes the negative margins ("top right bottom left") to clip this vertex's bounding box.
     */
    computeRootMargin() {
        const documentRoot = document.documentElement;
        const documentClientRect = documentRoot.getBoundingClientRect();
        const elementClientRect = this._element.getBoundingClientRect();
        const top = elementClientRect.top;
        const left = elementClientRect.left;
        const right = documentClientRect.width - elementClientRect.right;
        const bottom = documentClientRect.height - elementClientRect.bottom;
        this._rootMargin$.next(`${Math.ceil(-1 * top)}px ${Math.ceil(-1 * right)}px ${Math.ceil(-1 * bottom)}px ${Math.ceil(-1 * left)}px`);
    }
    installIntersectionObserver() {
        this._rootMargin$
            .pipe(distinctUntilChanged(), switchMap(rootMargin => fromIntersection$(this._element, { rootMargin, threshold: 1, root: document })), takeUntil(this._destroy$))
            .subscribe((entries) => {
            const isIntersecting = entries.at(-1)?.isIntersecting ?? false;
            if (!isIntersecting) {
                this._onPositionChange();
                this.computeRootMargin();
            }
        });
        // Recompute the root margin when the element re-enters the viewport.
        fromIntersection$(this._element, { threshold: 1, root: document })
            .pipe(takeUntil(this._destroy$))
            .subscribe((entries) => {
            const isIntersecting = entries.at(-1)?.isIntersecting ?? false;
            if (isIntersecting) {
                this._onPositionChange();
                this.computeRootMargin();
            }
        });
    }
    createVertexElement(position) {
        const element = document.createElement('div');
        setStyle(element, {
            'position': 'absolute',
            'top': position.top === 0 ? '0' : null,
            'right': position.right === 0 ? '0' : null,
            'bottom': position.bottom === 0 ? '0' : null,
            'left': position.left === 0 ? '0' : null,
            'width': '1px',
            'height': '1px',
            'visibility': 'hidden',
            'pointer-events': 'none',
        });
        return element;
    }
    destroy() {
        this._element.remove();
        this._destroy$.next();
    }
}
/**
 * Ensures that the given HTML element is positioned, setting its position to `relative` if it is not already positioned.
 *
 * Positioning is set using a constructable CSS stylesheet with a CSS layer. CSS layers have lower priority than "normal"
 * CSS declarations, and the layer name indicates the styling originates from `@scion/toolkit`.
 *
 * This function adds a data attribute to the element to locate it from the stylesheet.
 *
 * The function returns a {@link DisposeFn}, that when called, removes the attribute from the element.
 */
const positionElement = (() => {
    const styleSheet = new CSSStyleSheet({});
    // Add styles to position the document root element, required by BoundingClientRectObserver.
    // - Ensures the document root element is positioned to support `@scion/toolkit/observable/fromBoundingClientRect$` for observing element bounding boxes.
    // - Aligns the document root with the page viewport so the top-level positioning context fills the page viewport (as expected by applications).
    styleSheet.insertRule(`
    @layer sci-toolkit {
      :root {
        position: absolute;
        inset: 0;
      }
    }`);
    // Add styles to change the element's position to relative, required by BoundingClientRectObserver.
    const elementIdentifier = 'data-sci-bounding-client-rect';
    const elementIdentifierImportant = 'data-sci-bounding-client-rect-important';
    styleSheet.insertRule(`
    @layer sci-toolkit {
      [${elementIdentifier}] {
        position: relative;
      }
      [${elementIdentifierImportant}] {
        position: relative !important;
      }
    }`);
    document.adoptedStyleSheets.push(styleSheet);
    return (element) => {
        const disposables = new Array();
        // Add attribute to locate the element from the stylesheet.
        element.setAttribute(elementIdentifier, '');
        disposables.push(() => element.removeAttribute(elementIdentifier));
        // If CSS layer styles have no effect due to 'static' positioning or unset styles, enforce positioning with !important.
        const animationFrame = requestAnimationFrame(() => {
            if (getComputedStyle(element).position === 'static') {
                element.setAttribute(elementIdentifierImportant, '');
                disposables.push(() => element.removeAttribute(elementIdentifierImportant));
            }
        });
        disposables.push(() => cancelAnimationFrame(animationFrame));
        return () => disposables.forEach(disposable => disposable());
    };
})();
/**
 * Apples specified styles for given element.
 */
function setStyle(element, styles) {
    Object.entries(styles).forEach(([name, value]) => {
        if (value === null) {
            element.style.removeProperty(name);
        }
        else {
            element.style.setProperty(name, value);
        }
    });
}
function isEqualDomRect(a, b) {
    return a.top === b.top && a.right === b.right && a.bottom === b.bottom && a.left === b.left;
}

/*
 * Copyright (c) 2018-2019 Swiss Federal Railways
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 *  SPDX-License-Identifier: EPL-2.0
 */
/*
 * Secondary entrypoint: '@scion/toolkit/observable'
 * This module does not depend on Angular.
 *
 * @see https://github.com/ng-packagr/ng-packagr/blob/master/docs/secondary-entrypoints.md
 */

/**
 * Generated bundle index. Do not edit.
 */

export { fromBoundingClientRect$, fromIntersection$, fromMutation$, fromResize$ };
//# sourceMappingURL=scion-toolkit-observable.mjs.map
