import { Observable } from 'rxjs';

/**
 * Allows observing items contained in web storage (local storage or session storage).
 *
 * Items are added in the JSON format to the storage.
 *
 * Because web storage does not notify about same document storage changes, always use {@link WebStorage#put}
 * to add items to the storage, or {@link WebStorage#remove} to remove items from the storage.
 *
 * #### Storage implementors:
 * - Local storage:
 *   Maintains a persistent storage area per origin.
 * - Session storage:
 *   Maintains a separate storage area per origin that is available for the duration of the page session
 *   (as long as the browser is open, including page reloads and restores).
 */
declare class WebStorage {
    private _storage;
    private _currentDocumentChange$;
    /**
     * Provide the storage implementor: {@link window.localStorage} or {@link window.sessionStorage}.
     */
    constructor(_storage: Storage);
    /**
     * Puts the given item into storage. The item is serialized to JSON.
     */
    put(key: string, value: unknown): void;
    /**
     * Puts the given item into storage, but only if not present. The item is serialized to JSON.
     *
     * Instead of an item you can pass a provider function to produce the item.
     */
    putIfAbsent(key: string, value: unknown | (() => unknown)): void;
    /**
     * Returns the item associated with the given key, or `undefined` if not found.
     *
     * Expects the value to be stored in JSON format. Throws an error if the value cannot be parsed.
     */
    get<T>(key: string): T | null | undefined;
    /**
     * Removes the item associated with the given key.
     */
    remove(key: string): void;
    /**
     * Checks if an item is present in the storage. Present also includes `null` and `undefined` items.
     */
    isPresent(key: string): boolean;
    /**
     * Observes the item associated with the given key.
     *
     * Upon subscription, it emits the current item from the storage, but, by default, only if present,
     * and then continuously emits when the item associated with the given key changes. It never completes.
     *
     * When removing the item from the storage, by default, the Observable does not emit.
     *
     * Set `emitIfAbsent` to `true` if to emit `undefined` when removing the item, or if there is no item associated
     * with the given key upon subscription. By default, `emitIfAbsent` is set to `false`.
     */
    observe$<T>(key: string, options?: {
        emitIfAbsent?: boolean;
    }): Observable<T>;
    /**
     * Notifies when no item is present for the given key. The Observable never completes.
     */
    absent$(key: string): Observable<void>;
}

export { WebStorage };
