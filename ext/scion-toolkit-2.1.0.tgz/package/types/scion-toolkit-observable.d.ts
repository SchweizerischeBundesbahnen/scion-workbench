import { Observable } from 'rxjs';

/**
 * Wraps the native {@link ResizeObserver} in an RxJS Observable to observe resizing of an element.
 *
 * Upon subscription, emits the current size, and then continuously when the size changes. The Observable never completes.
 *
 * For more details, see https://developer.mozilla.org/en-US/docs/Web/API/ResizeObserver.
 *
 * @param element - Specifies the element to observe.
 * @param options - Configures {@link ResizeObserver}.
 *                  For more details, see https://developer.mozilla.org/en-US/docs/Web/API/ResizeObserver.
 */
declare function fromResize$(element: Element, options?: ResizeObserverOptions): Observable<ResizeObserverEntry[]>;

/**
 * Wraps the native {@link IntersectionObserver} in an RxJS Observable to observe intersection of an element.
 *
 * Upon subscription, emits the current intersection state, and then continuously when the intersection state changes. The Observable never completes.
 *
 * For more details, see https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API.
 *
 * @param element - Specifies the element to observe.
 * @param options - Configures {@link IntersectionObserver}.
 *                  For more details, see https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API.
 */
declare function fromIntersection$(element: Element, options?: IntersectionObserverInit): Observable<IntersectionObserverEntry[]>;

/**
 * Wraps the native {@link MutationObserver} in an RxJS Observable to observe mutations of an element.
 *
 * For more details, see https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver.
 *
 * @param element - Specifies the element to observe.
 * @param options - Configures {@link MutationObserver}.
 *                  For more details, see https://developer.mozilla.org/en-US/docs/Web/API/MutationObserverInit.
 */
declare function fromMutation$(element: Node, options?: MutationObserverInit): Observable<MutationRecord[]>;

/**
 * Observes changes to the bounding box of a specified element.
 *
 * The bounding box includes the element's position relative to the top-left of the viewport and its size.
 * Refer to https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect for more details.
 *
 * Upon subscription, emits the current bounding box, and then continuously when the bounding box changes. The Observable never completes.
 *
 * The element and the document root (`<html>`) must be positioned `relative` or `absolute`.
 * If not, positioning is changed to `relative`.

 * Note:
 * There is no native browser API to observe the position of an element. The observable uses {@link IntersectionObserver} and
 * {@link ResizeObserver} to detect position changes. For tracking only size changes, use {@link fromResize$} instead.
 *
 * @param element - The element to observe.
 * @returns {Observable<DOMRect>} An observable that emits the bounding box of the element.
 */
declare function fromBoundingClientRect$(element: HTMLElement): Observable<DOMRect>;

export { fromBoundingClientRect$, fromIntersection$, fromMutation$, fromResize$ };
