/**
 * Provides cryptographic functions.
 */
declare namespace Crypto {
    /**
     * Generates a digest of the given data using the specified algorithm (or SHA-256 by default) and converts it to a hex string.
     *
     * Can only be used in secure contexts (HTTPS) or on localhost. For more information, refer to https://developer.mozilla.org/en-US/docs/Web/Security/Secure_Contexts.
     *
     * Credits: https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/digest
     */
    function digest(data: string | BufferSource, options?: {
        algorithm?: 'SHA-256' | 'SHA-384' | 'SHA-512';
    }): Promise<string>;
}

export { Crypto };
