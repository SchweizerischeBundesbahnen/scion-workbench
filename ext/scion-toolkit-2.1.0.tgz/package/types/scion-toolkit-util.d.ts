import { Observable } from 'rxjs';

/**
 * Provides utility methods to work with `undefined` values. The value `null` is considered as a defined value.
 *
 * Note: TypeScript 3.7 introduces the `nullish coalescing operator` [1] `(??)`, which is similar to the `Defined` function,
 * but also applies for `null` values.
 *
 * ## Links:
 * [1] https://www.typescriptlang.org/docs/handbook/release-notes/typescript-3-7.html#nullish-coalescing
 */
declare namespace Defined {
    /**
     * Returns the value if not `undefined`, otherwise "orElseValue". The "orElseValue" value can be created with a factory function.
     *
     * Unlike JavaScript's "nullish coalescing operator (??)", the "orElse" function only tests for `undefined`, not `null`.
     */
    function orElse<T>(value: T | undefined, orElseValue: T | (() => T)): T;
    /**
     * Returns the value if not `undefined`, otherwise throws the error created by the passed factory function.
     */
    function orElseThrow<T>(value: T | undefined, orElseThrowFn: () => Error): T;
}

/**
 * Provides array utility methods.
 */
declare namespace Arrays {
    /**
     * Returns the value, if an array, or adds it to an array. If `null` or `undefined` is given, by default, returns an empty array.
     */
    function coerce<T>(value: T | T[] | readonly T[] | null | undefined, options?: {
        coerceNullOrUndefined: true;
    }): NonNullable<T[]>;
    function coerce<T>(value: T | T[] | readonly T[] | null | undefined, options: {
        coerceNullOrUndefined: false;
    }): T[] | null | undefined;
    /**
     * Compares items of given arrays for reference equality.
     *
     * Use the parameter `exactOrder` to control if the item order must be equal (which is by default) or not.
     *
     * @deprecated since version 2.1.0; use {@link Objects.isEqual} instead; API will be removed in version 3.0.0.
     */
    function isEqual(array1: any[] | null | undefined, array2: any[] | null | undefined, options?: {
        exactOrder?: boolean;
    }): boolean;
    /**
     * Removes the specified element from an array, or the elements which satisfy the provided predicate function.
     * The original array will be changed.
     *
     * @param  array - The array from which elements should be removed.
     * @param  element - The element to be removed, or a predicate function to resolve elements which to be removed.
     * @param  options - Control if to remove all occurrences of the element. If not specified, all occurrences are removed.
     * @return the elements removed from the array.
     */
    function remove<T>(array: T[], element: T | ((element: T) => boolean), options?: {
        firstOnly: boolean;
    }): T[];
    /**
     * Removes duplicate items from the array. The original array will not be modified.
     *
     * Use the parameter `keySelector` to provide a function for comparing objects.
     */
    function distinct<T>(items: T[] | readonly T[], keySelector?: (item: T) => any): T[];
    /**
     * Intersects the given arrays, returning a new array containing all the elements contained in every array.
     * Arrays which are `undefined` or `null` are ignored.
     */
    function intersect<T>(...arrays: Array<T[] | readonly T[] | undefined | null>): T[];
    /**
     * Returns the last element in the given array, optionally matching the predicate if given.
     *
     * Returns `undefined` if no element is found.
     */
    function last<T>(array: T[] | readonly T[] | null | undefined, predicate?: (item: T) => boolean): T | undefined;
}

/**
 * Provides helper functions for working with objects.
 */
declare const Objects: {
    /**
     * Compares two objects for deep equality.
     *
     * Supported types: Record, Array, Map, Set, and primitives.
     *
     * The property order is ignored when comparing records. The element order in arrays is relevant unless specified otherwise in options.
     *
     * @param a - The first object to compare.
     * @param b - The second object to compare.
     * @param options - Controls how to compare two objects.
     * @param options.ignoreArrayOrder - Controls whether to ignore the element order when comparing arrays. By default, the order is not ignored.
     * @return `true` if objects are equal, false otherwise.
     */
    readonly isEqual: (a: unknown, b: unknown, options?: {
        ignoreArrayOrder?: true;
    }) => boolean;
    /**
     * Stringifies given object to matrix notation: a=b;c=d;e=f
     */
    readonly toMatrixNotation: (object: Record<string, unknown> | null | undefined) => string;
    /**
     * Like {@link Object.keys}, but preserving the data type of keys.
     */
    readonly keys: <T, P extends keyof T>(object: T) => P[];
    /**
     * Like {@link Object.values}, but preserving the data type of values and supporting optional properties.
     */
    readonly values: <T, P extends keyof T>(object: T) => Array<T[P]>;
    /**
     * Like {@link Object.entries}, but preserving the data type of keys and supporting optional properties.
     */
    readonly entries: <T, P extends keyof T>(object: T) => Array<[P, T[P]]>;
};

/**
 * Provides utilities for a dictionary.
 */
declare namespace Dictionaries {
    /**
     * Creates a {@link Dictionary} from the given dictionary-like object. If given a `Dictionary`, it is returned. If given `null` or `undefined`, by default, returns an empty {@link Dictionary}.
     */
    function coerce<T = unknown>(dictionaryLike: Dictionary<T> | Map<string, T> | Iterable<[string, T]> | undefined | null, options?: {
        coerceNullOrUndefined: true;
    }): NonNullable<Dictionary<T>>;
    function coerce<T = unknown>(dictionaryLike: Dictionary<T> | Map<string, T> | Iterable<[string, T]> | undefined | null, options: {
        coerceNullOrUndefined: false;
    }): Dictionary<T> | null | undefined;
    /**
     * Returns a new {@link Dictionary} with `undefined` values removed.
     */
    function withoutUndefinedEntries<T = unknown>(object: Dictionary<T | undefined>): Dictionary<T>;
}
/**
 * Represents an object with a variable number of properties, whose keys are not known at development time.
 */
interface Dictionary<T = unknown> {
    [key: string]: T;
}

/**
 * Provides utilities for {@link Map}.
 */
declare namespace Maps {
    /**
     * Creates a {@link Map} from the given map-like object. If given a `Map`, it is returned. If given `null` or `undefined`, by default, returns an empty {@link Map}.
     */
    function coerce<T = unknown>(mapLike: Map<string, T> | Dictionary<T> | Iterable<[string, T]> | undefined | null, options?: {
        coerceNullOrUndefined: true;
    }): NonNullable<Map<string, T>>;
    function coerce<T = unknown>(mapLike: Map<string, T> | Dictionary<T> | Iterable<[string, T]> | undefined | null, options: {
        coerceNullOrUndefined: false;
    }): Map<string, T> | null | undefined;
    /**
     * Adds the given value into a {@link Set} in the multi value {@link Map}.
     */
    function addSetValue<K, V>(multiValueMap: Map<K, Set<V>>, key: K, value: V): Map<K, Set<V>>;
    /**
     * Removes the given value or values matching the given predicate from the multi {@link Map}.
     *
     * @return `true` if the element was removed, or `false` otherwise.
     */
    function removeSetValue<K, V>(multiValueMap: Map<K, Set<V>>, key: K, value: V | PredicateFn<V>): boolean;
    /**
     * Adds the given value into an {@link Array} in the multi value {@link Map}.
     */
    function addListValue<K, V>(map: Map<K, V[]>, key: K, value: V): Map<K, V[]>;
    /**
     * Removes the given value or values matching the given predicate from the multi {@link Map}.
     *
     * @return `true` if the element was removed, or `false` otherwise.
     */
    function removeListValue<K, V>(multiValueMap: Map<K, V[]>, key: K, value: V | PredicateFn<V>): boolean;
}
/**
 * Represents a predicate function which returns `true` or `false`.
 */
type PredicateFn<T> = (value: T) => boolean;

declare namespace Observables {
    /**
     * Creates an `Observable` from the passed value, which will emit the value and then complete,
     * or, if passing an `Observable`, returns it unchanged. If passing a `Promise`, it is converted
     * to an `Observable`.
     */
    function coerce<T>(value: T | Observable<T> | Promise<T>): Observable<T>;
}

export { Arrays, Defined, Dictionaries, Maps, Objects, Observables };
export type { Dictionary, PredicateFn };
