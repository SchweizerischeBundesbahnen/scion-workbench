/**
 * Generates a UUID (universally unique identifier) compliant with the RFC 4122 version 4.
 */
declare function randomUUID(): string;

declare const uuid_util_d_randomUUID: typeof randomUUID;
declare namespace uuid_util_d {
  export {
    uuid_util_d_randomUUID as randomUUID,
  };
}

export { uuid_util_d as UUID };
